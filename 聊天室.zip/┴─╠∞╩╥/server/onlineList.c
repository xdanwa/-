#include "onlineList.h"

node* head = NULL;

node* make_node(char* id, int socket_fd)
{
	node* p = (node*)malloc(sizeof(*p));
	if(p == NULL)
	{
		perror("malloc error");
		exit(1);
	}

	strncpy(p->id, id, 9);
	p->id[9] = '\0';
	p->socket_fd = socket_fd;
	p->next = NULL;
	return p;
}

void insert_node(node* p)
{
	p->next = head;
	head = p;	
}

node* find_node(char* id)
{
	node* p = head;
	for(p = head; p != NULL; p = p->next)
	{
		if(strcmp(p->id, id) == 0)
		{
			return p;	
		}
	}
	return NULL;
}

void traverse()
{
	node* p = head;
	while(p != NULL)
	{
		printf("%s : %d\n", p->id, p->socket_fd);
		p = p->next;
	}
}

void free_node(node *p)
{
    free(p);
    p = NULL;
}

void destory_link()
{
	node* p;
	while(head != NULL)
	{
		p = head;
		head = head->next;
		free_node(p);
	}
	return;
}

void rm_node(node* p)
{
	node* pre = head;
	if(p == head)
	{
		head = head->next;
		return;
	}else
	{
		while(pre->next != NULL)
		{
			if(pre->next == p)
			{
				pre->next = p->next;
				return;
			}
			pre = pre->next;
		}
	}
}

// int main(int argc, char const *argv[])
// {
// 	node* p = NULL;
// 	p = make_node("111111111", 1);
// 	insert_node(p);
// 	p = make_node("222222222", 2);
// 	insert_node(p);
// 	p = make_node("333333333", 3);
// 	insert_node(p);
// 	p = make_node("444444444", 4);
// 	insert_node(p);
// 	traverse();

// 	if((p = find_node("111111111")) == NULL)
// 	{
// 		printf("not find\n");
// 	}else
// 	{
// 		printf("find id is %s\n", p->id);
// 	}

// 	rm_node(p);
// 	free_node(p);
// 	traverse();
// 	return 0;
// }