gcc select_server.c wrap.c messageExec.c sqlite.c onlineList.c -l sqlite3 -o server 
