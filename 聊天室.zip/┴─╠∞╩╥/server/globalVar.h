#ifndef GLOBALVAR_H
#define GLOBALVAR_H

#define OK 1
#define NOT 0

typedef struct messageBag
{
	char type;
	char src_id[10];
	char dest_id[10];
	char message[200];
}messageBag;


enum{
	REGISTER = 'R',
	LOGIN = 'L',
	CHANGE_PASSWORD = 'C',
	LOGOUT = 'O',
	PRIVATE_CHAT = 'P',
	GROUP_CHAT = 'G',
	LOOK_ONLINE_USER = 'U',
	KICK = 'K',
	BAN = 'B',
	UNBAN = 'N'
};


#endif