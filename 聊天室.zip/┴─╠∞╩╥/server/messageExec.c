#include "messageExec.h"

extern node* head;

void parse_message_terminal(char* buf, messageBag* message_terminal)
{
	if(strncmp(buf, "kick", 4) == 0)
	{
		message_terminal->type = 'K';
		strncpy(message_terminal->dest_id, buf+5, 9);

		node* p = find_node(message_terminal->dest_id);
		if(p == NULL)
		{
			printf("This id is not online!\n");
		}else
		{
			Write(p->socket_fd, message_terminal, sizeof(messageBag));
		}
		
	}

	if(strncmp(buf, "ban", 3) == 0)
	{
		message_terminal->type = 'B';
		strncpy(message_terminal->dest_id, buf+4, 9);
		
		node* p = find_node(message_terminal->dest_id);
		if(p == NULL)
		{
			printf("This id is not online!\n");
		}else
		{
			Write(p->socket_fd, message_terminal, sizeof(messageBag));
		}
	}

	if (strncmp(buf, "unban", 5) == 0)
	{
		message_terminal->type = 'N';
		strncpy(message_terminal->dest_id, buf+6, 9);

		node* p = find_node(message_terminal->dest_id);
		if(p == NULL)
		{
			printf("This id is not online!\n");
		}else
		{
			Write(p->socket_fd, message_terminal, sizeof(messageBag));
		}
	}
}


void parse_message_bag(int socket_fd, messageBag* message_bag)
{
	switch(message_bag->type)
	{
		case LOGIN:
		{
			user_login(socket_fd, message_bag);
			break;
		}
		case REGISTER:
		{
			user_register(socket_fd, message_bag);
			break;
		}
		case CHANGE_PASSWORD:
		{
			user_change_pwd(socket_fd, message_bag);
			break;
		}
		case LOGOUT:
		{
			user_logout(socket_fd, message_bag);
			break;
		}
		case PRIVATE_CHAT:
		{
			user_private_chat(socket_fd, message_bag);
			break;
		}
		case GROUP_CHAT:
		{
			user_group_chat(socket_fd, message_bag);
			break;
		}
		case LOOK_ONLINE_USER:
		{
			user_look_online_users(socket_fd, message_bag);
			break;
		}
		default: break;
	}
}

void user_look_online_users(int socket_fd, messageBag* message_bag)
{
	printf("user_look_online_users\n");

	/*clear message_bag->message!*/
	bzero(message_bag->message, sizeof(message_bag->message));
	node* p = head;
	char str_1 = '\n';
	char str_2 = '\0';
	for(p; p != NULL; p = p->next)
	{
		strcat(message_bag->message, p->id);
		strcat(message_bag->message, &str_1);
	}
	strcat(message_bag->message, &str_2);

	printf("%s\n", message_bag->message);

	Write(socket_fd, message_bag, sizeof(messageBag));
}


void user_group_chat(int socket_fd, messageBag* message_bag)
{
	printf("%s send everyone %s\n", message_bag->src_id, message_bag->message);

	node* p = head;
	node* self = find_node(message_bag->src_id);
	for(p; p != NULL; p = p->next)
	{
		if(p != self)
		{
			m_sqlite3_insert_chat_record(message_bag->src_id, "0", message_bag->message, "12");
			Write(p->socket_fd, message_bag, sizeof(messageBag));
		}		
	}
}


void user_private_chat(int socket_fd, messageBag* message_bag)
{
	printf("%s send %s to %s\n", message_bag->src_id, message_bag->message, message_bag->dest_id);

	node* p = find_node(message_bag->dest_id);
	if(p == NULL)
	{
		bzero(message_bag->message, sizeof(message_bag->message));
		strncpy(message_bag->message, "error", 5);
		Write(socket_fd, message_bag, sizeof(messageBag));
	}else
	{
		m_sqlite3_insert_chat_record(message_bag->src_id, message_bag->dest_id, message_bag->message, "12");
		Write(p->socket_fd, message_bag, sizeof(messageBag));
	}
}

void user_logout(int socket_fd, messageBag* message_bag)
{
	printf("%c\n", message_bag->type);

	node* p = find_node(message_bag->src_id);
	rm_node(p);
}

void user_change_pwd(int socket_fd, messageBag* message_bag)
{
	printf("%ld\n", sizeof(*message_bag));	
	printf("userChangePwdID=%s\n", message_bag->src_id);
	printf("userChangePwdPassword=%s\n", message_bag->message);

	int rc;
	rc = m_sqlite3_select_ID(message_bag->src_id, message_bag->message);
	if(rc == OK)
	{
		printf("ID exsit and pwd correct!\n");

		bzero(message_bag->message, sizeof(*message_bag->message));
		strncpy(message_bag->message, "success", 7);
		message_bag->message[7] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));

	}else
	{
		printf("ID is not exsit or pwd error!\n");

		bzero(message_bag->message, sizeof(*message_bag->message));
		strncpy(message_bag->message, "error", 5);
		message_bag->message[5] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));

		return;		
	}

	Read(socket_fd, message_bag, sizeof(messageBag));

	printf("%s\n", message_bag->src_id);
	printf("%s\n", message_bag->message);

	rc = m_sqlite3_update_pwd(message_bag->src_id, message_bag->message);

	if(rc == OK)
	{
		printf("change password success!\n");

		bzero(message_bag->message, sizeof(*message_bag->message));
		strncpy(message_bag->message, "change_pwd_success", 18);
		message_bag->message[18] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));
	}else
	{
		printf("change password error!\n");

		bzero(message_bag->message, sizeof(*message_bag->message));
		strncpy(message_bag->message, "change_pwd_error", 16);
		message_bag->message[16] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));
	}

	return;
}

void user_register(int socket_fd, messageBag* message_bag)
{
	printf("%ld\n", sizeof(*message_bag));	
	printf("userRegisterID=%s\n", message_bag->src_id);
	printf("userRegisterPassword=%s\n", message_bag->message + 9);

	int rc;
	rc = m_sqlite3_insert_userInfo(message_bag->src_id, message_bag->message + 9);
	if(rc == OK)
	{
		printf("Register success!\n");

		bzero(message_bag->message, sizeof(*message_bag->message));
		strncpy(message_bag->message, "register_success", 16);
		message_bag->message[16] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));
	}else
	{
		printf("Register failed!\n");

		bzero(message_bag->message, sizeof(*message_bag->message));
		strncpy(message_bag->message, "register_failed", 15);
		message_bag->message[15] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));
	}
}

void user_login(int socket_fd, messageBag* message_bag)
{
	printf("%ld\n", sizeof(*message_bag));	
	printf("userID=%s\n", message_bag->src_id);
	printf("userPassword=%s\n", message_bag->message + 9);

	node* p = NULL;
	if((p = find_node(message_bag->src_id)) != NULL)
	{
		printf("id is online\n");

		bzero(message_bag->message, sizeof(*message_bag->message));
		strncpy(message_bag->message, "id_online", 9);
		message_bag->message[9] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));

	}else
	{
		int rc;
		rc = m_sqlite3_select_ID(message_bag->src_id, message_bag->message + 9);

		if(rc == 1)
		{
			printf("success!\n");

			node* p = make_node(message_bag->src_id, socket_fd);
			insert_node(p);
			traverse();

			bzero(message_bag->message, sizeof(*message_bag->message));
			strncpy(message_bag->message, "login_success", 13);
			message_bag->message[13] = '\0';

			Write(socket_fd, message_bag, sizeof(messageBag));
		}else if(rc == -1)
		{
			printf("pwd error!\n");

			bzero(message_bag->message, sizeof(*message_bag->message));
			strncpy(message_bag->message, "pwd_error", 9);
			message_bag->message[9] = '\0';

			Write(socket_fd, message_bag, sizeof(messageBag));
		}else if(rc == -2)
		{
			printf("id not exsit!\n");

			bzero(message_bag->message, sizeof(*message_bag->message));
			strncpy(message_bag->message, "id_not_exsit", 12);
			message_bag->message[12] = '\0';

			Write(socket_fd, message_bag, sizeof(messageBag));
		}
	}	
}
