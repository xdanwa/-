#include "sqlite.h"

sqlite3 *db;

static int callback(void *data, int argc, char **argv, char **azColName)
{
	int i;
	//fprintf(stderr, "%s: ", (const char*)data);
	for(i = 0; i < argc; i++)
	{
		printf("%s = %s\n", azColName[i], argv[i]);
	}
	printf("\n");
	return 0;
}

int m_sqlite3_get_table(sqlite3* db, char* sql, char*** result, int* row, int* col, char** err_msg)
{
	int rc = 0;
	rc = sqlite3_get_table(db, sql, result, row, col, err_msg);
	if( rc != SQLITE_OK )
	{
		fprintf(stderr, "SQL error: %s\n", *err_msg);
		sqlite3_free(err_msg);
	}else
	{
		fprintf(stdout, "m_sqlite3_get_table successfully\n");
	}

	if(*row <= 0)
	{
		return NOT;
	}else
	{
		return OK;
	}
}

/**********************************initial database*****************************************/

void m_sqlite3_init_db(void)
{
	int rc = 0;
	char* err_msg = NULL;

	rc = sqlite3_open("chatroom.db", &db);
	if(rc != SQLITE_OK)
	{
		fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		exit(1);
	}else
	{
		printf("Succeed to open the database!\n");
	}
}

/**********************************initial database*****************************************/

/**********************************select from table*****************************************/

int m_sqlite3_select_all(void)
{
	int rc = 0;
	char* err_msg = NULL;
	char sql[100];
	
	sprintf(sql, SELECT_ALL, "userInfo");
	printf("%s\n", sql);

	rc = sqlite3_exec(db, sql, &callback, 0, &err_msg);
	if( rc != SQLITE_OK )
	{
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	}else
	{
		fprintf(stdout, "sqlite3_exec successfully\n");
	}
}

int m_sqlite3_select_ID(char* id, char* pwd)
{
	printf("m_sqlite3_select_ID\n");
	int rc = 0;
	char* err_msg = NULL;
	char sql[100];
	char** result;
	int row = 0;
	int col = 0;
	
	sprintf(sql, SELECT_ID, "userInfo", id);
	printf("%s\n", sql);
	rc = m_sqlite3_get_table(db, sql, &result, &row, &col, &err_msg);
	if(rc == OK)
	{
		// printf("row = %d col = %d\n", row, col);
		
		// int i,j;
		// int max = col;
		// for(i = 0; i < row; i++)
		// {
		// 	for(j = 0; j < col; j++)
		// 	{
		// 		printf("%s : %s\n", result[j], result[max++]);			
		// 	}
		// }

		sprintf(sql, SELECT_ID_AND_PWD, "userInfo", id, pwd);
		printf("%s\n", sql);

		rc = m_sqlite3_get_table(db, sql, &result, &row, &col, &err_msg);

		if(rc == OK)
		{
			// printf("row = %d col = %d\n", row, col);
			
			// int i,j;
			// int max = col;
			// for(i = 0; i < row; i++)
			// {
			// 	for(j = 0; j < col; j++)
			// 	{
			// 		printf("%s : %s\n", result[j], result[max++]);			
			// 	}
			// }
			return 1;  // id exsit and pwd is correct!
		}else
		{
			return -1;  // id exsit but pwd is error!
		}

	}else if(rc == NOT)
	{
		return -2;  //id not exist;
	}
	
}

/**********************************select from table*****************************************/

/**********************************insert into table*****************************************/

int m_sqlite3_insert_userInfo(char* id, char* pwd)
{
	int rc = 0;
	char* err_msg = NULL;
	char sql[100];
	
	sprintf(sql, INSERT_USERINFO, id, pwd);
	printf("%s\n", sql);

	rc = sqlite3_exec(db, sql, NULL, 0, &err_msg);
	if( rc != SQLITE_OK )
	{
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
		return NOT;
	}else
	{
		fprintf(stdout, "sqlite3_exec successfully\n");
		return OK;
	}
}

int m_sqlite3_insert_chat_record(char* src_id, char* dest_id, char* message, char* t)
{
	int rc = 0;
	char* err_msg = NULL;
	char sql[100];
	char new_message[200] = {'"'};
	char str = '"';
	strcat(new_message,message);
	strcat(new_message, &str);
	
	sprintf(sql, INSERT_CHAR_RECORD, src_id, dest_id, new_message, t);
	printf("%s\n", sql);

	rc = sqlite3_exec(db, sql, NULL, 0, &err_msg);
	if( rc != SQLITE_OK )
	{
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
		return NOT;
	}else
	{
		fprintf(stdout, "sqlite3_exec successfully\n");
		return OK;
	}
}


/**********************************update table**********************************************/

int m_sqlite3_update_pwd(char* id, char* pwd)
{
	int rc = 0;
	char* err_msg = NULL;
	char sql[100];
	
	sprintf(sql, UPDATE_PWD, pwd, id);
	printf("%s\n", sql);

	rc = sqlite3_exec(db, sql, NULL, 0, &err_msg);
	if( rc != SQLITE_OK )
	{
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
		return NOT;
	}else
	{
		fprintf(stdout, "sqlite3_exec successfully\n");
		return OK;
	}	
}





/**********************************update table**********************************************/

/**********************************insert into table*****************************************/

// int main()
// {
// 	int rc = 0;
// 	char* err_msg;
// 	char sql[1024];

// 	m_sqlite3_init_db();
// 	m_sqlite3_select_all();
// 	m_sqlite3_select_ID("123123123");
// 	//m_sqlite3_insert_userInfo(6, "123456");

// 	sqlite3_close(db);

// 	return 0;
// }
