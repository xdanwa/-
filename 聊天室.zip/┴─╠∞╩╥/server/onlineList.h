#ifndef ONLINELIST_H
#define ONLINELIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node{
	char id[10];
	int socket_fd;
	struct node* next;
}node;


node* make_node(char* id, int socket_fd);
void insert_node(node* p);
void free_node(node *p);
void destory_link();
void rm_node(node* p);
node* find_node(char* id);
void traverse();

#endif