#ifndef SQLITE_H
#define SQLITE_H

#include <stdio.h>
#include <stdlib.h>
#include <sqlite3.h>
#include <string.h>
#include "globalVar.h"


#define SELECT_ALL "select * from %s;"
#define SELECT_ID "select * from %s where ID = %s;"
#define SELECT_PWD "select * from %s where Password = %s;"
#define SELECT_ID_AND_PWD "select * from %s where ID = %s and Password = %s;"
#define INSERT_USERINFO "insert into userInfo (ID, Password) values(%s, %s);"
#define INSERT_CHAR_RECORD "insert into chatRecordInfo (src_id, dest_id, message, time) values(%s, %s, %s, %s);"
#define UPDATE_PWD "update userInfo set Password = '%s' where ID = '%s';"

static int callback(void *data, int argc, char **argv, char **azColName);
int m_sqlite3_get_table(sqlite3* db, char* sql, char*** result, int* row, int* col, char** err_msg);
void m_sqlite3_init_db(void);
int m_sqlite3_select_all(void);
int m_sqlite3_select_ID(char* id, char* pwd);
int m_sqlite3_insert_userInfo(char* id, char* pwd);
int m_sqlite3_update_pwd(char* id, char* pwd);
int m_sqlite3_insert_chat_record(char* src_id, char* dest_id, char* message, char* time);



#endif


