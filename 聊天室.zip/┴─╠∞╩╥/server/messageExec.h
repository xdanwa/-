#ifndef MESSAGEEXEC_H
#define MESSAGEEXEC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globalVar.h"
#include "wrap.h"
#include "sqlite.h"
#include "onlineList.h"

void user_look_online_users(int socket_fd, messageBag* message_bag);
void user_group_chat(int socket_fd, messageBag* message_bag);
void user_private_chat(int socket_fd, messageBag* message_bag);
void user_logout(int socket_fd, messageBag* message_bag);
void user_change_pwd(int socket_fd, messageBag* message_bag);
void user_register(int socket_fd, messageBag* message_bag);
void user_login(int socket_fd, messageBag* message_bag);
void parse_message_bag(int socket_fd, messageBag* message_bag);
void parse_message_terminal(char* buf, messageBag* message_terminal);

#endif