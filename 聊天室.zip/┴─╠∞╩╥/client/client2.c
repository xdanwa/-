/* client.c */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>

#include "login.h"
#include "messageExec.h"
#include "wrap.h"

#define MAXLINE 200
#define SERV_PORT 8000

int main(int argc, char *argv[])
{
	struct sockaddr_in servaddr;
	char buf[MAXLINE];
	int sockfd, n;
	int nready;
	int maxfd;
	fd_set rset, allset;

	/*user_input_message*/
	messageBag* message_bag = (messageBag*)malloc(sizeof(messageBag));
	if(message_bag == NULL)
	{
		printf("malloc failed!\n");
		exit(1);
	}
	/*message_from_server*/
	messageBag* message_server = (messageBag*)malloc(sizeof(messageBag));
	if(message_server == NULL)
	{
		printf("malloc failed!\n");
		exit(1);
	}
    
	sockfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr);
	servaddr.sin_port = htons(SERV_PORT);
    
	Connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));

	maxfd = sockfd;
	FD_ZERO(&allset);
	FD_SET(0, &allset);
	FD_SET(sockfd, &allset);

user_login:
	initial_login();
	int rc = parse_user_input(get_user_input(), sockfd, message_bag);
	if(rc == NOT)
	{
		goto user_login;
	}else if(rc == OUT)
	{
		Close(sockfd);
		return 0;
	}

	for( ; ; )
	{
		rset = allset;	/* structure assignment */
		nready = select(maxfd+1, &rset, NULL, NULL, NULL);
		if (nready < 0)
		{
			perr_exit("select error");
		}

		if(FD_ISSET(sockfd, &rset))
		{
			//printf("there are some news from server\n");
			if(parse_server_message(sockfd, message_server) == 0)
			{
				goto close;
			}
		}

		if(FD_ISSET(0, &rset))
		{
			//printf("there are some news from terminal\n");
			if(parse_terminal_message(sockfd, message_bag) == 0)
			{
				goto close;
			}
		}

		if (--nready == 0)
		continue;	/* no more readable descriptors */
	}
	
	user_logout(sockfd, message_bag);

close:
	Close(sockfd);
	free(message_bag);
	free(message_server);
	return 0;
}