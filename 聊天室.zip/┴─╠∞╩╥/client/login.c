#include "login.h"


void initial_login(void)
{
	printf("\t**************欢迎使用聊天室*******************\n");
    printf("\t*                                             *\n");
    printf("\t*            0: 注册帐号                      *\n");
    printf("\t*            1: 登录聊天室                    *\n");
    printf("\t*            2: changePwd                     *\n");
    printf("\t*            3: 退出聊天室                    *\n");
    printf("\t*                                             *\n");
    printf("\t***********************************************\n");
    printf("请输入规定的指令序号:\n");
}

int get_user_input(void)
{
	char buf[2];
	ssize_t n;

begin:
	bzero(buf, sizeof(buf));
	n = Read(0, buf, sizeof(buf));
	if(buf[0] == '0')
	{
		printf("注册帐号\n");
		return USER_REGISTER;

	}else if(buf[0] == '1')
	{
		printf("登录聊天室\n");
		return USER_LOGIN;

	}else if(buf[0] == '2')
	{
		printf("changePwd\n");
		return USER_CHANGE_PWD;

	}else if(buf[0] == '3')
	{
		printf("退出聊天室\n");
		return USER_LOGOUT;

	}else
	{
		printf("restart input\n");
		goto begin;
	}
}

int parse_user_input(int order, int socket_fd, messageBag* message_bag)
{
	switch(order)
	{
		case USER_REGISTER:
		{
			user_register(socket_fd, message_bag);
			break;
		}
		case USER_LOGIN:
		{
			int rc;
			rc = user_login(socket_fd, message_bag);
			if(rc == OK)
			{
				return OK;
			}else
			{
				return NOT;
			}
			break;
		}
		case USER_CHANGE_PWD:
		{
			int rc;
			rc = user_change_pwd(socket_fd, message_bag);
			if(rc == OK)
			{
				return OK;
			}else
			{
				return NOT;
			}
			break;
		}
		case USER_LOGOUT:
		{
			return OUT;
			break;
		}
		default: break;
	}
}

int user_register(int socket_fd, messageBag* message_bag)
{
	char buf[10];
	ssize_t n;
	message_bag->type = REGISTER;

input_ID:

		printf("Please input register ID:\n");
		bzero(buf, sizeof(buf));
		n = Read(0, buf, sizeof(buf));
		if(n != 10)
		{
			printf("The id has night datas\n");
			goto input_ID;
		}
		strncpy(message_bag->src_id, buf, 9);
		message_bag->src_id[9] = '\0';
		strncpy(message_bag->message, buf,9);

input_pwd:

		printf("Please input register password:\n");
		bzero(buf, sizeof(buf));
		n = Read(0, buf, sizeof(buf));
		if(n != 10)
		{
			printf("The password has night datas\n");
			goto input_pwd;
		}
		strncpy((message_bag->message)+9, buf, 9);
		message_bag->message[18] = '\0';

		printf("%c\n", message_bag->type);
		printf("%s\n", message_bag->message);

		Write(socket_fd, message_bag, sizeof(messageBag));

		Read(socket_fd, message_bag, sizeof(messageBag));

		if(strcmp(message_bag->message, "register_success") == 0)
		{
			printf("Register success! Please login!\n");
			int rc;
			rc = user_login(socket_fd, message_bag);
			if(rc == OK)
			{
				return OK;
			}else
			{
				return NOT;
			}
		}

		if(strcmp(message_bag->message, "register_failed") == 0)
		{
			printf("Register falid!(maby the id has been registered)!\n");
			return NOT;			
		}
}

int user_login(int socket_fd, messageBag* message_bag)
{
	char buf[10];
	ssize_t n;
	message_bag->type = LOGIN;

input_ID:

		printf("Please input ID:\n");
		bzero(buf, sizeof(buf));
		n = Read(0, buf, sizeof(buf));
		if(n != 10)
		{
			printf("Input error(The id has night datas)\n");
			goto input_ID;
		}
		strncpy(message_bag->src_id, buf, 9);
		message_bag->src_id[9] = '\0';
		strncpy(message_bag->message, buf,9);

input_pwd:

		printf("Please input password:\n");
		bzero(buf, sizeof(buf));
		n = Read(0, buf, sizeof(buf));
		if(n != 10)
		{
			printf("Input error(The password has night datas)\n");
			goto input_pwd;
		}
		strncpy((message_bag->message)+9, buf, 9);
		message_bag->message[18] = '\0';

		// printf("%c\n", message_bag->type);
		// printf("%s\n", message_bag->src_id);
		// printf("%s\n", message_bag->message);

		Write(socket_fd, message_bag, sizeof(messageBag));

		Read(socket_fd, message_bag, sizeof(messageBag));
		printf("%s\n", message_bag->message);

		if(strcmp(message_bag->message, "login_success") == 0)
		{
			return OK;
		}

		if(strcmp(message_bag->message, "id_online") == 0)
		{
			printf("This ID is online! Please not login again!\n");
			return NOT;
		}

		if(strcmp(message_bag->message, "pwd_error") == 0)
		{
			goto input_pwd;
		}

		if(strcmp(message_bag->message, "id_not_exsit") == 0)
		{
			printf("The ID is not exist, Please register!\n");
			return NOT;						
		}
}

int user_change_pwd(int socket_fd, messageBag* message_bag)
{
	char buf[10];
	ssize_t n;
	message_bag->type = CHANGE_PASSWORD;

input_ID:

		printf("Please input ID:\n");
		bzero(buf, sizeof(buf));
		n = Read(0, buf, sizeof(buf));
		if(n != 10)
		{
			printf("Input error(The id has night datas)\n");
			goto input_ID;
		}
		strncpy(message_bag->src_id, buf, 9);
		message_bag->src_id[9] = '\0';

input_pwd:

		printf("Please input past password:\n");
		bzero(buf, sizeof(buf));
		n = Read(0, buf, sizeof(buf));
		if(n != 10)
		{
			printf("Input error(The password has night datas)\n");
			goto input_pwd;
		}
		strncpy(message_bag->message, buf, 9);
		message_bag->message[9] = '\0';


		Write(socket_fd, message_bag, sizeof(messageBag));

		Read(socket_fd, message_bag, sizeof(messageBag));

		if(strcmp(message_bag->message, "error") == 0)
		{
			printf("password error!\n");
			goto input_ID;
		}

		if(strcmp(message_bag->message, "success") == 0)
		{
			printf("Please input new password!\n");
		}

input_new_pwd:
		
		bzero(message_bag->message, sizeof(*message_bag->message));
		bzero(buf, sizeof(buf));
		n = Read(0, buf, sizeof(buf));
		if(n != 10)
		{
			printf("Input error(The password has night datas)\n");
			goto input_new_pwd;
		}

		strncpy(message_bag->message, buf, 9);
		message_bag->message[9] = '\0';

		Write(socket_fd, message_bag, sizeof(messageBag));

		Read(socket_fd, message_bag, sizeof(messageBag));	

		if(strcmp(message_bag->message, "change_pwd_success") == 0)
		{
			printf("change password success!\n");
			return NOT;   //let user login!
		}

		if(strcmp(message_bag->message, "change_pwd_error") == 0)
		{
			printf("change password error!\n");
			goto input_ID;
		}
}

int user_logout(int socket_fd, messageBag* message_bag)
{
	message_bag->type = LOGOUT;

	Write(socket_fd, message_bag, sizeof(messageBag));
}



