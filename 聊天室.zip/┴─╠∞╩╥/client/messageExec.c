#include "messageExec.h"

int ban_flag = 0;

int parse_terminal_message(int socket_fd, messageBag* message_bag)
{
	char buf[200];
	ssize_t n;
	bzero(buf, sizeof(buf));

	n = Read(0, buf, sizeof(buf));

	/*private chat*/
	if(buf[9] == '/' &&  strncmp(message_bag->src_id, buf, 9) != 0)
	{
		if(ban_flag == 1)
		{
			printf("you have been baned by manager!\n");
			return 1;
		}else
		{
			message_bag->type = PRIVATE_CHAT;
			int len = n - 10; //except '/'
			//printf("%d\n", len);
			strncpy(message_bag->dest_id, buf, 9);
			strncpy(message_bag->message, buf+10, len);
			message_bag->message[len-1] = '\0';
			//printf("%c, %s\n", message_bag->type, message_bag->message);

			Write(socket_fd, message_bag, sizeof(messageBag));
		}
	}

	/*group chat*/
	if(strncmp(buf, "group/", 6) == 0)
	{
		if(ban_flag == 1)
		{
			printf("you have been baned by manager!\n");
			return 1;
		}else
		{
			message_bag->type = GROUP_CHAT;
			int len = n - 6; //except '/'
			//printf("%d\n", len);
			strncpy(message_bag->message, buf+6, len);
			message_bag->message[len-1] = '\0';
			printf("%c, %s\n", message_bag->type, message_bag->message);

			Write(socket_fd, message_bag, sizeof(messageBag));			
		}
	}

	/*look_online_user*/
	if(strncmp(buf, "look_online_users", 17) == 0)
	{
		message_bag->type = LOOK_ONLINE_USER;
		Write(socket_fd, message_bag, sizeof(messageBag));
	}

	/*user_logout*/
	if(strncmp(buf, "exit", 4) == 0)
	{
		message_bag->type = LOGOUT;
		Write(socket_fd, message_bag, sizeof(messageBag));

		return 0;		
	}
}

int parse_server_message(int socket_fd, messageBag* message_server)
{
	ssize_t n;
	n = Read(socket_fd, message_server, sizeof(messageBag));
	/*private_chat*/
	if(message_server->type == 'P')
	{	
		if(strncmp(message_server->message, "error", 5) == 0)
		{
			printf("this id is not online!\n");
		}else
		{
			printf("%s send %s\n", message_server->src_id, message_server->message);
		}	
	}

	/*group_chat*/
	if(message_server->type == 'G')
	{
		printf("%s send %s\n", message_server->src_id, message_server->message);
	}

	/*look_online_users*/
	if(message_server->type == 'U')
	{
		printf("%s\n", message_server->message);
	}

	/*manager_kick_user*/
	if(message_server->type == 'K')
	{
		printf("you have been kicked by manager from chatroom!\n");
		return 0;
	}

	if(message_server->type == 'B')
	{
		printf("you have been baned by manager!\n");
		ban_flag = 1;
	}

	if (message_server->type == 'N')
	{
		printf("you have been unbaned by manager!\n");
		ban_flag = 0;
	}
}
