#ifndef LOGIN_H
#define LOGIN_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>
#include <string.h>
#include "wrap.h"
#include "messageExec.h"

enum user_input
{
	USER_REGISTER,
	USER_LOGIN,
	USER_CHANGE_PWD,
	USER_LOGOUT
};

void initial_login(void);
int get_user_input(void);
int parse_user_input(int order, int socket_fd, messageBag* message_bag);
int user_register(int socket_fd, messageBag* message_bag);
int user_login(int socket_fd, messageBag* message_bag);
int user_change_pwd(int socket_fd, messageBag* message_bag);
int user_logout(int socket_fd, messageBag* message_bag);


#endif