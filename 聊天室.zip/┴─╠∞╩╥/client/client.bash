gcc client2.c login.c wrap.c messageExec.c -o client
