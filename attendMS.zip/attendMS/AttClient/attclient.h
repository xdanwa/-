#ifndef ATTCLIENT_H
#define ATTCLIENT_H

#include <QMainWindow>

#include "loginform.h"
#include "chatroomform.h"

#include "staffinfoform.h"
#include "checkform.h"
#include "attendanceform.h"
#include "vacationform.h"
#include "staffchangepswdform.h"
#include "staffregisterform.h"
#include "vacationform.h"

#include "managerinfoform.h"
#include "vacationmsform.h"

#include "msgsocket.h"

namespace Ui {
class AttClient;
}

class AttClient : public QMainWindow
{
    Q_OBJECT

protected:
    void paintEvent(QPaintEvent *);
    void closeEvent(QCloseEvent *ev);

public slots:
    void slotUserLogin(QString id, QString pswd);
    void slotUserLoginResult(bool res);
    void slotUserLogout(void);
    void slotUserLogoutResult(bool res);
    void slotRelogin(bool res);

    void slotUserRegister(void);
    void slotRegister(void);
    void slotRegisterRelogin(bool res);

    void slotStaffChangePswd(QString newPswd);

    void slotStaffWorkTime(QString workTime, QString endTime, QString date);
    void slotStaffEndTime(QString workTime, QString endTime, QString date);
    void slotObtainStaffAttendanceInfo(void);

    void slotVacationApply(QString vacationReason, QString vacationDate);
    void slotVacationApplyAgree(void);
    void slotVacationApplyReject(void);
    void slotGainStaffVacationApplyInfo(void);

    void slotGainGroupBulletin(void);    //获取群公告！
    void slotPublishBulletin(QString dateTime, QString data);  //发布群公告！
    void slotSendGroupMessage(QString dateTime, QString data);  //发布群消息！

    void slotGainGroupMember(void);     //获取群成员！

public:
    explicit AttClient(QWidget *parent = 0);
    ~AttClient();

private slots:
    void on_actionCheck_In_triggered();

    void on_actionVavation_triggered();

    void on_actionAttendance_triggered();

    void on_actionStaffInfo_triggered();

    void on_actionManagerInfo_triggered();

    void on_actionStaffChangePswd_triggered();

    void on_actionVacationMS_triggered();

    void on_actionChatRoom_triggered();

private:
    Ui::AttClient *ui;

    bool m_isCloseSystem;
    LoginForm* m_loginForm;
    ChatRoomForm* m_chatRoomForm;
    MsgSocket* m_msgSocket;

    ////////////////staff//////////////////

    StaffInfoForm* m_staffInfoForm;
    CheckForm* m_checkForm;
    AttendanceForm* m_attendanceForm;
    VacationForm* m_vacationForm;
    StaffChangePswdForm* m_staffChangePswdForm;
    StaffRegisterForm* m_staffRegisterForm;
    void initStaffWidget();

    ///////////////manager////////////////////

    ManagerInfoForm* m_managerInfoForm;
    VacationMSForm* m_vacationMSForm;
    void initManagerWidget();
};

#endif // ATTCLIENT_H
