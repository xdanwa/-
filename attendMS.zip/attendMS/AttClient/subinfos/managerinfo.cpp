#include "managerinfo.h"

ManagerInfo::ManagerInfo()
{

}

ManagerInfo::ManagerInfo(QString id, QString name,
                         QString dept)
{
    m_id = id;
    m_name = name;
    m_dept = dept;
}

void ManagerInfo::setID(QString id)
{
    m_id = id;
}

void ManagerInfo::setName(QString name)
{
    m_name = name;
}

void ManagerInfo::setDept(QString dept)
{
    m_dept = dept;
}

const QString ManagerInfo::getID(void) const
{
    return m_id;
}

const QString ManagerInfo::getName(void) const
{
    return m_name;
}

const QString ManagerInfo::getDept(void) const
{
    return m_dept;
}

void ManagerInfo::ManagerInfoDisplay(void)
{
    qDebug() << "id: " << m_id;
    qDebug() << "name: " << m_name;
    qDebug() << "dept: " << m_dept;
}

