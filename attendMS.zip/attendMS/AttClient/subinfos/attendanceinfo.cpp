#include "attendanceinfo.h"

AttendanceInfo::AttendanceInfo()
{

}

AttendanceInfo::AttendanceInfo(QString staffID, QString staffName, QString staffDept,
               QString workTime, QString endTime, QString date)
{
    m_staffID = staffID;
    m_staffName = staffName;
    m_staffDept = staffDept;
    m_workTime = workTime;
    m_endTime = endTime;
    m_date = date;
}

void AttendanceInfo::setStaffID(QString staffID)
{
    m_staffID = staffID;
}

void AttendanceInfo::setStaffName(QString staffName)
{
    m_staffName = staffName;
}

void AttendanceInfo::setStaffDept(QString staffDept)
{
    m_staffDept = staffDept;
}

void AttendanceInfo::setWorkTime(QString workTime)
{
    m_workTime = workTime;
}

void AttendanceInfo::setEndTime(QString endTime)
{
    m_endTime = endTime;
}

void AttendanceInfo::setDate(QString Date)
{
    m_date = Date;
}

const QString AttendanceInfo::getStaffID(void) const
{
    return m_staffID;
}

const QString AttendanceInfo::getStaffName(void) const
{
    return m_staffName;
}

const QString AttendanceInfo::getStaffDept(void) const
{
    return m_staffDept;
}

const QString AttendanceInfo::getWorkTime(void) const
{
    return m_workTime;
}

const QString AttendanceInfo::getEndTime(void) const
{
    return m_endTime;
}

const QString AttendanceInfo::getDate(void) const
{
    return m_date;
}

void AttendanceInfo::AttendanceInfoDisplay(void)
{
    qDebug() << "staff_id:" << m_staffID;
    qDebug() << "staff_name:" << m_staffName;
    qDebug() << "staff_dept:" << m_staffDept;
    qDebug() << "work_time:" << m_workTime;
    qDebug() << "end_time:" << m_endTime;
    qDebug() << "date:" << m_date;
}

