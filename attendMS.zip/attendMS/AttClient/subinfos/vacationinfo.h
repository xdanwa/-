#ifndef VACATIONINFO_H
#define VACATIONINFO_H

#include <QString>
#include <QList>
#include <QMap>
#include <QDebug>

class VacationInfo
{
public:
    VacationInfo();
    VacationInfo(QString id, QString name, QString dept,
                 QString managerID,
                 QString vacationDate, QString vacationReason,
                 QString flag);

    void setID(QString id);
    void setName(QString name);
    void setDept(QString dept);
    void setManagerID(QString id);
    void setVacationDate(QString vacationDate);
    void setVacationReason(QString vacationReason);
    void setVacationFlag(QString flag);

    const QString getID(void) const;
    const QString getName(void) const;
    const QString getDept(void) const;
    const QString getManagerID(void) const;
    const QString getVacationDate(void) const;
    const QString getVacationReason(void) const;
    const QString getVacationFlag(void) const;

    void VacationInfoDisplay(void);

    friend bool operator ==(const VacationInfo &one, const VacationInfo &other);

private:

    QString m_id;
    QString m_name;
    QString m_dept;
    QString m_managerID;
    QString m_vacationDate;
    QString m_vacationReason;
    QString m_flag;      //用来标记员工请假信息是否被经理处理
};

typedef QList<VacationInfo> VacationInfoList;
typedef QMap<QString, VacationInfoList::iterator> VacationInfoMap;

#endif // VACATIONINFO_H
