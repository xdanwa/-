#ifndef ATTENDANCEINFO_H
#define ATTENDANCEINFO_H

#include <QString>
#include <QList>
#include <QDebug>

class AttendanceInfo
{
public:
    AttendanceInfo();
    AttendanceInfo(QString staffID, QString staffName, QString staffDept,
                   QString workTime, QString endTime, QString date);

    void setStaffID(QString staffID);
    void setStaffName(QString staffName);
    void setStaffDept(QString staffDept);
    void setWorkTime(QString workTime);
    void setEndTime(QString endTime);
    void setDate(QString Date);

    const QString getStaffID(void) const;
    const QString getStaffName(void) const;
    const QString getStaffDept(void) const;
    const QString getWorkTime(void) const;
    const QString getEndTime(void) const;
    const QString getDate(void) const;

    void AttendanceInfoDisplay(void);

private:

    QString m_staffID;
    QString m_staffName;
    QString m_staffDept;
    QString m_workTime;
    QString m_endTime;
    QString m_date;
};

typedef QList<AttendanceInfo> AttendanceInfoList;
typedef QMap<QString, AttendanceInfoList::iterator> AttendanceInfoMap;

#endif // ATTENDANCEINFO_H
