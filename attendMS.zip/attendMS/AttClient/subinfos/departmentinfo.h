#ifndef DEPARTMENTINFO_H
#define DEPARTMENTINFO_H

#include <QString>
#include <QMap>
#include <QList>
#include <QDebug>

class DepartmentInfo
{
public:
    DepartmentInfo();
    DepartmentInfo(QString id, QString name,
                   QString count, QString manager);

    void setID(QString id);
    void setName(QString name);
    void setCount(QString count);
    void setManager(QString manager);

    const QString getID(void) const;
    const QString getName(void) const;
    const QString getCount(void) const;
    const QString getManager(void) const;

    void DepartmentInfoDisplay(void);

private:

    QString m_id;
    QString m_name;
    QString m_count;
    QString m_manager;

};

typedef QList<DepartmentInfo> DepartmentInfoList;
typedef QMap<QString, DepartmentInfoList::iterator> DepartmentInfoMap;

#endif // DEPARTMENTINFO_H
