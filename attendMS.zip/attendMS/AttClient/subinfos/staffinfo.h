#ifndef STAFFINFO_H
#define STAFFINFO_H

#include <QString>
#include <QMap>
#include <QList>
#include <QDebug>

class StaffInfo
{
public:
    StaffInfo();
    StaffInfo(QString id, QString name,
              QString dept, QString post);

    void setID(QString id);
    void setName(QString name);
    void setDept(QString dept);
    void setPost(QString post);

    const QString getID(void) const;
    const QString getName(void) const;
    const QString getDept(void) const;
    const QString getPost(void) const;

    void StaffInfoDisplay(void);

private:

    QString m_id;
    QString m_name;
    QString m_dept;
    QString m_post;

};

typedef QList<StaffInfo> StaffInfoList;
typedef QMap<QString, StaffInfoList::iterator> StaffInfoMap;

#endif // STAFFINFO_H
