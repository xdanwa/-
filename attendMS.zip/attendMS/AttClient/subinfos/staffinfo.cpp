#include "staffinfo.h"

StaffInfo::StaffInfo()
{

}

StaffInfo::StaffInfo(QString id, QString name,
                     QString dept, QString post)
{
    m_id = id;
    m_name = name;
    m_dept = dept;
    m_post = post;
}

void StaffInfo::setID(QString id)
{
    m_id = id;
}

void StaffInfo::setName(QString name)
{
    m_name = name;
}

void StaffInfo::setDept(QString dept)
{
    m_dept = dept;
}

void StaffInfo::setPost(QString post)
{
    m_post = post;
}

const QString StaffInfo::getID(void) const
{
    return  m_id;
}

const QString StaffInfo::getName(void) const
{
    return m_name;
}

const QString StaffInfo::getDept(void) const
{
    return m_dept;
}

const QString StaffInfo::getPost(void) const
{
    return m_post;
}

void StaffInfo::StaffInfoDisplay(void)
{
    qDebug() << "id: " << m_id;
    qDebug() << "name: " << m_name;
    qDebug() << "dept: " << m_dept;
    qDebug() << "post: " << m_post;
}

