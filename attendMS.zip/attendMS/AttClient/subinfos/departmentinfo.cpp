#include "departmentinfo.h"

DepartmentInfo::DepartmentInfo()
{

}

DepartmentInfo::DepartmentInfo(QString id, QString name,
                               QString count, QString manager)
{
    m_id = id;
    m_name = name;
    m_count = count;
    m_manager = manager;
}

void DepartmentInfo::setID(QString id)
{
    m_id = id;
}

void DepartmentInfo::setName(QString name)
{
    m_name = name;
}

void DepartmentInfo::setCount(QString count)
{
    m_count = count;
}

void DepartmentInfo::setManager(QString manager)
{
    m_manager = manager;
}

const QString DepartmentInfo::getID(void) const
{
    return m_id;
}

const QString DepartmentInfo::getName(void) const
{
    return m_name;
}

const QString DepartmentInfo::getCount(void) const
{
    return m_count;
}

const QString DepartmentInfo::getManager(void) const
{
    return m_manager;
}

void DepartmentInfo::DepartmentInfoDisplay(void)
{
    qDebug() << "ID:" << m_id;
    qDebug() << "name:" << m_name;
    qDebug() << "count:" << m_count;
    qDebug() << "manager:" << m_manager;
}

