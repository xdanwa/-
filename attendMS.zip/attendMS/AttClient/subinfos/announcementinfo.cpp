#include "announcementinfo.h"

AnnouncementInfo::AnnouncementInfo()
{

}

AnnouncementInfo::AnnouncementInfo(QString ID, QString name, QString dept,
                 QString dateTime, QString content)
{
    m_id = ID;
    m_name = name;
    m_dept = dept;
    m_dateTime = dateTime;
    m_content = content;
}

void AnnouncementInfo::setID(QString ID)
{
    m_id = ID;
}

void AnnouncementInfo::setName(QString name)
{
    m_name = name;
}

void AnnouncementInfo::setDept(QString dept)
{
    m_dept = dept;
}

void AnnouncementInfo::setdateTime(QString dateTime)
{
    m_dateTime = dateTime;
}

void AnnouncementInfo::setContent(QString content)
{
    m_content = content;
}

const QString AnnouncementInfo::getID(void) const
{
    return m_id;
}

const QString AnnouncementInfo::getName(void) const
{
    return m_name;
}

const QString AnnouncementInfo::getDept(void) const
{
    return m_dept;
}

const QString AnnouncementInfo::getdateTime(void) const
{
    return m_dateTime;
}

const QString AnnouncementInfo::getContent(void) const
{
    return m_content;
}

void AnnouncementInfo::AnnouncementInfoDisplay(void)
{
    qDebug() << "ID: " << m_id;
    qDebug() << "Name: " << m_name;
    qDebug() << "Dept: " << m_dept;
    qDebug() << "DateTime: " << m_dateTime;
    qDebug() << "Content: " << m_content;
}

