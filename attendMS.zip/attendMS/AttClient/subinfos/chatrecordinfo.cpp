#include "chatrecordinfo.h"

ChatRecordInfo::ChatRecordInfo()
{

}

ChatRecordInfo::ChatRecordInfo(QString ID, QString name, QString dept,
               QString dateTime, QString content)
{
    m_id = ID;
    m_name = name;
    m_dept = dept;
    m_dateTime = dateTime;
    m_content = content;
}

void ChatRecordInfo::setID(QString ID)
{
    m_id = ID;
}

void ChatRecordInfo::setName(QString name)
{
    m_name = name;
}

void ChatRecordInfo::setDept(QString dept)
{
    m_dept = dept;
}

void ChatRecordInfo::setdateTime(QString dateTime)
{
    m_dateTime = dateTime;
}

void ChatRecordInfo::setContent(QString content)
{
    m_content = content;
}

const QString ChatRecordInfo::getID(void) const
{
    return m_id;
}

const QString ChatRecordInfo::getName(void) const
{
    return m_name;
}

const QString ChatRecordInfo::getDept(void) const
{
    return m_dept;
}

const QString ChatRecordInfo::getdateTime(void) const
{
    return m_dateTime;
}

const QString ChatRecordInfo::getContent(void) const
{
    return m_content;
}

void ChatRecordInfo::ChatRecordInfoDisplay(void)
{
    qDebug() << "ID: " << m_id;
    qDebug() << "Name: " << m_name;
    qDebug() << "Dept: " << m_dept;
    qDebug() << "DateTime: " << m_dateTime;
    qDebug() << "Content: " << m_content;
}



