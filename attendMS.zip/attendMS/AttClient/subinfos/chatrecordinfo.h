#ifndef CHATRECORDINFO_H
#define CHATRECORDINFO_H

#include <QString>
#include <QList>
#include <QDebug>

class ChatRecordInfo
{
public:
    ChatRecordInfo();
    ChatRecordInfo(QString ID, QString name, QString dept,
                   QString dateTime, QString content);

    void setID(QString ID);
    void setName(QString name);
    void setDept(QString dept);
    void setdateTime(QString dateTime);
    void setContent(QString content);

    const QString getID(void) const;
    const QString getName(void) const;
    const QString getDept(void) const;
    const QString getdateTime(void) const;
    const QString getContent(void) const;

    void ChatRecordInfoDisplay(void);

private:
    QString m_id;
    QString m_name;
    QString m_dept;
    QString m_dateTime;
    QString m_content;

};

typedef QList<ChatRecordInfo> ChatRecordInfoList;

#endif // CHATRECORDINFO_H
