#ifndef MANAGERINFO_H
#define MANAGERINFO_H

#include <QString>
#include <QList>
#include <QMap>
#include <QDebug>

class ManagerInfo
{
public:
    ManagerInfo();
    ManagerInfo(QString id, QString name, QString dept);

    void setID(QString id);
    void setName(QString name);
    void setDept(QString dept);

    const QString getID(void) const;
    const QString getName(void) const;
    const QString getDept(void) const;

    void ManagerInfoDisplay(void);

private:
    QString m_id;
    QString m_name;
    QString m_dept;
};

typedef QList<ManagerInfo> ManagerInfoList;
typedef QMap<QString, ManagerInfoList::iterator> ManagerInfoMap;

#endif // MANAGERINFO_H
