#include "vacationmsform.h"
#include "ui_vacationmsform.h"

#include <QDebug>
#include "globalvars.h"

VacationMSForm::VacationMSForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VacationMSForm)
{
    ui->setupUi(this);
    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");
}

VacationMSForm::~VacationMSForm()
{
    delete ui;
}

void VacationMSForm::slotStaffVacationApply(void)
{
    updateTableInfos();
}

void VacationMSForm::updateTableInfos(void)
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(7);

    QStringList header;
    header << "员工号" << "员工姓名"  << "员工部门" << "经理编号" << "请假日期" << "请假原因" << "是否批准(0否1批)";
    ui->tableWidget->setHorizontalHeaderLabels(header);
    ui->tableWidget->setRowCount(GlobalVars::g_vacationInfoList->length());

    for(int i = 0; i < GlobalVars::g_vacationInfoList->length(); i++)
    {
        QTableWidgetItem *item = new QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getID());
        ui->tableWidget->setItem(i,0,item);
        item = new QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getName());
        ui->tableWidget->setItem(i,1,item);
        item = new QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getDept());
        ui->tableWidget->setItem(i,2,item);
        item = new QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getManagerID());
        ui->tableWidget->setItem(i,3,item);
        item = new QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getVacationDate());
        ui->tableWidget->setItem(i,4,item);
        item = new QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getVacationReason());
        ui->tableWidget->setItem(i,5,item);
        item = new QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getVacationFlag());
        ui->tableWidget->setItem(i,6,item);
    }
}

void VacationMSForm::on_tableWidget_clicked(const QModelIndex &index)
{
    GlobalVars::g_currentVacationInfo = GlobalVars::g_vacationInfoList->at(index.row());
}

void VacationMSForm::on_pb_agree_clicked()
{
    GlobalVars::g_vacationInfoList->removeOne(GlobalVars::g_currentVacationInfo);
    GlobalVars::g_currentVacationInfo.setVacationFlag("1");

    emit signalVacationApplyAgree();
    updateTableInfos();
}

void VacationMSForm::on_pb_reject_clicked()
{
    GlobalVars::g_vacationInfoList->removeOne(GlobalVars::g_currentVacationInfo);
    GlobalVars::g_currentVacationInfo.setVacationFlag("0");

    emit signalVacationApplyReject();
    updateTableInfos();
}
