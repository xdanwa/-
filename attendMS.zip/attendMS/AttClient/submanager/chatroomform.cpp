#include "chatroomform.h"
#include "ui_chatroomform.h"

#include "globalvars.h"

#include <QMessageBox>
#include <QStringBuilder>

ChatRoomForm::ChatRoomForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChatRoomForm)
{
    ui->setupUi(this);
    ui->tw_groupBulletin->setStyleSheet("background-color:rgba(0,0,0,0)");
    ui->lw_groupMember->setStyleSheet("background-color:rgba(0,0,0,0)");
    ui->te_chatRecord->setStyleSheet("background-color:rgba(0,0,0,0)");
    ui->te_sendContent->setStyleSheet("background-color:rgba(0,0,0,0)");
}

ChatRoomForm::~ChatRoomForm()
{
    delete ui;
}

void ChatRoomForm::updateGroupBulletin()
{
    ui->tw_groupBulletin->clear();
    ui->tw_groupBulletin->setColumnCount(2);

    // set header lables
    QStringList headers;
    headers << "日期" << "内容";
    ui->tw_groupBulletin->setHorizontalHeaderLabels(headers);
    ui->tw_groupBulletin->setRowCount(GlobalVars::g_localGroupBulletinList->length());
    for(int i=0; i < GlobalVars::g_localGroupBulletinList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_localGroupBulletinList->at(i).getdateTime());
        ui->tw_groupBulletin->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_localGroupBulletinList->at(i).getContent());
        ui->tw_groupBulletin->setItem(i, 1, item);
    }
}

void ChatRoomForm::updateGroupMember()
{
    ui->lw_groupMember->clear();
    int i = 0;

    for(QMap<QString, QString>::iterator it = GlobalVars::g_groupMemberMap.begin();
          it != GlobalVars::g_groupMemberMap.end(); it++)
    {
        QListWidgetItem *item = new QListWidgetItem;
        item->setText(it.key() + it.value());
        if(it.value() == "[在线]")
        {
           item->setTextColor(QColor(0, 255, 0, 255));
        }else
        {
           item->setTextColor(QColor(255, 255, 255, 255));
        }

        ui->lw_groupMember->insertItem(i++,item);
    }
}

void ChatRoomForm::updateGroupMessage()
{
    ui->te_chatRecord->clear();
    for(int i = 0; i < GlobalVars::g_localChatRecordList->length(); i++)
    {
        QString line = GlobalVars::g_localChatRecordList->at(i).getdateTime()
                % "\n" % GlobalVars::g_localChatRecordList->at(i).getName() % " : "
                % GlobalVars::g_localChatRecordList->at(i).getContent();

        ui->te_chatRecord->append(line);
    }
}

void ChatRoomForm::slotShowGroupBulletin(void)
{
    updateGroupBulletin();
}

void ChatRoomForm::slotUpdateGroupBulletin(void)
{
    updateGroupBulletin();
}

void ChatRoomForm::slotUpdateGroupMessage(void)
{
    updateGroupMessage();
}

void ChatRoomForm::slotShowGroupMember(void)
{
    updateGroupMember();
}

void ChatRoomForm::slotNewClientOnline(QString name)
{
    GlobalVars::g_groupMemberMap[name] = "[在线]";
    updateGroupMember();
}

void ChatRoomForm::slotClientOffline(QString name)
{
    GlobalVars::g_groupMemberMap[name] = "[离线]";
    updateGroupMember();
}

void ChatRoomForm::on_pb_publishBulletin_clicked()
{
    if(GlobalVars::g_localUser.getRole() == "员工")
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("你无权限发布公告!");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
    }else
    {
        emit signalPublishBulletin(m_dateTime.currentDateTime().toString(), ui->te_sendContent->document()->toPlainText());

        ui->te_sendContent->clear();
    }
}

void ChatRoomForm::on_pb_send_clicked()
{
    emit signalSendGroupMessage(m_dateTime.currentDateTime().toString(), ui->te_sendContent->document()->toPlainText());

    ui->te_sendContent->clear();
}
