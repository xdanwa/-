#ifndef CHATROOMFORM_H
#define CHATROOMFORM_H

#include <QWidget>
#include <QDateTime>

namespace Ui {
class ChatRoomForm;
}

class ChatRoomForm : public QWidget
{
    Q_OBJECT

public:
    explicit ChatRoomForm(QWidget *parent = 0);
    ~ChatRoomForm();

signals:
    void signalPublishBulletin(QString dateTime, QString data);  //群主发布新公告
    void signalSendGroupMessage(QString dataTime, QString data);  //群成员发布消息

public slots:
    void slotShowGroupBulletin(void);  //把获取的群公告显示到界面上！
    void slotUpdateGroupBulletin(void); //把刚刚发布的群公告显示到界面上！

    void slotShowGroupMember(void);    //把获取的群成员信息显示到界面上！
    void slotNewClientOnline(QString name);  //新的客户端上线
    void slotClientOffline(QString name);    //客户端下线
    void slotUpdateGroupMessage(void);      //更新群消息

private slots:
    void on_pb_publishBulletin_clicked();

    void on_pb_send_clicked();

private:
    Ui::ChatRoomForm *ui;

    QDateTime m_dateTime;

    void updateGroupBulletin();
    void updateGroupMember();
    void updateGroupMessage();
};

#endif // CHATROOMFORM_H
