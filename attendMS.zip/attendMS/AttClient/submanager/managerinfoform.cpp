#include "managerinfoform.h"
#include "ui_managerinfoform.h"

ManagerInfoForm::ManagerInfoForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ManagerInfoForm)
{
    ui->setupUi(this);
}

ManagerInfoForm::~ManagerInfoForm()
{
    delete ui;
}

void ManagerInfoForm::slotGainManagerInfo(bool res)
{
    if(res)
    {
        ui->le_id->setText(GlobalVars::g_localManager.getID());
        ui->le_name->setText(GlobalVars::g_localManager.getName());
        ui->le_dept->setText(GlobalVars::g_localManager.getDept());
        ui->le_date->setText(GlobalVars::g_localUser.getDate());
    }

    emit signalGainStaffVacationApplyInfo();   //获取经理信息后
                                               //获取员工请假信息
}
