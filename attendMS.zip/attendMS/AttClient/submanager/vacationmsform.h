#ifndef VACATIONMSFORM_H
#define VACATIONMSFORM_H

#include <QWidget>

namespace Ui {
class VacationMSForm;
}

class VacationMSForm : public QWidget
{
    Q_OBJECT

public:
    explicit VacationMSForm(QWidget *parent = 0);
    ~VacationMSForm();

signals:

    void signalVacationApplyAgree(void);
    void signalVacationApplyReject(void);

public slots:
    void slotStaffVacationApply(void);

private slots:
    void on_tableWidget_clicked(const QModelIndex &index);

    void on_pb_agree_clicked();

    void on_pb_reject_clicked();

private:
    Ui::VacationMSForm *ui;

    void updateTableInfos(void);
};

#endif // VACATIONMSFORM_H
