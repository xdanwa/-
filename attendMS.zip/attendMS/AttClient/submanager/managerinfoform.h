#ifndef MANAGERINFOFORM_H
#define MANAGERINFOFORM_H

#include <QWidget>

#include "globalvars.h"

namespace Ui {
class ManagerInfoForm;
}

class ManagerInfoForm : public QWidget
{
    Q_OBJECT

public:
    explicit ManagerInfoForm(QWidget *parent = 0);
    ~ManagerInfoForm();

private:
    Ui::ManagerInfoForm *ui;

signals:

    void signalGainStaffVacationApplyInfo(void);

public slots:
    void slotGainManagerInfo(bool res);
};

#endif // MANAGERINFOFORM_H
