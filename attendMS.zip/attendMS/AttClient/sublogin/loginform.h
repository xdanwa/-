#ifndef LOGINFORM_H
#define LOGINFORM_H

#include <QWidget>
#include <QCloseEvent>

namespace Ui {
class LoginForm;
}

class LoginForm : public QWidget
{
    Q_OBJECT
signals:
    void signalUserLogin(QString id, QString pswd);
    void signalUserLogout(void);
    void signalUserRegister(void);

private slots:
    void on_pb_login_clicked();

    void on_pb_register_clicked();

protected:
    void closeEvent(QCloseEvent *ev);
    void paintEvent(QPaintEvent *);

public:
    explicit LoginForm(QWidget *parent = 0);
    ~LoginForm();

    void userLoginFail(void);

private:
    Ui::LoginForm *ui;
};

#endif // LOGINFORM_H
