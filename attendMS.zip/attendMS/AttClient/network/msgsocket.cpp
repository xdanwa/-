#include "msgsocket.h"

#include <QDebug>
#include <QMessageBox>
#include "globalvars.h"

MsgSocket::MsgSocket(QThread *parent) : QThread(parent)
{
    m_isExit = false;
    m_tcpBlockSize = 0;
    m_tcpSocket = new QTcpSocket(this);

    connect(m_tcpSocket, SIGNAL(readyRead()),
            this, SLOT(slotReadyRead()));

    m_tcpSocket->connectToHost("127.0.0.1", 55555);
}

MsgSocket::~MsgSocket()
{

}

void MsgSocket::exitThread(void)
{
    m_isExit = true;
}

void MsgSocket::run()
{
    while(!m_isExit)
    {
        if(!GlobalVars::g_msgQueue.isEmpty())
        {
            QString msg = GlobalVars::g_msgQueue.dequeue();
            parseUserAsk(msg);
        }
        msleep(20);
    }
}

void MsgSocket::slotReadyRead()
{

    QDataStream in(m_tcpSocket);
    in.setVersion(QDataStream::Qt_4_6);

    if(m_tcpBlockSize == 0)
    {
        if(m_tcpSocket->bytesAvailable()<sizeof(quint16))
            return;

        in >> m_tcpBlockSize;
    }

    if(m_tcpSocket->bytesAvailable() < m_tcpBlockSize)
        return;

    QString msg;
    in >> msg;
    qDebug() << "Client Recv: " << msg;
    GlobalVars::g_msgQueue.enqueue(msg);
    m_tcpBlockSize = 0;
}

void MsgSocket::slotSendMsg(QString msg)
{
    QByteArray buffer;
    QDataStream out(&buffer, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_6);

    out << (quint16)0;
    out << msg;
    out.device()->seek(0);
    out << (quint16)(buffer.size() - sizeof(quint16));

    qDebug() << "Client Send: " << msg;
    m_tcpSocket->write(buffer);
}

void MsgSocket::parseUserAsk(QString msg)
{
    QStringList list = msg.split("#");
    int cmd = msg.at(0).toLatin1();
    switch (cmd) {
    case CMD_UserLogin_L: parseUserLogin(list.at(1)); break;
    case CMD_UserInfo_I: parseUserInfo(list.at(1)); break;
    case CMD_ChangePswd_H: parseChangePswd(list.at(1)); break;
    case CMD_UserExit_X: parseUserExit(list.at(1)); break;
    case CMD_NewClientOnline_N: parseNewClientOnline(list.at(1)); break;
    case CMD_ClientOffline_F: parseClientOffline(list.at(1)); break;

    case CMD_GainGroupBulletin_B: parseUserGainGroupBulletin(list.at(1)); break;   //用户获取群组信息！
    case CMD_PublishGroupBulletin_P: parsePublishGroupBulletin(list.at(1)); break;  //用户获取群主新发布的群公告！
    case CMD_GainGroupMember_M: parseGainGroupMember(list.at(1)); break;            //用户获取群成员
    case CMD_SendGroupMessage_S: parseUserSendGroupMessage(list.at(1)); break;      //用户发送群消息

    case CMD_StaffVacation_V: parseVacationApply(list.at(1)); break;    //经理在线，直接接受请假信息！
    case CMD_GainVacationApplyInfo_G: parseGainVacationApplyInfo(list.at(1)); break;  //经理不在线，上线主动获取！
    case CMD_VacationAgree_A: parseVacationAgree(list.at(1)); break;
    case CMD_VacationReject_J: parseVacationReject(list.at(1)); break;

    case CMD_ObtainStaffAttendanceInfo_O: parseStaffAttendanceInfo(list.at(1)); break;

    default:
        break;
    }
}

///////////////////解析用户请求命令////////////////////////////////

void MsgSocket::parseUserLogin(QString data)
{
    qDebug() << "MsgSocket::parseUserLogin" << data;
    QStringList list = data.split("|");
    int res = data.at(0).toLatin1();
    if(RES_Down == res)
    {
        GlobalVars::g_localUser.setID(list.at(1));
        GlobalVars::g_localUser.setPswd(list.at(2));
        GlobalVars::g_localUser.setRole(list.at(3));
        GlobalVars::g_localUser.setDate(list.at(4));
        emit signalUserLoginResult(true);
    }else
    {
        emit signalUserLoginResult(false);
    }
}

void MsgSocket::parseUserInfo(QString data)
{
    qDebug() << "MsgSocket::parseUserInfo" << data;
    QStringList list = data.split("|");
    int res = data.at(0).toLatin1();
    if(RES_Down == res)
    {
        if(GlobalVars::g_localUser.getRole() == "经理")
        {
            GlobalVars::g_localManager.setID(list.at(1));
            GlobalVars::g_localManager.setName(list.at(2));
            GlobalVars::g_localManager.setDept(list.at(3));
            emit signalGainManagerInfo(true);     
        }else
        {
            GlobalVars::g_localStaff.setID(list.at(1));
            GlobalVars::g_localStaff.setName(list.at(2));
            GlobalVars::g_localStaff.setDept(list.at(3));
            GlobalVars::g_localStaff.setPost(list.at(4));

            if(GlobalVars::g_localStaff.getDept() == "人事部")
            {
                GlobalVars::g_localManager.setID("MN-101");
            }else if(GlobalVars::g_localStaff.getDept() == "财务部")
            {
                GlobalVars::g_localManager.setID("MN-102");
            }else if(GlobalVars::g_localStaff.getDept() == "开发部")
            {
                GlobalVars::g_localManager.setID("MN-103");
            }else if(GlobalVars::g_localStaff.getDept() == "测试部")
            {
                GlobalVars::g_localManager.setID("MN-104");
            }else if(GlobalVars::g_localStaff.getDept() == "业务部")
            {
                GlobalVars::g_localManager.setID("MN-105");
            }

            emit signalGainStaffInfo(true);
        }
    }
}

void MsgSocket::parseChangePswd(QString data)
{
    qDebug() << "MsgSocket::parseChangePswd" << data;
    QStringList list = data.split("|");
    int res = data.at(0).toLatin1();

    if(res == RES_Down)
    {
        emit signalUserChangerPswdResult(true);
    }else
    {
        emit signalUserChangerPswdResult(false);
    }

}

void MsgSocket::parseUserExit(QString data)
{
    QStringList list = data.split("|");
    int res = data.at(0).toLatin1();
    QString uid = list.at(1);
    if((RES_Down == res)&&(uid == GlobalVars::g_localUser.getID()))
    {
        emit signalUserLogoutResult(true);
    }
}

void MsgSocket::parseUserRegister(QString data)
{

}

void MsgSocket::parseNewClientOnline(QString data)
{
    qDebug() << "MsgSocket::parseNewClientOnline" << data;

    QString name = data;
    emit signalNewClientOnline(name);
}

void MsgSocket::parseClientOffline(QString data)
{
    qDebug() << "MsgSocket::parseClientOffline" << data;

    QString name = data;
    emit signalClientOffline(name);
}

void MsgSocket::parseUserGainGroupBulletin(QString data)
{
    qDebug() << "MsgSocket::parseUserGainGroupBulletin" << data;

    QStringList listInfo = data.split("$");

    for(int i = 0; i < listInfo.length()-1; i++)
    {
        QStringList list = listInfo.at(i).split("|");

        QString dataTime = list.at(0);
        QString content = list.at(1);

        AnnouncementInfo info("1", "2", "3", dataTime, content);

        GlobalVars::g_localGroupBulletinList->append(info);
    }

    emit signalShowGroupBulletin();

    emit signalGainGroupMember();  //获取完群公告之后获取群成员列表
}

void MsgSocket::parsePublishGroupBulletin(QString data)
{
    qDebug() << "MsgSocket::parsePublishGroupBulletin" << data;

    QStringList list = data.split("|");

    QString id = list.at(0);
    QString name = list.at(1);
    QString dept = list.at(2);
    QString dateTime = list.at(3);
    QString content = list.at(4);

    AnnouncementInfo info(id, name, dept, dateTime, content);

    GlobalVars::g_localGroupBulletinList->append(info);

    emit signalUpdateGroupBlletin();
}

void MsgSocket::parseUserSendGroupMessage(QString data)
{
    qDebug() << "MsgSocket::parseUserSendGroupMessage" << data;

    QStringList list = data.split("|");

    QString id = list.at(0);
    QString name = list.at(1);
    QString dept = list.at(2);
    QString dateTime = list.at(3);
    QString content = list.at(4);

    ChatRecordInfo info(id, name, dept, dateTime, content);
    GlobalVars::g_localChatRecordList->append(info);

    emit signalUpdateGroupMessage();
}

void MsgSocket::parseGainGroupMember(QString data)
{
    qDebug() << "MsgSocket::parseGainGroupMember" << data;

    QStringList listInfo = data.split("$");

    for(int i = 0; i < listInfo.length()-1; i++)
    {
        QStringList list = listInfo.at(i).split("|");

        QString name = list.at(0);
        QString state = list.at(1);

        GlobalVars::g_groupMemberMap[name] = state;
    }

    emit signalShowGroupMember();
}

///////////////////解析员工请求命令////////////////////////////////

void MsgSocket::parseVacationApply(QString data)
{
    qDebug() << "MsgSocket::parseVacationApply" << data;

    QStringList list = data.split("|");

    QString staffID = list.at(0);
    QString staffName = list.at(1);
    QString staffDept = list.at(2);
    QString managerID = list.at(3);
    QString vacationDate = list.at(4);
    QString vacationReason = list.at(5);
    QString flag = list.at(6);

    VacationInfo info(staffID, staffName, staffDept,
                      managerID, vacationDate, vacationReason,flag);

    GlobalVars::g_vacationInfoList->append(info);

    emit signalStaffVacationApply();    //经理在线直接发送；
}

void MsgSocket::parseStaffAttendanceInfo(QString data)
{
    qDebug() << "MsgSocket::parseStaffAttendanceInfo" << data;

    QStringList listInfo = data.split("$");

    for(int i = 0; i < listInfo.length()-1; i++)
    {
        QStringList list = listInfo.at(i).split("|");

        QString staffID = list.at(0);
        QString staffName = list.at(1);
        QString staffDept = list.at(2);
        QString workTime = list.at(3);
        QString endTime = list.at(4);
        QString date = list.at(5);

        AttendanceInfo info(staffID, staffName, staffDept,
                            workTime, endTime, date);

        GlobalVars::g_localStaffAttendanceInfoList->append(info);
    }

    emit signalShowStaffAttendanceInfo();

    emit signalGainGroupBulletin();    //获取完打卡信息后，获取群组公告信息！
}

void MsgSocket::parseVacationAgree(QString data)
{
    qDebug() << "MsgSocket::parseVacationAgree" << data;
    emit signalStaffVacationAgreed();
}

void MsgSocket::parseVacationReject(QString data)
{
    qDebug() << "MsgSocket::parseVacationReject" << data;
    emit signalStaffVacationRejected();
}

////////////////////////解析经理请求命令////////////////////////////////

void MsgSocket::parseGainVacationApplyInfo(QString data)
{
    qDebug() << "MsgSocket::parseGainVacationApplyInfo" << data;

    QStringList infoList = data.split("$");

    for(int i = 0; i < infoList.length() - 1; i++)
    {
        QStringList list = infoList.at(i).split("|");

        QString staffID = list.at(0);
        QString staffName = list.at(1);
        QString staffDept = list.at(2);
        QString managerID = list.at(3);
        QString vacationDate = list.at(4);
        QString vacationReason = list.at(5);
        QString vacationFlag = list.at(6);

        VacationInfo info(staffID, staffName, staffDept, managerID,
                          vacationDate, vacationReason, vacationFlag);

        GlobalVars::g_vacationInfoList->append(info);
    }

    emit signalStaffVacationApply();   //把员工请假信息显示到界面上！

    emit signalGainGroupBulletin();    //获取完请假信息后，获取群组公告信息！
}

