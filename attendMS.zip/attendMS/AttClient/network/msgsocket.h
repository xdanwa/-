#ifndef MSGSOCKET_H
#define MSGSOCKET_H

#include <QObject>
#include <QTcpSocket>
#include <QThread>

class MsgSocket : public QThread
{
    Q_OBJECT

signals:
    void signalUserLoginResult(bool res);
    void signalUserLogoutResult(bool res);
    void signalGainManagerInfo(bool res);
    void signalGainStaffInfo(bool res);

    void signalUserChangerPswdResult(bool res);

    void signalStaffVacationApply(void);
    void signalStaffVacationAgreed(void);
    void signalStaffVacationRejected(void);

    void signalShowStaffAttendanceInfo(void);

    void signalGainGroupBulletin(void);   //获取群组公告
    void signalShowGroupBulletin(void);  //把获取的群公告显示到界面上！
    void signalUpdateGroupBlletin(void);  //更新刚刚发布的群公告！

    void signalGainGroupMember(void);    //获取群成员
    void signalShowGroupMember(void);    //把获取的群成员信息显示到界面上
    void signalNewClientOnline(QString name);  //有新的客户端上线
    void signalClientOffline(QString name);    //有客户端下线
    void signalUpdateGroupMessage(void);       //更新刚刚发布的群消息

public slots:
    void slotReadyRead();
    void slotSendMsg(QString msg);

public:
    explicit MsgSocket(QThread *parent = 0);
    ~MsgSocket();

    void exitThread(void);

protected:
    void run();

private:
    bool m_isExit;
    quint16 m_tcpBlockSize;
    QTcpSocket *m_tcpSocket;

    void parseUserAsk(QString msg);

    ///解析通用请求命令
    void parseUserLogin(QString data);
    void parseUserInfo(QString data);
    void parseChangePswd(QString data);
    void parseUserExit(QString data);
    void parseUserRegister(QString data);
    void parseNewClientOnline(QString data);
    void parseClientOffline(QString data);

    void parseUserGainGroupBulletin(QString data);
    void parsePublishGroupBulletin(QString data);
    void parseGainGroupMember(QString data);
    void parseUserSendGroupMessage(QString data);

    ///解析员工命令
    void parseVacationApply(QString data);
    void parseVacationAgree(QString data);
    void parseVacationReject(QString data);

    void parseStaffAttendanceInfo(QString data);

    ///解析经理命令
    void parseGainVacationApplyInfo(QString data);

};

#endif // MSGSOCKET_H
