#include "globalvars.h"

UserInfo GlobalVars::g_localUser;
StaffInfo GlobalVars::g_localStaff;
ManagerInfo GlobalVars::g_localManager;

AttendanceInfoList* GlobalVars::g_localStaffAttendanceInfoList = new AttendanceInfoList;

AnnouncementInfoList *GlobalVars::g_localGroupBulletinList = new AnnouncementInfoList;
ChatRecordInfoList *GlobalVars::g_localChatRecordList = new ChatRecordInfoList;

VacationInfoList* GlobalVars::g_vacationInfoList = new VacationInfoList;
VacationInfo GlobalVars::g_currentVacationInfo;

QList<QString> GlobalVars::g_groupMemberList;
QMap<QString, QString> GlobalVars::g_groupMemberMap;

QQueue<QString> GlobalVars::g_msgQueue;
