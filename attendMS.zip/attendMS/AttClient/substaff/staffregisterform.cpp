#include "staffregisterform.h"
#include "ui_staffregisterform.h"

#include "userinfo.h"
#include "staffinfo.h"

#include <QMessageBox>

StaffRegisterForm::StaffRegisterForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StaffRegisterForm)
{
    ui->setupUi(this);
}

StaffRegisterForm::~StaffRegisterForm()
{
    delete ui;
}

const QString StaffRegisterForm::getUserID(void) const
{
    return ui->le_id->text();
}

const QString StaffRegisterForm::getUserName(void) const
{
    return ui->le_name->text();
}

const QString StaffRegisterForm::getUserPswd(void) const
{
    return ui->le_pswd->text();
}

const QString StaffRegisterForm::getUserDept(void) const
{
    return ui->le_dept->text();
}

const QString StaffRegisterForm::getUserDate(void) const
{
    return ui->le_date->text();
}


void StaffRegisterForm::on_pb_register_clicked()
{   

    if(ui->le_id->text() == "")
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("员工号不能为空，请输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();

    }else if(ui->le_name->text() == "")
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("姓名不能为空，请输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();

    }else if(ui->le_pswd->text() == "")
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("密码不能为空，请输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();

    }else if(ui->le_dept->text() == "")
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("部门不能为空，请输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();

    }else if(ui->le_date->text() == "")
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("注册日期不能为空，请输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();

    }else
    {
        emit signalRegister();

        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("注册成功，请登录!");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Ok);

        int res = msgBox.exec();
        switch (res)
        {
            case QMessageBox::Ok: emit signalRegisterRelogin(true); break;
            case QMessageBox::Close: break;
            default:  break;
        }
    }
}

void StaffRegisterForm::on_pb_cancle_clicked()
{
    ui->le_date->clear();
    ui->le_dept->clear();
    ui->le_id->clear();
    ui->le_name->clear();
    ui->le_pswd->clear();
}
