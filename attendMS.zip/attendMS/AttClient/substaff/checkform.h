#ifndef CHECKFORM_H
#define CHECKFORM_H

#include <QWidget>
#include <QTime>
#include <QDate>

namespace Ui {
class CheckForm;
}

class CheckForm : public QWidget
{
    Q_OBJECT

public:
    explicit CheckForm(QWidget *parent = 0);
    ~CheckForm();

signals:
    void signalWorkTime(QString workTime, QString endTime, QString date);
    void signalEndTime(QString workTime, QString endTime, QString date);

private slots:
    void on_pb_startWork_clicked();

    void on_pb_endWork_clicked();

private:
    Ui::CheckForm *ui;

    QDate m_date;
    QTime m_startTime;
    QTime m_endTime;
};

#endif // CHECKFORM_H
