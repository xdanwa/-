#include "checkform.h"
#include "ui_checkform.h"

#include <QMessageBox>

CheckForm::CheckForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CheckForm)
{
    ui->setupUi(this);
}

CheckForm::~CheckForm()
{
    delete ui;
}

void CheckForm::on_pb_startWork_clicked()
{
    if(ui->le_workTime->text() == "")
    {
        ui->le_workTime->setText(m_startTime.currentTime().toString());

        emit signalWorkTime(ui->le_workTime->text(),
                            ui->le_endTime->text(),
                            m_date.currentDate().toString(Qt::ISODate));
    }else
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("你已打卡，请勿重复打卡!");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
    }

}

void CheckForm::on_pb_endWork_clicked()
{
    if(ui->le_endTime->text() == "")
    {
        ui->le_endTime->setText(m_endTime.currentTime().toString());

        emit signalEndTime(ui->le_workTime->text(),
                           ui->le_endTime->text(),
                           m_date.currentDate().toString(Qt::ISODate));
    }else
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("你已打卡，请勿重复打卡!");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
    }
}
