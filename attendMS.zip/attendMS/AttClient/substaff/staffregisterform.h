#ifndef STAFFREGISTERFORM_H
#define STAFFREGISTERFORM_H

#include <QWidget>

namespace Ui {
class StaffRegisterForm;
}

class StaffRegisterForm : public QWidget
{
    Q_OBJECT

signals:

    void signalRegister(void);
    void signalRegisterRelogin(bool res);

public:
    explicit StaffRegisterForm(QWidget *parent = 0);
    ~StaffRegisterForm();

    const QString getUserID(void) const;
    const QString getUserName(void) const;
    const QString getUserPswd(void) const;
    const QString getUserDept(void) const;
    const QString getUserDate(void) const;


private slots:
    void on_pb_register_clicked();

    void on_pb_cancle_clicked();

private:
    Ui::StaffRegisterForm *ui;
};

#endif // STAFFREGISTERFORM_H
