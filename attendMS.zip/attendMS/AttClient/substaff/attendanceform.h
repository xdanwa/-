#ifndef ATTENDANCEFORM_H
#define ATTENDANCEFORM_H

#include <QWidget>

namespace Ui {
class AttendanceForm;
}

class AttendanceForm : public QWidget
{
    Q_OBJECT

public:
    explicit AttendanceForm(QWidget *parent = 0);
    ~AttendanceForm();

public slots:
    void slotShowStaffAttendanceInfo(void);

private:
    Ui::AttendanceForm *ui;

    void updateTableInfos(void);
};

#endif // ATTENDANCEFORM_H
