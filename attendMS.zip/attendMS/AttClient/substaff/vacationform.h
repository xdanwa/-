#ifndef VACATIONFORM_H
#define VACATIONFORM_H

#include <QWidget>
#include <QDate>

namespace Ui {
class VacationForm;
}

class VacationForm : public QWidget
{
    Q_OBJECT

public:
    explicit VacationForm(QWidget *parent = 0);
    ~VacationForm();

signals:
    void signalVacationApply(QString vacationReason, QString vacationDate);

public slots:
    void slotStaffVacationAgreed(void);
    void slotStaffVacationRejected(void);

private slots:
    void on_pb_vacationApply_clicked();

private:
    Ui::VacationForm *ui;

    QDate m_date;
};

#endif // VACATIONFORM_H
