﻿#include "vacationform.h"
#include "ui_vacationform.h"

#include <QMessageBox>

VacationForm::VacationForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VacationForm)
{
    ui->setupUi(this);
    ui->le_vacationReason->setEnabled(true);
}

VacationForm::~VacationForm()
{
    delete ui;
}

void VacationForm::on_pb_vacationApply_clicked()
{
    if(ui->le_vacationReason->text() == "")
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("请假原因不能为空，请重新输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();
    }else
    {
        emit signalVacationApply(ui->le_vacationReason->text(), m_date.currentDate().toString(Qt::ISODate));

        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("请假申请已向经理发送，请等待批准!");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
    }

    ui->le_vacationReason->clear();
    ui->le_vacationReason->setEnabled(false);
}

void VacationForm::slotStaffVacationAgreed(void)
{
    QMessageBox msgBox(this);
    msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
    msgBox.setInformativeText("请假申请已被经理批准，请按时上班!");
    msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
    msgBox.setDefaultButton(QMessageBox::Ok);
    msgBox.exec();
}

void VacationForm::slotStaffVacationRejected(void)
{
    QMessageBox msgBox(this);
    msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
    msgBox.setInformativeText("请假申请已被经理拒绝，请继续上班!");
    msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
    msgBox.setDefaultButton(QMessageBox::Ok);
    msgBox.exec();
}
