#ifndef STAFFCHANGEPSWDFORM_H
#define STAFFCHANGEPSWDFORM_H

#include <QWidget>
#include <QMessageBox>

#include "globalvars.h"

namespace Ui {
class StaffChangePswdForm;
}

class StaffChangePswdForm : public QWidget
{
    Q_OBJECT

signals:
    void signalStaffChangePswd(QString newPswd);
    void signalRelogin(bool res);

public:
    explicit StaffChangePswdForm(QWidget *parent = 0);
    ~StaffChangePswdForm();

public slots:
    void slotUserChangerPswdResult(bool res);

private slots:
    void on_pb_changePswd_clicked();



private:
    Ui::StaffChangePswdForm *ui;
};

#endif // STAFFCHANGEPSWDFORM_H
