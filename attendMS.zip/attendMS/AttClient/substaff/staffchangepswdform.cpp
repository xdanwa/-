#include "staffchangepswdform.h"
#include "ui_staffchangepswdform.h"

StaffChangePswdForm::StaffChangePswdForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StaffChangePswdForm)
{
    ui->setupUi(this);
}

StaffChangePswdForm::~StaffChangePswdForm()
{
    delete ui;
}

void StaffChangePswdForm::on_pb_changePswd_clicked()
{
    if(ui->le_usedPswd->text() != GlobalVars::g_localUser.getPswd())
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("原密码输入错误，请重新输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();
    }else if(ui->le_newPswd->text() != ui->le_confirmPswd->text())
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("新密码与确认密码不一致，请重新输入!");
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Retry);
        msgBox.exec();
    }else
    {
        emit signalStaffChangePswd(ui->le_newPswd->text());
    }
}

void StaffChangePswdForm::slotUserChangerPswdResult(bool res)
{
    if(res)
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("密码修改正确，请重新登录!");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Ok);

        int res = msgBox.exec();
        switch (res)
        {
            case QMessageBox::Ok: emit signalRelogin(true); break;
            case QMessageBox::Close: break;
            default:  break;
        }
    }else
    {
        QMessageBox msgBox(this);
        msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
        msgBox.setInformativeText("密码修改错误，请重新修改!");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Close);
        msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();
    }
}
