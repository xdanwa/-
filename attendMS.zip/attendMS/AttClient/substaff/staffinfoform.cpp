#include "staffinfoform.h"
#include "ui_staffinfoform.h"

StaffInfoForm::StaffInfoForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StaffInfoForm)
{
    ui->setupUi(this);
}

StaffInfoForm::~StaffInfoForm()
{
    delete ui;
}

void StaffInfoForm::slotGainStaffInfo(bool res)
{
    if(res)
    {
        ui->le_id->setText(GlobalVars::g_localStaff.getID());
        ui->le_name->setText(GlobalVars::g_localStaff.getName());
        ui->le_post->setText(GlobalVars::g_localStaff.getPost());
        ui->le_dept->setText(GlobalVars::g_localStaff.getDept());
        ui->le_date->setText(GlobalVars::g_localUser.getDate());
    }

    emit signalObtainStaffAttendanceInfo(); //获取完员工的信息之后
                                            //获取员工打卡信息
}
