#ifndef STAFFINFOFORM_H
#define STAFFINFOFORM_H

#include <QWidget>

#include "globalvars.h"

namespace Ui {
class StaffInfoForm;
}

class StaffInfoForm : public QWidget
{
    Q_OBJECT

public:
    explicit StaffInfoForm(QWidget *parent = 0);
    ~StaffInfoForm();

signals:

    void signalObtainStaffAttendanceInfo(void);

private:
    Ui::StaffInfoForm *ui;

public slots:
    void slotGainStaffInfo(bool res);
};

#endif // STAFFINFOFORM_H
