#include "attclient.h"
#include "ui_attclient.h"

#include "globalvars.h"

#include <QStringBuilder>
#include <QDebug>
#include <QMessageBox>
#include <QPaintEvent>
#include <QPainter>
#include <QPixmap>

AttClient::AttClient(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AttClient)
{
    ui->setupUi(this);
    ui->menuBar->hide();
    ui->statusBar->hide();
    ui->mainToolBar->hide();

    m_isCloseSystem = false;
    m_loginForm = new LoginForm(ui->widget);
    m_staffRegisterForm = new StaffRegisterForm(ui->widget);

    m_managerInfoForm = new ManagerInfoForm(ui->widget);
    m_vacationMSForm = new VacationMSForm(ui->widget);

    m_chatRoomForm = new ChatRoomForm(ui->widget);

    m_checkForm = new CheckForm(ui->widget);
    m_staffInfoForm = new StaffInfoForm(ui->widget);
    m_attendanceForm = new AttendanceForm(ui->widget);
    m_vacationForm = new VacationForm(ui->widget);
    m_staffChangePswdForm = new StaffChangePswdForm(ui->widget);

    m_msgSocket = new MsgSocket;

    ///登录退出的信号与槽
    ///
    connect(m_loginForm, SIGNAL(signalUserLogin(QString,QString)),
            this, SLOT(slotUserLogin(QString,QString)));
    connect(m_msgSocket, SIGNAL(signalUserLoginResult(bool)),
            this, SLOT(slotUserLoginResult(bool)));
    connect(m_loginForm, SIGNAL(signalUserLogout()),
            this, SLOT(slotUserLogout()));
    connect(m_msgSocket, SIGNAL(signalUserLogoutResult(bool)),
            this, SLOT(slotUserLogoutResult(bool)));

    ///群的信号与槽
    ///群公告
    connect(m_msgSocket, SIGNAL(signalGainGroupBulletin()),
            this, SLOT(slotGainGroupBulletin()));
    connect(m_msgSocket, SIGNAL(signalShowGroupBulletin()),
            m_chatRoomForm, SLOT(slotShowGroupBulletin()));
    connect(m_msgSocket, SIGNAL(signalUpdateGroupBlletin()),
            m_chatRoomForm, SLOT(slotUpdateGroupBulletin()));
    connect(m_chatRoomForm, SIGNAL(signalPublishBulletin(QString,QString)),
            this, SLOT(slotPublishBulletin(QString,QString)));
    ///群成员
    connect(m_msgSocket, SIGNAL(signalGainGroupMember()),
            this, SLOT(slotGainGroupMember()));
    connect(m_msgSocket, SIGNAL(signalShowGroupMember()),
            m_chatRoomForm, SLOT(slotShowGroupMember()));
    connect(m_msgSocket, SIGNAL(signalNewClientOnline(QString)),
            m_chatRoomForm, SLOT(slotNewClientOnline(QString)));
    connect(m_msgSocket, SIGNAL(signalClientOffline(QString)),
            m_chatRoomForm, SLOT(slotClientOffline(QString)));
    ///群消息
    connect(m_chatRoomForm, SIGNAL(signalSendGroupMessage(QString,QString)),
            this, SLOT(slotSendGroupMessage(QString,QString)));
    connect(m_msgSocket, SIGNAL(signalUpdateGroupMessage()),
            m_chatRoomForm, SLOT(slotUpdateGroupMessage()));

    m_staffRegisterForm->hide();
    m_managerInfoForm->hide();
    m_vacationMSForm->hide();
    m_chatRoomForm->hide();
    m_checkForm->hide();
    m_staffInfoForm->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_staffChangePswdForm->hide();

    connect(m_loginForm, SIGNAL(signalUserRegister()),
            this, SLOT(slotUserRegister()));

    m_msgSocket->start();
}

AttClient::~AttClient()
{
    delete ui;
}

void AttClient::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    QPixmap pix(":/icons/003.jpg");
    p.drawPixmap(0,0,pix);
}

void AttClient::closeEvent(QCloseEvent *ev)
{
    if(!m_isCloseSystem)
    {
        slotUserLogout();
        ev->ignore();
    }else
    {
        ev->accept();
    }
}

void AttClient::slotGainGroupBulletin(void)
{
    ///用户获取相应群公告的信息
    QString msg = QString(CMD_GainGroupBulletin_B) % QString("#")
            % GlobalVars::g_localManager.getID()
            % QString("|") % GlobalVars::g_localUser.getID();
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotPublishBulletin(QString dateTime, QString data)
{
    ///群主发布群公告！
    QString msg = QString(CMD_PublishGroupBulletin_P) % QString("#")
            % GlobalVars::g_localManager.getID() % QString("|")
            % GlobalVars::g_localManager.getName() % QString("|")
            % GlobalVars::g_localManager.getDept() % QString("|")
            % dateTime % QString("|")
            % data;
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotSendGroupMessage(QString dateTime, QString data)
{
    ///群成员发布群消息
    QString msg;
    if(GlobalVars::g_localManager.getDept() == "")
    {
         msg = QString(CMD_SendGroupMessage_S) % QString("#")
                % GlobalVars::g_localStaff.getID() % QString("|")
                % GlobalVars::g_localStaff.getName() % QString("|")
                % GlobalVars::g_localStaff.getDept() % QString("|")
                % dateTime % QString("|")
                % data;
    }else
    {
        msg = QString(CMD_SendGroupMessage_S) % QString("#")
                % GlobalVars::g_localManager.getID() % QString("|")
                % GlobalVars::g_localManager.getName() % QString("|")
                % GlobalVars::g_localManager.getDept() % QString("|")
                % dateTime % QString("|")
                % data;
    }

    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotGainGroupMember(void)
{
    ///用户获取群成员列表！
    QString msg = QString(CMD_GainGroupMember_M) % QString("#")
            % GlobalVars::g_localUser.getID();
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotUserLogin(QString id, QString pswd)
{
    ///用户登录请求
    QString msg = QString(CMD_UserLogin_L)
            % QString("#") % id
            % QString("|") % pswd;
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotUserLoginResult(bool res)
{
    if(res)
    {
        if(GlobalVars::g_localUser.getRole() == "经理")
        {
            initManagerWidget();

        }else if(GlobalVars::g_localUser.getRole() == "员工")
        {
            initStaffWidget();
        }

        ui->mainToolBar->show();
        m_loginForm->hide();

        ///个人信息请求
        QString msg = QString(CMD_UserInfo_I)
            % QString("#") % GlobalVars::g_localUser.getID()
            % QString("|") % GlobalVars::g_localUser.getRole();
        m_msgSocket->slotSendMsg(msg);
    }else
    {
        m_loginForm->userLoginFail();
    }
}

void AttClient::slotUserLogout(void)
{
    ///用户退出请求
    QString msg = QString(CMD_UserExit_X)
            % QString("#") % GlobalVars::g_localUser.getID();
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotUserLogoutResult(bool res)
{
    m_isCloseSystem = res;
    this->close();
}

void AttClient::slotRelogin(bool res)
{
    if(res)
    {
        ui->mainToolBar->hide();
        ui->menuBar->hide();
        ui->statusBar->hide();

        m_staffInfoForm->hide();
        m_attendanceForm->hide();
        m_vacationForm->hide();
        m_checkForm->hide();
        m_staffChangePswdForm->hide();
        m_loginForm->show();
    }
}

void AttClient::slotUserRegister(void)
{
    ui->mainToolBar->hide();
    ui->menuBar->hide();
    ui->statusBar->hide();

    m_loginForm->hide();
    m_staffRegisterForm->show();

    connect(m_staffRegisterForm, SIGNAL(signalRegister()),
            this, SLOT(slotRegister()));

    connect(m_staffRegisterForm, SIGNAL(signalRegisterRelogin(bool)),
            this, SLOT(slotRegisterRelogin(bool)));
}

void AttClient::slotRegisterRelogin(bool res)
{
    if(res)
    {
        ui->mainToolBar->hide();
        ui->menuBar->hide();
        ui->statusBar->hide();

        m_staffRegisterForm->hide();
        m_loginForm->show();
    }
}

void AttClient::slotRegister(void)
{
    QString msg = QString(CMD_UserRegister_R) % QString("#")
            % QString(m_staffRegisterForm->getUserID()) % QString("|")
            % QString(m_staffRegisterForm->getUserName()) % QString("|")
            % QString(m_staffRegisterForm->getUserPswd()) % QString("|")
            % QString("员工") % QString("|")
            % QString(m_staffRegisterForm->getUserDept()) % QString("|")
            % QString(m_staffRegisterForm->getUserDate());

    m_msgSocket->slotSendMsg(msg);
}

///////////////////////////satffInfo//////////////////////////

void AttClient::on_actionCheck_In_triggered()
{
    m_checkForm->show();
    m_staffInfoForm->hide();
    m_vacationForm->hide();
    m_attendanceForm->hide();
    m_staffChangePswdForm->hide();
    m_chatRoomForm->hide();

    ui->actionCheck_In->setEnabled(false);
    ui->actionAttendance->setEnabled(true);
    ui->actionStaffChangePswd->setEnabled(true);
    ui->actionStaffInfo->setEnabled(true);
    ui->actionVavation->setEnabled(true);
    ui->actionChatRoom->setEnabled(true);
}

void AttClient::on_actionVavation_triggered()
{
    m_vacationForm->show();
    m_checkForm->hide();
    m_staffInfoForm->hide();
    m_attendanceForm->hide();
    m_staffChangePswdForm->hide();
    m_chatRoomForm->hide();

    ui->actionCheck_In->setEnabled(true);
    ui->actionAttendance->setEnabled(true);
    ui->actionStaffChangePswd->setEnabled(true);
    ui->actionStaffInfo->setEnabled(true);
    ui->actionVavation->setEnabled(false);
    ui->actionChatRoom->setEnabled(true);
}

void AttClient::on_actionAttendance_triggered()
{
    m_attendanceForm->show();
    m_vacationForm->hide();
    m_staffInfoForm->hide();
    m_checkForm->hide();
    m_staffChangePswdForm->hide();
    m_chatRoomForm->hide();

    ui->actionCheck_In->setEnabled(true);
    ui->actionAttendance->setEnabled(false);
    ui->actionStaffChangePswd->setEnabled(true);
    ui->actionStaffInfo->setEnabled(true);
    ui->actionVavation->setEnabled(true);
    ui->actionChatRoom->setEnabled(true);
}

void AttClient::on_actionStaffInfo_triggered()
{
    m_staffInfoForm->show();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_checkForm->hide();
    m_staffChangePswdForm->hide();
    m_chatRoomForm->hide();

    ui->actionCheck_In->setEnabled(true);
    ui->actionAttendance->setEnabled(true);
    ui->actionStaffChangePswd->setEnabled(true);
    ui->actionStaffInfo->setEnabled(false);
    ui->actionVavation->setEnabled(true);
    ui->actionChatRoom->setEnabled(true);
}

void AttClient::on_actionStaffChangePswd_triggered()
{
    m_staffInfoForm->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_checkForm->hide();
    m_staffChangePswdForm->show();
    m_chatRoomForm->hide();

    ui->actionCheck_In->setEnabled(true);
    ui->actionAttendance->setEnabled(true);
    ui->actionStaffChangePswd->setEnabled(false);
    ui->actionStaffInfo->setEnabled(true);
    ui->actionVavation->setEnabled(true);
   ui->actionChatRoom->setEnabled(true);
}

void AttClient::initStaffWidget()
{
    this->setWindowTitle(tr("考勤管理系统[员工端]"));
    on_actionCheck_In_triggered();

    ui->mainToolBar->removeAction(ui->actionManagerInfo);
    ui->mainToolBar->removeAction(ui->actionVacationMS);

    connect(m_msgSocket, SIGNAL(signalGainStaffInfo(bool)),
            m_staffInfoForm, SLOT(slotGainStaffInfo(bool)));

    ///修改密码的信号与槽
    connect(m_staffChangePswdForm, SIGNAL(signalStaffChangePswd(QString)),
            this, SLOT(slotStaffChangePswd(QString)));

    connect(m_msgSocket, SIGNAL(signalUserChangerPswdResult(bool)),
            m_staffChangePswdForm, SLOT(slotUserChangerPswdResult(bool)));

    connect(m_staffChangePswdForm, SIGNAL(signalRelogin(bool)),
            this, SLOT(slotRelogin(bool)));

    ///打卡的信号与槽
    connect(m_checkForm, SIGNAL(signalWorkTime(QString,QString,QString)),
            this, SLOT(slotStaffWorkTime(QString,QString,QString)));

    connect(m_checkForm, SIGNAL(signalEndTime(QString,QString,QString)),
            this, SLOT(slotStaffEndTime(QString,QString,QString)));

    connect(m_staffInfoForm, SIGNAL(signalObtainStaffAttendanceInfo()),
            this, SLOT(slotObtainStaffAttendanceInfo()));

    connect(m_msgSocket, SIGNAL(signalShowStaffAttendanceInfo()),
            m_attendanceForm, SLOT(slotShowStaffAttendanceInfo()));

    ///请假的信号与槽
    connect(m_vacationForm, SIGNAL(signalVacationApply(QString,QString)),
            this, SLOT(slotVacationApply(QString,QString)));

    connect(m_msgSocket, SIGNAL(signalStaffVacationAgreed()),
            m_vacationForm, SLOT(slotStaffVacationAgreed()));

    connect(m_msgSocket, SIGNAL(signalStaffVacationRejected()),
            m_vacationForm, SLOT(slotStaffVacationRejected()));

}

void AttClient::slotStaffChangePswd(QString newPswd)
{
    ///用户修改密码请求
    QString msg = QString(CMD_ChangePswd_H)
            % QString("#") % GlobalVars::g_localUser.getID()
            % QString("|") % newPswd;
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotStaffWorkTime(QString workTime, QString endTime, QString date)
{
    ///上班打卡信息发送给服务器
    QString msg = QString(CMD_StaffCheck_C)
            % QString("#") % GlobalVars::g_localStaff.getID()
            % QString("|") % GlobalVars::g_localStaff.getName()
            % QString("|") % GlobalVars::g_localStaff.getDept()
            % QString("|") % workTime
            % QString("|") % endTime
            % QString("|") % date;
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotStaffEndTime(QString workTime, QString endTime, QString date)
{
    ///下班打卡信息发送给服务器
    QString msg = QString(CMD_StaffCheck_C)
            % QString("#") % GlobalVars::g_localStaff.getID()
            % QString("|") % GlobalVars::g_localStaff.getName()
            % QString("|") % GlobalVars::g_localStaff.getDept()
            % QString("|") % workTime
            % QString("|") % endTime
            % QString("|") % date;
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotObtainStaffAttendanceInfo()
{
    ///员工打卡信息的获取
    QString msg = QString(CMD_ObtainStaffAttendanceInfo_O)
            % QString("#") % GlobalVars::g_localStaff.getID();

    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotVacationApply(QString vacationReason, QString vacationDate)
{
    ///假期申请
    QString msg = QString(CMD_StaffVacation_V)
            % QString("#") % GlobalVars::g_localStaff.getID()
            % QString("|") % GlobalVars::g_localStaff.getName()
            % QString("|") % GlobalVars::g_localStaff.getDept()
            % QString("|") % GlobalVars::g_localManager.getID()
            % QString("|") % vacationDate
            % QString("|") % vacationReason
            % QString("|") % QString("0");
    m_msgSocket->slotSendMsg(msg);
}

/////////////////////////managerInfo///////////////////////////////

void AttClient::initManagerWidget()
{
    this->setWindowTitle(tr("考勤管理系统[经理端]"));

    ui->mainToolBar->removeAction(ui->actionAttendance);
    ui->mainToolBar->removeAction(ui->actionCheck_In);
    ui->mainToolBar->removeAction(ui->actionStaffInfo);
    ui->mainToolBar->removeAction(ui->actionVavation);
    ui->mainToolBar->removeAction(ui->actionStaffChangePswd);

    on_actionManagerInfo_triggered();

    connect(m_msgSocket, SIGNAL(signalGainManagerInfo(bool)),
            m_managerInfoForm, SLOT(slotGainManagerInfo(bool)));

    connect(m_managerInfoForm, SIGNAL(signalGainStaffVacationApplyInfo()),
            this, SLOT(slotGainStaffVacationApplyInfo()));

    connect(m_msgSocket, SIGNAL(signalStaffVacationApply(void)),
            m_vacationMSForm, SLOT(slotStaffVacationApply()));

    connect(m_vacationMSForm, SIGNAL(signalVacationApplyAgree()),
            this, SLOT(slotVacationApplyAgree()));

    connect(m_vacationMSForm, SIGNAL(signalVacationApplyReject()),
            this, SLOT(slotVacationApplyReject()));

}

void AttClient::on_actionManagerInfo_triggered()
{
    m_managerInfoForm->show();
    m_vacationMSForm->hide();
    m_chatRoomForm->hide();

    ui->actionManagerInfo->setEnabled(false);
    ui->actionVacationMS->setEnabled(true);
    ui->actionChatRoom->setEnabled(true);
}

void AttClient::on_actionVacationMS_triggered()
{
    m_managerInfoForm->hide();
    m_vacationMSForm->show();
    m_chatRoomForm->hide();

    ui->actionManagerInfo->setEnabled(true);
    ui->actionVacationMS->setEnabled(false);
    ui->actionChatRoom->setEnabled(true);
}

void AttClient::on_actionChatRoom_triggered()
{
    m_managerInfoForm->hide();
    m_vacationMSForm->hide();
    m_staffInfoForm->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_checkForm->hide();
    m_staffChangePswdForm->hide();

    m_chatRoomForm->show();

    ui->actionManagerInfo->setEnabled(true);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAttendance->setEnabled(true);
    ui->actionCheck_In->setEnabled(true);
    ui->actionStaffChangePswd->setEnabled(true);
    ui->actionStaffInfo->setEnabled(true);
    ui->actionVavation->setEnabled(true);
    ui->actionChatRoom->setEnabled(false);
}

void AttClient::slotGainStaffVacationApplyInfo(void)
{
    ///经理想服务器获取员工请假申请信息
    ///未读的员工假期信息请求
    QString msg = QString(CMD_GainVacationApplyInfo_G)
                  % QString ("#") % GlobalVars::g_localUser.getID();
     m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotVacationApplyAgree(void)
{
    ///经理端把同意的请假信息发给服务器
    QString msg = QString(CMD_VacationAgree_A) % QString("#")
                  % QString(GlobalVars::g_currentVacationInfo.getID()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getName()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getDept()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getManagerID()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getVacationDate()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getVacationReason()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getVacationFlag());
    m_msgSocket->slotSendMsg(msg);
}

void AttClient::slotVacationApplyReject(void)
{
    ///经理端把被拒绝的请假信息发给服务器
    QString msg = QString(CMD_VacationReject_J) % QString("#")
                  % QString(GlobalVars::g_currentVacationInfo.getID()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getName()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getDept()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getManagerID()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getVacationDate()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getVacationReason()) % QString("|")
                  % QString(GlobalVars::g_currentVacationInfo.getVacationFlag());
    m_msgSocket->slotSendMsg(msg);
}


