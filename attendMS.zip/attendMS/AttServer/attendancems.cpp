#include "attendancems.h"
#include "ui_attendancems.h"

#include <QPaintEvent>
#include <QPainter>
#include <QPixmap>

AttendanceMS::AttendanceMS(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AttendanceMS)
{
    ui->setupUi(this);

    ui->menuBar->hide();
    ui->statusBar->hide();

    m_loginWidget = new LoginWidget(ui->widget);
    m_userForm = new UserForm(ui->widget);
    m_staffForm = new StaffForm(ui->widget);
    m_managerForm = new ManagerForm(ui->widget);
    m_departmentFrom = new DepartmentForm(ui->widget);
    m_attendanceForm = new AttendanceForm(ui->widget);
    m_vacationForm = new VacationForm(ui->widget);
    m_announcementForm = new AnnouncementForm(ui->widget);
    m_chatRecordForm = new ChatRecordForm(ui->widget);

    connect(m_loginWidget,SIGNAL(signalLoginSuccess(QString,QString)),
             this, SLOT(slotLoginSuccess(QString,QString)));

    m_loginWidget->show();
    m_userForm->hide();
    m_staffForm->hide();
    m_managerForm->hide();
    m_departmentFrom->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_announcementForm->hide();
    m_chatRecordForm->hide();

    ui->mainToolBar->hide();   

    m_msgServer = new MsgServer;

    connect(m_msgServer, SIGNAL(signalUpdateBuffer()),
            m_userForm, SLOT(slotUpdateBuffer()));

    connect(m_msgServer, SIGNAL(signalUpdateBuffer()),
            m_staffForm, SLOT(slotUpdateBuffer()));

    connect(m_msgServer, SIGNAL(signalUpdateBuffer()),
            m_attendanceForm, SLOT(slotUpdateBuffer()));

    connect(m_msgServer, SIGNAL(signalUpdateBuffer()),
            m_vacationForm, SLOT(slotUpdateBuffer()));

    connect(m_msgServer, SIGNAL(signalUpdateBuffer()),
            m_announcementForm, SLOT(slotUpdateBuffer()));

    connect(m_msgServer, SIGNAL(signalUpdateBuffer()),
            m_chatRecordForm, SLOT(slotUpdateBuffer()));

}

AttendanceMS::~AttendanceMS()
{
    delete ui;
}

void AttendanceMS::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    QPixmap pix(":/images/003.jpg");
    p.drawPixmap(0,0,pix);
}

void AttendanceMS::on_actionUser_triggered()
{
    m_userForm->show();
    m_staffForm->hide();
    m_departmentFrom->hide();
    m_managerForm->hide();
    m_loginWidget->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_announcementForm->hide();
    m_chatRecordForm->hide();

    ui->actionUser->setEnabled(false);
    ui->actionStaff->setEnabled(true);
    ui->actionManager_2->setEnabled(true);
    ui->actionDepartmentMS->setEnabled(true);
    ui->actionAttendanceMS->setEnabled(true);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAnnouncementMS->setEnabled(true);
    ui->actionChatRecordMS->setEnabled(true);
}

void AttendanceMS::on_actionStaff_triggered()
{
    m_userForm->hide();
    m_staffForm->show();
    m_departmentFrom->hide();
    m_managerForm->hide();
    m_loginWidget->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_announcementForm->hide();
    m_chatRecordForm->hide();

    ui->actionUser->setEnabled(true);
    ui->actionStaff->setEnabled(false);
    ui->actionManager_2->setEnabled(true);
    ui->actionDepartmentMS->setEnabled(true);
    ui->actionAttendanceMS->setEnabled(true);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAnnouncementMS->setEnabled(true);
    ui->actionChatRecordMS->setEnabled(true);
}

void AttendanceMS::on_actionManager_2_triggered()
{
    m_userForm->hide();
    m_staffForm->hide();
    m_managerForm->show();
    m_departmentFrom->hide();
    m_loginWidget->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_announcementForm->hide();
    m_chatRecordForm->hide();

    ui->actionUser->setEnabled(true);
    ui->actionStaff->setEnabled(true);
    ui->actionManager_2->setEnabled(false);
    ui->actionDepartmentMS->setEnabled(true);
    ui->actionAttendanceMS->setEnabled(true);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAnnouncementMS->setEnabled(true);
    ui->actionChatRecordMS->setEnabled(true);
}

void AttendanceMS::on_actionDepartmentMS_triggered()
{
    m_userForm->hide();
    m_staffForm->hide();
    m_managerForm->hide();
    m_departmentFrom->show();
    m_loginWidget->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_announcementForm->hide();
    m_chatRecordForm->hide();

    ui->actionUser->setEnabled(true);
    ui->actionStaff->setEnabled(true);
    ui->actionManager_2->setEnabled(true);
    ui->actionDepartmentMS->setEnabled(false);
    ui->actionAttendanceMS->setEnabled(true);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAnnouncementMS->setEnabled(true);
    ui->actionChatRecordMS->setEnabled(true);
}

void AttendanceMS::on_actionAttendanceMS_triggered()
{
    m_userForm->hide();
    m_staffForm->hide();
    m_managerForm->hide();
    m_departmentFrom->hide();
    m_loginWidget->hide();
    m_attendanceForm->show();
    m_vacationForm->hide();
    m_announcementForm->hide();
    m_chatRecordForm->hide();

    ui->actionUser->setEnabled(true);
    ui->actionStaff->setEnabled(true);
    ui->actionManager_2->setEnabled(true);
    ui->actionDepartmentMS->setEnabled(true);
    ui->actionAttendanceMS->setEnabled(false);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAnnouncementMS->setEnabled(true);
    ui->actionChatRecordMS->setEnabled(true);
}

void AttendanceMS::on_actionVacationMS_triggered()
{
    m_userForm->hide();
    m_staffForm->hide();
    m_managerForm->hide();
    m_departmentFrom->hide();
    m_loginWidget->hide();
    m_attendanceForm->hide();
    m_vacationForm->show();
    m_announcementForm->hide();
    m_chatRecordForm->hide();

    ui->actionUser->setEnabled(true);
    ui->actionStaff->setEnabled(true);
    ui->actionManager_2->setEnabled(true);
    ui->actionDepartmentMS->setEnabled(true);
    ui->actionAttendanceMS->setEnabled(true);
    ui->actionVacationMS->setEnabled(false);
    ui->actionAnnouncementMS->setEnabled(true);
    ui->actionChatRecordMS->setEnabled(true);
}

void AttendanceMS::on_actionAnnouncementMS_triggered()
{
    m_userForm->hide();
    m_staffForm->hide();
    m_managerForm->hide();
    m_departmentFrom->hide();
    m_loginWidget->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_announcementForm->show();
    m_chatRecordForm->hide();

    ui->actionUser->setEnabled(true);
    ui->actionStaff->setEnabled(true);
    ui->actionManager_2->setEnabled(true);
    ui->actionDepartmentMS->setEnabled(true);
    ui->actionAttendanceMS->setEnabled(true);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAnnouncementMS->setEnabled(false);
    ui->actionChatRecordMS->setEnabled(true);
}

void AttendanceMS::on_actionChatRecordMS_triggered()
{
    m_userForm->hide();
    m_staffForm->hide();
    m_managerForm->hide();
    m_departmentFrom->hide();
    m_loginWidget->hide();
    m_attendanceForm->hide();
    m_vacationForm->hide();
    m_announcementForm->hide();
    m_chatRecordForm->show();

    ui->actionUser->setEnabled(true);
    ui->actionStaff->setEnabled(true);
    ui->actionManager_2->setEnabled(true);
    ui->actionDepartmentMS->setEnabled(true);
    ui->actionAttendanceMS->setEnabled(true);
    ui->actionVacationMS->setEnabled(true);
    ui->actionAnnouncementMS->setEnabled(true);
    ui->actionChatRecordMS->setEnabled(false);
}

void AttendanceMS::slotLoginSuccess(QString id, QString pswd)
{
    if(id == "Unicorn" && pswd == "123456")
    {
        ui->mainToolBar->show();
        on_actionUser_triggered();
    }else
    {
         m_loginWidget->userLoginFail();
    }
}



