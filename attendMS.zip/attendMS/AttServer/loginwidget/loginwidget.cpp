#include "loginwidget.h"
#include "ui_loginwidget.h"

#include <QMessageBox>
#include <QPaintEvent>
#include <QPainter>
#include <QPixmap>

LoginWidget::LoginWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginWidget)
{
    ui->setupUi(this);
}

LoginWidget::~LoginWidget()
{
    delete ui;
}

void LoginWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    QPixmap pix(":/images/003.jpg");
    p.drawPixmap(0,0,pix);
}

void LoginWidget::on_pb_login_clicked()
{
    emit signalLoginSuccess(ui->le_id->text(),ui->le_pswd->text());
}

void LoginWidget::userLoginFail(void)
{
    QMessageBox msgBox(this);
    msgBox.setStyleSheet("background-color: rgb(255, 255, 255);");
    msgBox.setText("登录失败!");
    msgBox.setInformativeText("用户名或者密码错误，请重新输入!");
    msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Close);
    msgBox.setDefaultButton(QMessageBox::Retry);
    msgBox.exec();
}
