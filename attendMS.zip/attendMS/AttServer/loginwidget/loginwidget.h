#ifndef LOGINWIDGET_H
#define LOGINWIDGET_H

#include <QWidget>
#include <QString>

namespace Ui {
class LoginWidget;
}

class LoginWidget : public QWidget
{
    Q_OBJECT

signals:
    void signalLoginSuccess(QString id, QString pswd);

public:
    explicit LoginWidget(QWidget *parent = 0);
    ~LoginWidget();

    void userLoginFail(void);

protected:
    void paintEvent(QPaintEvent *);

private slots:
    void on_pb_login_clicked();

private:
    Ui::LoginWidget *ui;
};

#endif // LOGINWIDGET_H
