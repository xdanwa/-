#ifndef CONNECTMYSQL_H
#define CONNECTMYSQL_H


class connectMySQL
{
public:
    connectMySQL();
    bool createConnection();
    void closeConnection();
};

#endif // CONNECTMYSQL_H
