#ifndef EXECSQL_H
#define EXECSQL_H

#include "globalvars.h"

#include "userinfo.h"
#include "staffinfo.h"
#include "managerinfo.h"
#include "departmentinfo.h"
#include "attendanceinfo.h"
#include "vacationinfo.h"
#include "announcementinfo.h"
#include "chatrecordinfo.h"

class ExecSQL
{
public:
    ExecSQL();

    ///////////////////////UserInfo/////////////////////////////

    static void searchAllUserInfos();
    static void searchUserInfoForID(const QString &value);
    static void searchUserInfoForRole(const QString &value);
    static void searchUserInfoForDate(const QString &value);
    static void searchUserInfoForDept(const QString &value);
    static void updateUserInfoList(const QString &sql);

    static bool addNewUserInfo(const UserInfo &info);
    static bool removeUserInfo(QString value);
    static bool modifyUserInfoForPswd(const QString &id, const QString &value);
    static bool modifyUserInfoForRole(const QString &id, const QString &value);
    static bool modifyUserInfoForDept(const QString &id, const QString &value);
    static bool modifyUserInfoForDate(const QString &id, const QString &value);

    ///////////////////////StaffInfo/////////////////////////////

    static void searchAllStaffInfos();
    static void searchStaffInfoForID(const QString &value);
    static void searchStaffInfoForName(const QString &value);
    static void searchStaffInfoForDept(const QString &value);
    static void searchStaffInfoForPost(const QString &value);
    static void updateStaffInfoList(const QString &sql);

    static bool addNewStaffInfo(const StaffInfo &info);
    static bool removeStaffInfo(QString value);
    static bool modifyStaffInfoForName(const QString &id, const QString &value);
    static bool modifyStaffInfoForDept(const QString &id, const QString &value);
    static bool modifyStaffInfoForPost(const QString &id, const QString &value);

    ///////////////////////ManagerInfo/////////////////////////////

    static void searchAllManagerInfos();
    static void searchManagerInfoForID(const QString &value);
    static void searchManagerInfoForName(const QString &value);
    static void searchManagerInfoForDept(const QString &value);
    static void updateManagerInfoList(const QString &sql);

    static bool addNewManagerInfo(const ManagerInfo &info);
    static bool removeManagerInfo(QString value);
    static bool modifyManagerInfoForName(const QString &id, const QString &value);
    static bool modifyManagerInfoForDept(const QString &id, const QString &value);

    //////////////////////DepartmentInfo////////////////////////////

    static void searchAllDepartmentInfos();
    static void searchDepartmentInfoForID(const QString &value);
    static void searchDepartmentInfoForName(const QString &value);
    static void searchDepartmentInfoForCount(const QString &value);
    static void searchDepartmentInfoForManager(const QString &value);
    static void updateDepartmentInfoList(const QString &sql);

    static bool addNewDepartmentInfo(const DepartmentInfo &info);
    static bool removeDepartmentInfo(QString value);
    static bool modifyDepartmentInfoForName(const QString &id, const QString &value);
    static bool modifyDepartmentInfoForCount(const QString &id, const QString &value);
    static bool modifyDepartmentInfoForManager(const QString &id, const QString &value);

    /////////////////////AttendanceInfo//////////////////////////////

    static void searchAllAttendanceInfos();
    static void searchAttendanceInfoForID(const QString &value);
    static void searchAttendanceInfoForName(const QString &value);
    static void searchAttendanceInfoForDept(const QString &value);
    static void searchAttendanceInfoForDate(const QString &value);
    static void updateAttendanceInfoList(const QString &sql);
    static void updateLocalStaffAttendanceInfoList(const QString &sql);

    static bool addNewAttendanceInfo(const AttendanceInfo &info);
    static bool removeAttendanceInfo(QString value);
    static bool modifyAttendanceInfoForEndTime(const QString &id, const QString &date,
                                               const QString &workTime, const QString &endTime);

    /////////////////////VacationInfo////////////////////////////////

    static void searchAllVacationInfos();
    static void searchVacationInfoForID(const QString &value);
    static void searchVacationInfoForName(const QString &value);
    static void searchVacationInfoForDept(const QString &value);
    static void searchVacationInfoForDate(const QString &value);
    static void searchVacationInfoForFlag(const QString &value);
    static void updateVacationInfoList(const QString &sql);
    static void updateVacationApplyInfoList(const QString &sql);

    static bool addNewVacationInfo(const VacationInfo &info);
    static bool modifyVacationInfoForFlag(const QString &date, const QString &id, const QString &flag);

    /////////////////////announcementInfo////////////////////////////////////

    static void searchAllAnnouncementInfos();
    static void searchAnnouncementInfoForName(const QString &value);
    static void searchAnnouncementInfoForDate(const QString &value);
    static void updateAnnouncementInfoList(const QString &sql);
    static void updateLocalGroupBulletinList(const QString &sql);

    static bool addNewAnnouncementInfo(const AnnouncementInfo &info);

    /////////////////////chatRecordInfo//////////////////////////////////////

    static void searchAllChatRecordInfos();
    static void searchChatRecordInfoForName(const QString &value);
    static void searchChatRecordInfoForDept(const QString &value);
    static void searchChatRecordInfoForDate(const QString &value);
    static void updateChatRecordInfoList(const QString &sql);

    static bool addNewChatRecordInfo(const ChatRecordInfo &info);
};

#endif // EXECSQL_H
