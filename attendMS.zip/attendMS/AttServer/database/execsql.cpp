#include "execsql.h"

#include <QSqlQuery>
#include <QSqlRecord>
#include <QSqlError>

ExecSQL::ExecSQL()
{

}

////////////////////////UserInfo////////////////////////////

void ExecSQL::searchAllUserInfos()
{
    QString queryString = QString("select * from user_info");
    qDebug() << queryString;

    updateUserInfoList(queryString);
}

void ExecSQL::searchUserInfoForID(const QString &value)
{
    QString queryString = QString("select * from user_info where id = '%1'").arg(value);
    qDebug() << queryString;

    updateUserInfoList(queryString);
}

void ExecSQL::searchUserInfoForRole(const QString &value)
{
    QString queryString = QString("select * from user_info where role = '%1'").arg(value);
    qDebug() << queryString;

    updateUserInfoList(queryString);
}

void ExecSQL::searchUserInfoForDate(const QString &value)
{
    QString queryString = QString("select * from user_info where user_date = '%1'").arg(value);
    qDebug() << queryString;

    updateUserInfoList(queryString);
}

void ExecSQL::searchUserInfoForDept(const QString &value)
{
    QString queryString = QString("select * from user_info where dept = '%1'").arg(value);
    qDebug() << queryString;

    updateUserInfoList(queryString);
}

void ExecSQL::updateUserInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_userInfoList->clear();
    GlobalVars::g_userInfoMap.clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("id");
         int pswd_idx = query.record().indexOf("pswd");
         int role_idx = query.record().indexOf("role");
         int dept_idx = query.record().indexOf("dept");
         int date_idx = query.record().indexOf("user_date");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString pswd = query.value(pswd_idx).toString();
            QString role = query.value(role_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString date = query.value(date_idx).toString();

            UserInfo info(id, pswd, role, dept, date);
            GlobalVars::g_userInfoList->append(info);
          }
            for(UserInfoList::iterator it = GlobalVars::g_userInfoList->begin();
                it != GlobalVars::g_userInfoList->end(); it++)
            {
               GlobalVars::g_userInfoMap.insert(it->getID(), it);
            }
    }
}

bool ExecSQL::addNewUserInfo(const UserInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into user_info values('%1', '%2', '%3', '%4', '%5')")
            .arg(info.getID()).arg(info.getPswd()).arg(info.getRole()).arg(info.getDept()).arg(info.getDate());
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::removeUserInfo(QString value)
{
    QSqlQuery query;
    QString queryString = QString("delete from user_info where id = '%1'").arg(value);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyUserInfoForPswd(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update user_info set pswd = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyUserInfoForRole(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update user_info set role = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyUserInfoForDept(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update user_info set dept = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyUserInfoForDate(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update user_info set user_date = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

///////////////////////////StaffInfo/////////////////////////////////

void ExecSQL::searchAllStaffInfos()
{
    QString queryString = QString("select * from staff_info");
    qDebug() << queryString;

    updateStaffInfoList(queryString);
}

void ExecSQL::searchStaffInfoForID(const QString &value)
{
    QString queryString = QString("select * from staff_info where id = '%1'").arg(value);
    qDebug() << queryString;

    updateStaffInfoList(queryString);
}

void ExecSQL::searchStaffInfoForName(const QString &value)
{
    QString queryString = QString("select * from staff_info where name = '%1'").arg(value);
    qDebug() << queryString;

    updateStaffInfoList(queryString);
}

void ExecSQL::searchStaffInfoForDept(const QString &value)
{
    QString queryString = QString("select * from staff_info where dept = '%1'").arg(value);
    qDebug() << queryString;

    updateStaffInfoList(queryString);
}

void ExecSQL::searchStaffInfoForPost(const QString &value)
{
    QString queryString = QString("select * from staff_info where post = '%1'").arg(value);
    qDebug() << queryString;

    updateStaffInfoList(queryString);
}

void ExecSQL::updateStaffInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_staffInfoList->clear();
    GlobalVars::g_staffInfoMap.clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("id");
         int name_idx = query.record().indexOf("name");
         int dept_idx = query.record().indexOf("dept");
         int post_idx = query.record().indexOf("post");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString post = query.value(post_idx).toString();

            StaffInfo info(id, name, dept, post);
            GlobalVars::g_staffInfoList->append(info);
         }

         for(StaffInfoList::iterator it = GlobalVars::g_staffInfoList->begin();
                it != GlobalVars::g_staffInfoList->end(); it++)
         {
            GlobalVars::g_staffInfoMap.insert(it->getID(), it);
         }
    }
}

bool ExecSQL::addNewStaffInfo(const StaffInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into staff_info values('%1', '%2', '%3', '%4')")
            .arg(info.getID()).arg(info.getName()).arg(info.getDept()).arg(info.getPost());
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::removeStaffInfo(QString value)
{
    QSqlQuery query;
    QString queryString = QString("delete from staff_info where id = '%1'").arg(value);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyStaffInfoForName(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update staff_info set name = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyStaffInfoForDept(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update staff_info set dept = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyStaffInfoForPost(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update staff_info set post = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

///////////////////////ManagerInfo/////////////////////////////////

void ExecSQL::searchAllManagerInfos()
{
    QString queryString = QString("select * from manager_info");
    qDebug() << queryString;

    updateManagerInfoList(queryString);
}

void ExecSQL::searchManagerInfoForID(const QString &value)
{
    QString queryString = QString("select * from manager_info where id = '%1' ").arg(value);
    qDebug() << queryString;

    updateManagerInfoList(queryString);
}

void ExecSQL::searchManagerInfoForName(const QString &value)
{
    QString queryString = QString("select * from manager_info where name = '%1' ").arg(value);
    qDebug() << queryString;

    updateManagerInfoList(queryString);
}

void ExecSQL::searchManagerInfoForDept(const QString &value)
{
    QString queryString = QString("select * from manager_info where dept = '%1' ").arg(value);
    qDebug() << queryString;

    updateManagerInfoList(queryString);
}

void ExecSQL::updateManagerInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_managerInfoList->clear();
    GlobalVars::g_managerInfoMap.clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("id");
         int name_idx = query.record().indexOf("name");
         int dept_idx = query.record().indexOf("dept");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();

            ManagerInfo info(id, name, dept);
            GlobalVars::g_managerInfoList->append(info);
         }

         for(ManagerInfoList::iterator it = GlobalVars::g_managerInfoList->begin();
                it != GlobalVars::g_managerInfoList->end(); it++)
         {
            GlobalVars::g_managerInfoMap.insert(it->getID(), it);
         }
    }
}

bool ExecSQL::addNewManagerInfo(const ManagerInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into manager_info values('%1', '%2', '%3')")
            .arg(info.getID()).arg(info.getName()).arg(info.getDept());
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::removeManagerInfo(QString value)
{
    QSqlQuery query;
    QString queryString = QString("delete from manager_info where id = '%1'").arg(value);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyManagerInfoForName(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update manager_info set name = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyManagerInfoForDept(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update manager_info set dept = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

////////////////////////////DepartmentInfo/////////////////////////////////////

void ExecSQL::searchAllDepartmentInfos()
{
    QString queryString = QString("select * from department_info");
    qDebug() << queryString;

    updateDepartmentInfoList(queryString);
}

void ExecSQL::searchDepartmentInfoForID(const QString &value)
{
    QString queryString = QString("select * from department_info where id = '%1' ").arg(value);
    qDebug() << queryString;

    updateDepartmentInfoList(queryString);
}

void ExecSQL::searchDepartmentInfoForName(const QString &value)
{
    QString queryString = QString("select * from department_info where name = '%1' ").arg(value);
    qDebug() << queryString;

    updateDepartmentInfoList(queryString);
}

void ExecSQL::searchDepartmentInfoForCount(const QString &value)
{
    QString queryString = QString("select * from department_info where count = '%1' ").arg(value);
    qDebug() << queryString;

    updateDepartmentInfoList(queryString);
}

void ExecSQL::searchDepartmentInfoForManager(const QString &value)
{
    QString queryString = QString("select * from department_info where manager = '%1' ").arg(value);
    qDebug() << queryString;

    updateDepartmentInfoList(queryString);
}

void ExecSQL::updateDepartmentInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_departmentInfoList->clear();
    GlobalVars::g_departmentInfoMap.clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("id");
         int name_idx = query.record().indexOf("name");
         int count_idx = query.record().indexOf("count");
         int manager_idx = query.record().indexOf("manager");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString count = query.value(count_idx).toString();
            QString manager = query.value(manager_idx).toString();

            DepartmentInfo info(id, name, count, manager);
            GlobalVars::g_departmentInfoList->append(info);
         }

         for(DepartmentInfoList::iterator it = GlobalVars::g_departmentInfoList->begin();
                it != GlobalVars::g_departmentInfoList->end(); it++)
         {
            GlobalVars::g_departmentInfoMap.insert(it->getID(), it);
         }
    }
}

bool ExecSQL::addNewDepartmentInfo(const DepartmentInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into department_info values('%1', '%2', '%3', '%4')")
            .arg(info.getID()).arg(info.getName()).arg(info.getCount()).arg(info.getManager());
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::removeDepartmentInfo(QString value)
{
    QSqlQuery query;
    QString queryString = QString("delete from department_info where id = '%1'").arg(value);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyDepartmentInfoForName(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update department_info set name = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyDepartmentInfoForCount(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update department_info set count = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyDepartmentInfoForManager(const QString &id, const QString &value)
{
    QSqlQuery query;
    QString queryString = QString("update department_info set manager = '%1' where id = '%2'").arg(value).arg(id);
    qDebug() << queryString;
    return query.exec(queryString);
}

/////////////////////AttendanceInfo//////////////////////////////

void ExecSQL::searchAllAttendanceInfos()
{
    QString queryString = QString("select * from attendance_info");
    qDebug() << queryString;

    updateAttendanceInfoList(queryString);
}

void ExecSQL::searchAttendanceInfoForID(const QString &value)
{
    QString queryString = QString("select * from attendance_info where staff_id = '%1'").arg(value);
    qDebug() << queryString;

    updateAttendanceInfoList(queryString);
}

void ExecSQL::searchAttendanceInfoForName(const QString &value)
{
    QString queryString = QString("select * from attendance_info where staff_name = '%1'").arg(value);
    qDebug() << queryString;

    updateAttendanceInfoList(queryString);
}

void ExecSQL::searchAttendanceInfoForDept(const QString &value)
{
    QString queryString = QString("select * from attendance_info where staff_dept = '%1'").arg(value);
    qDebug() << queryString;

    updateAttendanceInfoList(queryString);
}

void ExecSQL::searchAttendanceInfoForDate(const QString &value)
{
    QString queryString = QString("select * from attendance_info where date = '%1'").arg(value);
    qDebug() << queryString;

    updateAttendanceInfoList(queryString);
}

void ExecSQL::updateAttendanceInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_attendanceInfoList->clear();
    GlobalVars::g_attendanceInfoMap.clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("staff_id");
         int name_idx = query.record().indexOf("staff_name");
         int dept_idx = query.record().indexOf("staff_dept");
         int work_time_idx = query.record().indexOf("work_time");
         int end_time_idx = query.record().indexOf("end_time");
         int date_idx = query.record().indexOf("date");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString work_time = query.value(work_time_idx).toString();
            QString end_time = query.value(end_time_idx).toString();
            QString date = query.value(date_idx).toString();


            AttendanceInfo info(id, name, dept, work_time, end_time, date);
            GlobalVars::g_attendanceInfoList->append(info);
         }

         for(AttendanceInfoList::iterator it = GlobalVars::g_attendanceInfoList->begin();
                it != GlobalVars::g_attendanceInfoList->end(); it++)
         {
            GlobalVars::g_attendanceInfoMap.insert(it->getStaffID(), it);
         }
    }
}

void ExecSQL::updateLocalStaffAttendanceInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_localStaffAttendanceInfoList->clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("staff_id");
         int name_idx = query.record().indexOf("staff_name");
         int dept_idx = query.record().indexOf("staff_dept");
         int work_time_idx = query.record().indexOf("work_time");
         int end_time_idx = query.record().indexOf("end_time");
         int date_idx = query.record().indexOf("date");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString work_time = query.value(work_time_idx).toString();
            QString end_time = query.value(end_time_idx).toString();
            QString date = query.value(date_idx).toString();


            AttendanceInfo info(id, name, dept, work_time, end_time, date);
            GlobalVars::g_localStaffAttendanceInfoList->append(info);
         }
    }
}

bool ExecSQL::addNewAttendanceInfo(const AttendanceInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into attendance_info values('%1', '%2', '%3', '%4', '%5', '%6')")
            .arg(info.getStaffID()).arg(info.getStaffName()).arg(info.getStaffDept()).arg(info.getWorkTime())
            .arg(info.getEndTime()).arg(info.getDate());
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::removeAttendanceInfo(QString value)
{
    QSqlQuery query;
    QString queryString = QString("delete from attendance_info where staff_id = '%1'").arg(value);
    qDebug() << queryString;
    return query.exec(queryString);
}

bool ExecSQL::modifyAttendanceInfoForEndTime(const QString &id, const QString &date, const QString &workTime, const QString &endTime)
{
    QSqlQuery query;
    QString queryString = QString("update attendance_info set end_time = '%1' where staff_id = '%2' and date = '%3' and work_time = '%4'")
                            .arg(endTime).arg(id).arg(date).arg(workTime);
    qDebug() << queryString;
    return query.exec(queryString);
}

/////////////////////VacationInfo////////////////////////////////

void ExecSQL::searchAllVacationInfos()
{
    QString queryString = QString("select * from vacation_info");
    qDebug() << queryString;

    updateVacationInfoList(queryString);
}

void ExecSQL::searchVacationInfoForID(const QString &value)
{
    QString queryString = QString("select * from vacation_info where staff_id = '%1'").arg(value);
    qDebug() << queryString;

    updateVacationInfoList(queryString);
}

void ExecSQL::searchVacationInfoForName(const QString &value)
{
    QString queryString = QString("select * from vacation_info where name = '%1'").arg(value);
    qDebug() << queryString;

    updateVacationInfoList(queryString);
}

void ExecSQL::searchVacationInfoForDept(const QString &value)
{
    QString queryString = QString("select * from vacation_info where dept = '%1'").arg(value);
    qDebug() << queryString;

    updateVacationInfoList(queryString);
}

void ExecSQL::searchVacationInfoForDate(const QString &value)
{
    QString queryString = QString("select * from vacation_info where vacationDate = '%1'").arg(value);
    qDebug() << queryString;

    updateVacationInfoList(queryString);
}

void ExecSQL::searchVacationInfoForFlag(const QString &value)
{
    QString queryString = QString("select * from vacation_info where flag = '%1'").arg(value);
    qDebug() << queryString;

    updateVacationInfoList(queryString);
}

void ExecSQL::updateVacationInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_vacationInfoList->clear();
    GlobalVars::g_vacationInfoMap.clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("staff_id");
         int name_idx = query.record().indexOf("staff_name");
         int dept_idx = query.record().indexOf("staff_dept");
         int managerID_idx = query.record().indexOf("manager_id");
         int vacationDate_idx = query.record().indexOf("vacationDate");
         int vacationReason_idx = query.record().indexOf("vacationReason");
         int flag_idx = query.record().indexOf("flag");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString managerID = query.value(managerID_idx).toString();
            QString vacationDate = query.value(vacationDate_idx).toString();
            QString vacationReason = query.value(vacationReason_idx).toString();
            QString flag = query.value(flag_idx).toString();


            VacationInfo info(id, name, dept, managerID, vacationDate, vacationReason, flag);
            GlobalVars::g_vacationInfoList->append(info);
         }

         for(VacationInfoList::iterator it = GlobalVars::g_vacationInfoList->begin();
                it != GlobalVars::g_vacationInfoList->end(); it++)
         {
            GlobalVars::g_vacationInfoMap.insert(it->getID(), it);
         }
    }
}

void ExecSQL::updateVacationApplyInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_vacationApplyInfoList->clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("staff_id");
         int name_idx = query.record().indexOf("staff_name");
         int dept_idx = query.record().indexOf("staff_dept");
         int managerID_idx = query.record().indexOf("manager_id");
         int vacationDate_idx = query.record().indexOf("vacationDate");
         int vacationReason_idx = query.record().indexOf("vacationReason");
         int flag_idx = query.record().indexOf("flag");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString managerID = query.value(managerID_idx).toString();
            QString vacationDate = query.value(vacationDate_idx).toString();
            QString vacationReason = query.value(vacationReason_idx).toString();
            QString flag = query.value(flag_idx).toString();

            VacationInfo info(id, name, dept, managerID, vacationDate, vacationReason, flag);
            GlobalVars::g_vacationApplyInfoList->append(info);
         }
    }
}

bool ExecSQL::addNewVacationInfo(const VacationInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into vacation_info values('%1', '%2', '%3', '%4', '%5', '%6', '%7')")
            .arg(info.getID()).arg(info.getName()).arg(info.getDept()).arg(info.getManagerID())
            .arg(info.getVacationDate()).arg(info.getVacationReason()).arg(info.getVacationFlag());
    qDebug() << queryString;

    return query.exec(queryString);
}

bool ExecSQL::modifyVacationInfoForFlag(const QString &date, const QString &id, const QString &flag)
{
    QSqlQuery query;
    QString queryString = QString("update vacation_info set flag = '%1' where staff_id = '%2' and vacationDate = '%3'")
                            .arg(flag).arg(id).arg(date);
    qDebug() << queryString;
    return query.exec(queryString);
}

//////////////////////////announcementInfo//////////////////////////////////////////

void ExecSQL::searchAllAnnouncementInfos()
{
    QString queryString = QString("select * from announcement_info");
    qDebug() << queryString;

    updateAnnouncementInfoList(queryString);
}

void ExecSQL::searchAnnouncementInfoForName(const QString &value)
{
    QString queryString = QString("select * from announcement_info where manager_name = '%1'").arg(value);
    qDebug() << queryString;

    updateAnnouncementInfoList(queryString);
}

void ExecSQL::searchAnnouncementInfoForDate(const QString &value)
{
    QString queryString = QString("select * from announcement_info where dateTime = '%1'").arg(value);
    qDebug() << queryString;

    updateAnnouncementInfoList(queryString);
}

void ExecSQL::updateAnnouncementInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_announcementInfoList->clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("manager_id");
         int name_idx = query.record().indexOf("manager_name");
         int dept_idx = query.record().indexOf("manager_dept");
         int dateTime_idx = query.record().indexOf("dateTime");
         int content_idx = query.record().indexOf("content");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString dateTime = query.value(dateTime_idx).toString();
            QString content = query.value(content_idx).toString();

            AnnouncementInfo info(id, name, dept, dateTime, content);
            GlobalVars::g_announcementInfoList->append(info);
         }
    }
}

void ExecSQL::updateLocalGroupBulletinList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_localGroupBulletinList->clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("manager_id");
         int name_idx = query.record().indexOf("manager_name");
         int dept_idx = query.record().indexOf("manager_dept");
         int dateTime_idx = query.record().indexOf("dateTime");
         int content_idx = query.record().indexOf("content");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString dateTime = query.value(dateTime_idx).toString();
            QString content = query.value(content_idx).toString();

            AnnouncementInfo info(id, name, dept, dateTime, content);
            GlobalVars::g_localGroupBulletinList->append(info);
         }
    }
}

bool ExecSQL::addNewAnnouncementInfo(const AnnouncementInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into announcement_info values('%1', '%2', '%3', '%4', '%5')")
                          .arg(info.getID()).arg(info.getName()).arg(info.getDept()).arg(info.getdateTime())
                          .arg(info.getContent());
    qDebug() << queryString;

    return query.exec(queryString);
}

/////////////////////chatRecordInfo//////////////////////////////////////

void ExecSQL::searchAllChatRecordInfos()
{
    QString queryString = QString("select * from chatrecord_info");
    qDebug() << queryString;

    updateChatRecordInfoList(queryString);
}

void ExecSQL::searchChatRecordInfoForName(const QString &value)
{
    QString queryString = QString("select * from chatrecord_info where name = '%1'").arg(value);
    qDebug() << queryString;

    updateAnnouncementInfoList(queryString);
}

void ExecSQL::searchChatRecordInfoForDept(const QString &value)
{
    QString queryString = QString("select * from chatrecord_info where dept = '%1'").arg(value);
    qDebug() << queryString;

    updateAnnouncementInfoList(queryString);
}

void ExecSQL::searchChatRecordInfoForDate(const QString &value)
{
    QString queryString = QString("select * from chatrecord_info where dateTime = '%1'").arg(value);
    qDebug() << queryString;

    updateAnnouncementInfoList(queryString);
}

void ExecSQL::updateChatRecordInfoList(const QString &sql)
{
    QSqlQuery query;
    GlobalVars::g_chatRecordInfoList->clear();

    if(query.exec(sql))
    {
         int id_idx = query.record().indexOf("id");
         int name_idx = query.record().indexOf("name");
         int dept_idx = query.record().indexOf("dept");
         int dateTime_idx = query.record().indexOf("dateTime");
         int content_idx = query.record().indexOf("content");

         while(query.next())
         {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString dept = query.value(dept_idx).toString();
            QString dateTime = query.value(dateTime_idx).toString();
            QString content = query.value(content_idx).toString();

            ChatRecordInfo info(id, name, dept, dateTime, content);
            GlobalVars::g_chatRecordInfoList->append(info);
         }
    }
}

bool ExecSQL::addNewChatRecordInfo(const ChatRecordInfo &info)
{
    QSqlQuery query;
    QString queryString = QString("insert into chatRecord_info values('%1', '%2', '%3', '%4', '%5')")
                          .arg(info.getID()).arg(info.getName()).arg(info.getDept()).arg(info.getdateTime())
                          .arg(info.getContent());
    qDebug() << queryString;

    return query.exec(queryString);
}
