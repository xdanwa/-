#include "connectmysql.h"
#include <QSqlDatabase>
#include <QSqlError>

connectMySQL::connectMySQL()
{

}

bool connectMySQL::createConnection()
{
    QSqlDatabase db;
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setPort(3307);
    db.setDatabaseName("attendancems");
    db.setUserName("root");
    db.setPassword("123456");
    if(!db.open()){
        qCritical("Can't open database: %s(%s)",
        db.lastError().text().toLocal8Bit().data(),
        qt_error_string().toLocal8Bit().data());
        return false;
    }
    return true;
}

void connectMySQL::closeConnection()
{
    QSqlDatabase::database().close();
}

