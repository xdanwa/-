#ifndef GLOBALVARS_H
#define GLOBALVARS_H

#include "userinfo.h"
#include "staffinfo.h"
#include "managerinfo.h"
#include "departmentinfo.h"
#include "attendanceinfo.h"
#include "vacationinfo.h"
#include "announcementinfo.h"
#include "chatrecordinfo.h"

#include <QQueue>

enum Oper_Data{
    Oper_None,
    Oper_Add,
    Oper_Del,
    Oper_Mdy,
    Oper_Cancel
};

enum RESPONSE{
    RES_Down = '!',
    RES_Fail = '?'
};

enum COMMAND{

    ///通用请求命令
    CMD_UserLogin_L = 'L',          //用户登录
    CMD_UserInfo_I = 'I',           //获取个人信息
    CMD_ChangePswd_H = 'H',         //修改密码
    CMD_UserExit_X = 'X',           //用户退出
    CMD_UserRegister_R = 'R',       //用户注册
    CMD_NewClientOnline_N = 'N',    //新的客户端上线
    CMD_ClientOffline_F = 'F',      //有客户端离线

    CMD_GainGroupBulletin_B = 'B',   //用户获取群公告
    CMD_PublishGroupBulletin_P = 'p', //群主发布群公告
    CMD_GainGroupMember_M = 'M',      //用户获取群成员
    CMD_SendGroupMessage_S = 'S',     //群成员发送群消息

    ///员工请求命令
    CMD_StaffCheck_C = 'C',         //员工打卡
    CMD_StaffVacation_V = 'V',      //员工请假
    CMD_ObtainStaffAttendanceInfo_O = 'O', //员工请假信息的获取


    /// 经理请求命令
    CMD_GainVacationApplyInfo_G = 'G', //经理获取请假申请信息
    CMD_VacationAgree_A = 'A',       //经理同意请假
    CMD_VacationReject_J = 'J'       //经理拒绝请假
};

class GlobalVars
{
public:
    GlobalVars();

    static QQueue<QString> g_msgQueue; //消息队列

    static QList<QString> g_userOnlineList; //用户在线ID列表
    static UserOnlineMap g_userOnlineMap;   //用户在线Map

    static UserInfoList *g_userInfoList;
    static UserInfoMap g_userInfoMap;

    static StaffInfoList *g_staffInfoList;
    static StaffInfoMap g_staffInfoMap;

    static ManagerInfoList *g_managerInfoList;
    static ManagerInfoMap g_managerInfoMap;

    static DepartmentInfoList *g_departmentInfoList;
    static DepartmentInfoMap g_departmentInfoMap;

    static AttendanceInfoList *g_attendanceInfoList;
    static AttendanceInfoList *g_localStaffAttendanceInfoList;
    static AttendanceInfoMap g_attendanceInfoMap;

    static VacationInfoList *g_vacationInfoList;  //所有的假期申请信息
    static VacationInfoList *g_vacationApplyInfoList; //未读取的假期信息
    static VacationInfoMap g_vacationInfoMap;

    static AnnouncementInfoList *g_announcementInfoList;
    static AnnouncementInfoList *g_localGroupBulletinList;

    static ChatRecordInfoList *g_chatRecordInfoList;

};

#endif // GLOBALVARS_H
