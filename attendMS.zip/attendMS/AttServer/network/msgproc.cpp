#include "msgproc.h"

#include "execsql.h"
#include <QStringBuilder>
#include <QByteArray>

MsgProc::MsgProc(QThread *parent) : QThread(parent)
{
    m_isExit = false;
}

void MsgProc::exitThread(void)
{
    m_isExit = true;
}

void MsgProc::run()
{
    while(!m_isExit)
    {
        if(!GlobalVars::g_msgQueue.isEmpty())
        {
            QString msg = GlobalVars::g_msgQueue.dequeue();
            parseUserAsk(msg);
        }
        msleep(20);
    }
}

void MsgProc::parseUserAsk(QString msg)
{
    QStringList list = msg.split("#");
    int cmd = msg.at(0).toLatin1();

    switch (cmd) {
    ///通用请求命令
    ///
    case CMD_UserInfo_I:     parseUserInfo(list.at(1));  break;
    case CMD_ChangePswd_H:   parseChangePswd(list.at(1)); break;
    case CMD_UserRegister_R: parseUserRegister(list.at(1)); break;
    case CMD_GainGroupBulletin_B: parseUserGainGroupBulletin(list.at(1)); break;
    case CMD_GainGroupMember_M: parseUserGainGroupMember(list.at(1)); break;
    case CMD_SendGroupMessage_S: parseUserSendGroupMessage(list.at(1)); break;

    ///员工请求命令
    ///
    case CMD_StaffCheck_C:  parseStaffCheck(list.at(1)); break;
    case CMD_StaffVacation_V:  parseVacationApply(list.at(1)); break;
    case CMD_ObtainStaffAttendanceInfo_O: parseStaffAttendanceInfo(list.at(1)); break;

    ///经理请求
    ///
    case CMD_VacationAgree_A: parseVacationApplyResult(list.at(1)); break;
    case CMD_GainVacationApplyInfo_G: parseGainVacationApplyInfo(list.at(1)); break;
    case CMD_PublishGroupBulletin_P: parsePublishGroupBulletin(list.at(1)); break;
    default:
        break;
    }
}

void MsgProc::parseUserInfo(QString data)
{
    qDebug() << "MsgProc::parseUserInfo" << data;
    QStringList list = data.split("|");
    QString id = list.at(0);
    QString role = list.at(1);

    if(role == "经理")
    {
        if(GlobalVars::g_managerInfoMap.contains(id))
        {
            ManagerInfoList::iterator it = GlobalVars::g_managerInfoMap[id];
            QString msg = QString(CMD_UserInfo_I)
                    % QString("#!|") % it->getID()
                    % "|" % it->getName()
                    % "|" % it->getDept();

            emit signalSendMsgToClient(id, msg);
        }
    }else if(role == "员工")
    {
        if(GlobalVars::g_staffInfoMap.contains(id))
        {
            StaffInfoList::iterator it = GlobalVars::g_staffInfoMap[id];
            QString msg = QString(CMD_UserInfo_I)
                    % QString("#!|") % it->getID()
                    % "|" % it->getName()
                    % "|" % it->getDept()
                    % "|" % it->getPost();
            emit signalSendMsgToClient(id, msg);
        }
    }else
    {
        QString msg = QString(CMD_UserInfo_I)
                % QString("#?|") % QString("UserInfo error");
        emit signalSendMsgToClient(id, msg);
    }

}

void MsgProc::parseChangePswd(QString data)
{
    qDebug() << "MsgProc::parseChangePswd" << data;

    QStringList list = data.split("|");
    QString id = list.at(0);
    QString newPswd = list.at(1);

    if(ExecSQL::modifyUserInfoForPswd(id,newPswd))  //密码修改成功后给客户端发送修改成功的消息
    {
        QString msg = QString(CMD_ChangePswd_H) % QString("#")
                        % QString("!") % QString("|") % QString(id)
                        % QString("|") % QString(newPswd);

        emit signalSendMsgToClient(id,msg);
        emit signalUpdateTemp();

    }else
    {
        QString msg = QString(CMD_ChangePswd_H) % QString("#")
                        % QString("?") % QString("|") % QString(id)
                        % QString("|") % QString("change fail");

        emit signalSendMsgToClient(id,msg);
    }
}

void MsgProc::parseUserRegister(QString data)
{
    qDebug() << "MsgProc::parseUserRegister" << data;

    QStringList list = data.split("|");

    QString id = list.at(0);
    QString name = list.at(1);
    QString pswd = list.at(2);
    QString role = list.at(3);
    QString dept = list.at(4);
    QString date = list.at(5);

    UserInfo info(id, pswd, role, dept, date);
    if(ExecSQL::addNewUserInfo(info))
    {
        QString msg = QString(CMD_UserRegister_R) % QString("#")
                       % QString("!") % QString("|")
                       % QString(id) % QString("|")
                       % QString("register success");

        StaffInfo info(id,name,dept,"普通员工");
        ExecSQL::addNewStaffInfo(info);

        emit signalUpdateTemp();
    }
}

void MsgProc::parseUserGainGroupBulletin(QString data)
{
    qDebug() << "MsgProc::parseUserGainGroupBulletin" << data;

    QStringList list = data.split("|");
    QString managerID = list.at(0);
    QString userID = list.at(1);

    ExecSQL::updateLocalGroupBulletinList(QString("select * from announcement_info where manager_id = '%1'").arg(managerID));

    QString msg = QString(CMD_GainGroupBulletin_B) % QString("#");

    for(int i = 0; i < GlobalVars::g_localGroupBulletinList->length(); i++)
    {
        QString data = GlobalVars::g_localGroupBulletinList->at(i).getdateTime() % QString("|") %
                GlobalVars::g_localGroupBulletinList->at(i).getContent() % QString("$");

        msg.append(data);
    }

    emit signalSendMsgToClient(userID, msg);
}

void MsgProc::parseUserGainGroupMember(QString data)
{
    qDebug() << "MsgProc::parseUserGainGroupMember" << data;

     QString id = data;  //获取群成员的用户的ID

     QString msg = QString(CMD_GainGroupMember_M) % QString("#");

     ///先查找部门经理信息
     for(int i = 0; i < GlobalVars::g_managerInfoList->length(); i++)
     {
         if((GlobalVars::g_managerInfoMap[GlobalVars::g_managerInfoList->at(i).getID()]->getDept() == GlobalVars::g_userInfoMap[id]->getDept())
                 && (GlobalVars::g_userOnlineMap.find(GlobalVars::g_managerInfoList->at(i).getID())).value() == 1)
         {
             msg.append(GlobalVars::g_managerInfoList->at(i).getName() % "|[在线]");
         }else if((GlobalVars::g_managerInfoMap[GlobalVars::g_managerInfoList->at(i).getID()]->getDept() == GlobalVars::g_userInfoMap[id]->getDept())
                  && (GlobalVars::g_userOnlineMap.find(GlobalVars::g_managerInfoList->at(i).getID())).value() != 1)
         {
             msg.append(GlobalVars::g_managerInfoList->at(i).getName() % "|[离线]");
         }
     }

     msg.append("$");

     ///在查找员工信息
     for(int i = 0; i < GlobalVars::g_staffInfoList->length(); i++)
     {
         if((GlobalVars::g_staffInfoMap[GlobalVars::g_staffInfoList->at(i).getID()]->getDept() == GlobalVars::g_userInfoMap[id]->getDept())
                 && (GlobalVars::g_userOnlineMap.find(GlobalVars::g_staffInfoList->at(i).getID())).value() == 1)
         {
             msg.append(GlobalVars::g_staffInfoList->at(i).getName() % "|[在线]$");
         }else if((GlobalVars::g_staffInfoMap[GlobalVars::g_staffInfoList->at(i).getID()]->getDept() == GlobalVars::g_userInfoMap[id]->getDept())
                  && (GlobalVars::g_userOnlineMap.find(GlobalVars::g_staffInfoList->at(i).getID())).value() != 1)
         {
             msg.append(GlobalVars::g_staffInfoList->at(i).getName() % "|[离线]$");
         }
     }

     emit signalSendMsgToClient(id,msg);
}

void MsgProc::parseUserSendGroupMessage(QString data)
{
    qDebug() << "MsgProc::parseUserSendGroupMessage" << data;

    QStringList list = data.split("|");

    QString id = list.at(0);
    QString name = list.at(1);
    QString dept = list.at(2);
    QString dateTime = list.at(3);
    QString content = list.at(4);

    ChatRecordInfo info(id, name, dept, dateTime, content);

    ExecSQL::addNewChatRecordInfo(info);\
    emit signalUpdateTemp();   //更新服务器的缓冲区

    QString msg = QString(CMD_SendGroupMessage_S) % QString("#")
            % id % QString("|") % name % QString("|")
            % dept %QString("|") % dateTime % QString("|")
            % content;

    for(int i = 0; i < GlobalVars::g_userOnlineList.length(); i++)
    {
        if(GlobalVars::g_userInfoMap[GlobalVars::g_userOnlineList.at(i)]->getDept() == GlobalVars::g_userInfoMap[id]->getDept())
        {
            emit signalSendMsgToClient(GlobalVars::g_userOnlineList.at(i), msg);
        }
    }
}

/////////////////////员工请求命令/////////////////////////////

void MsgProc::parseStaffCheck(QString data)
{
    qDebug() << "MsgProc::parseStaffCheck" << data;

    QStringList list = data.split("|");

    QString staff_id = list.at(0);
    QString staff_name = list.at(1);
    QString staff_dept = list.at(2);
    QString workTime = list.at(3);
    QString endTime = list.at(4);
    QString date = list.at(5);

    if(endTime == "")
    {
        AttendanceInfo info(staff_id, staff_name, staff_dept,
                            workTime, endTime, date);
        if(ExecSQL::addNewAttendanceInfo(info))
        {
            emit signalUpdateTemp();
        }
    }else
    {
        if(ExecSQL::modifyAttendanceInfoForEndTime(staff_id, date, workTime, endTime))
        {
            emit signalUpdateTemp();
        }
    }

}

void MsgProc::parseStaffAttendanceInfo(QString data)
{
    qDebug() << "MsgProc::parseStaffAttendanceInfo";

    QString staffID = data;

    ExecSQL::updateLocalStaffAttendanceInfoList(QString("select * from attendance_info where staff_id = '%1'").arg(staffID));

    QString msg = QString(CMD_ObtainStaffAttendanceInfo_O) % QString("#");

    for(int i = 0; i < GlobalVars::g_localStaffAttendanceInfoList->length(); i++)
    {
        QString staffID = GlobalVars::g_localStaffAttendanceInfoList->at(i).getStaffID();
        QString staffName = GlobalVars::g_localStaffAttendanceInfoList->at(i).getStaffName();
        QString staffDept = GlobalVars::g_localStaffAttendanceInfoList->at(i).getStaffDept();
        QString workTime = GlobalVars::g_localStaffAttendanceInfoList->at(i).getWorkTime();
        QString endTime = GlobalVars::g_localStaffAttendanceInfoList->at(i).getEndTime();
        QString date = GlobalVars::g_localStaffAttendanceInfoList->at(i).getDate();

        QString data = staffID % QString("|") % staffName % QString("|")
                  % staffDept % QString("|") % workTime % QString("|")
                  % endTime % QString("|") % date % QString("$");

        msg.append(data);
    }

    signalSendMsgToClient(staffID, msg);
}

void MsgProc::parseVacationApply(QString data)
{
    qDebug() << "MsgProc::parseVacationApply" << data;

    QStringList list = data.split("|");

    QString staffID = list.at(0);
    QString staffName = list.at(1);
    QString staffDept = list.at(2);
    QString managerID = list.at(3);
    QString vacationDate = list.at(4);
    QString vacationReason = list.at(5);
    QString flag = list.at(6);

    VacationInfo info(staffID, staffName, staffDept, managerID,
                      vacationDate, vacationReason, flag);

    if(GlobalVars::g_userOnlineList.contains(managerID))  //如果经理在线，把请假信息发送给经理
    {
        QString msg = QString(CMD_StaffVacation_V)
                % QString("#") % staffID
                % QString("|") % staffName
                % QString("|") % staffDept
                % QString("|") % managerID
                % QString("|") % vacationDate
                % QString("|") % vacationReason
                % QString("|") % flag;

        ExecSQL::addNewVacationInfo(info);   //无论经理端在不在线都先写入数据库
        emit signalUpdateTemp();
        emit signalSendMsgToClient(managerID, msg);
    }else
    {
        ExecSQL::addNewVacationInfo(info);
        emit signalUpdateTemp();
    }
}

//////////////////////////经理请求命令///////////////////////////

void MsgProc::parseGainVacationApplyInfo(QString data)
{
    qDebug() << "MsgProc::parseGainVacationApplyInfo" << data;

    QString managerID = data;

    ExecSQL::updateVacationApplyInfoList(QString("select * from vacation_info where manager_id = '%1' and flag = '%2'")
                                         .arg(managerID).arg("0"));

    QString msg = QString(CMD_GainVacationApplyInfo_G) % QString("#");

    for(int i = 0; i < GlobalVars::g_vacationApplyInfoList->length(); i++)
    {
       QString staffID = GlobalVars::g_vacationApplyInfoList->at(i).getID();
       QString staffName = GlobalVars::g_vacationApplyInfoList->at(i).getName();
       QString staffDept = GlobalVars::g_vacationApplyInfoList->at(i).getDept();
       QString managerID = GlobalVars::g_vacationApplyInfoList->at(i).getManagerID();
       QString vacationDate = GlobalVars::g_vacationApplyInfoList->at(i).getVacationDate();
       QString vacationReason = GlobalVars::g_vacationApplyInfoList->at(i).getVacationReason();
       QString vacationFlag = GlobalVars::g_vacationApplyInfoList->at(i).getVacationFlag();

       QString data = staffID % QString("|") % staffName % QString("|")
             % staffDept % QString("|") % managerID % QString("|")
             % vacationDate % QString("|") % vacationReason % QString("|")
             % vacationFlag % QString("$");

       msg.append(data);
    }

    signalSendMsgToClient(managerID, msg);
}

void MsgProc::parseVacationApplyResult(QString data)
{
    qDebug() << "MsgProc::parseVacationApplyResult" << data;

    QStringList list = data.split("|");
    QString staffID = list.at(0);
    QString vacationDate = list.at(4);  
    QString flag = list.at(6);

    if(flag == "1")
    {
        ExecSQL::modifyVacationInfoForFlag(vacationDate, staffID, flag);
        QString msg = QString(CMD_VacationAgree_A) % QString("#")
                      % QString("vacation agreed");
        emit signalUpdateTemp();
        emit signalSendMsgToClient(staffID, msg);
    }else
    {
        ExecSQL::modifyVacationInfoForFlag(vacationDate, staffID, flag);
        QString msg = QString(CMD_VacationReject_J) % QString("#")
                      % QString("vacation rejected");
        emit signalUpdateTemp();
        emit signalSendMsgToClient(staffID, msg);
    }
}

void MsgProc::parsePublishGroupBulletin(QString data)
{
    qDebug() << "MsgProc::parsePublishGroupBulletin" << data;

    QStringList list = data.split("|");

    QString id = list.at(0);
    QString name = list.at(1);
    QString dept = list.at(2);
    QString dateTime = list.at(3);
    QString content = list.at(4);

    AnnouncementInfo info(id, name, dept, dateTime, content);
    ExecSQL::addNewAnnouncementInfo(info);

    emit signalUpdateTemp();     //更新缓冲区！

    QString msg = QString(CMD_PublishGroupBulletin_P) % QString("#")
            % id % QString("|") % name % QString("|")
            % dept %QString("|") % dateTime % QString("|")
            % content;

    for(int i = 0; i < GlobalVars::g_userOnlineList.length(); i++)
    {
        if(GlobalVars::g_userInfoMap[GlobalVars::g_userOnlineList.at(i)]->getDept() == GlobalVars::g_userInfoMap[id]->getDept())
        {
            emit signalSendMsgToClient(GlobalVars::g_userOnlineList.at(i), msg);
        }
    }
}
