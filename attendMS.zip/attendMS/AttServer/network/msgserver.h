#ifndef MSGSERVER_H
#define MSGSERVER_H

#include <QObject>
#include <QTcpServer>

#include "msgproc.h"
#include "msgsocket.h"
#include "userform.h"

class MsgServer : public QObject
{
    Q_OBJECT

signals:   
    void signalUpdateBuffer(void);
    void signalNewClientOnline(QString id);

public slots:
    void slotNewConnection();
    void slotRegisterSocket(QString id, MsgSocket *socket);
    void slotLogoutSocket(QString id, MsgSocket *socket);
    void slotSendMsgToClient(QString id, QString msg);

    void slotUpdateTemp(void);

public:
    explicit MsgServer(QObject *parent = 0);
    ~MsgServer();

private:
    QTcpServer *m_server;
    MsgProc *m_msgProc;
    SocketMap m_socketMap;

};

#endif // MSGSERVER_H
