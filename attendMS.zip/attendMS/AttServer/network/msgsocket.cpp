#include "msgsocket.h"

#include "execsql.h"
#include <QString>
#include <QStringBuilder>

MsgSocket::MsgSocket(QTcpSocket *socket,QObject *parent) : QObject(parent)
{
    qDebug() << "MsgSocket::MsgSocket";
    m_tcpBlockSize = 0;

    m_socket = socket;
    connect(m_socket, SIGNAL(disconnected()),
            m_socket, SLOT(deleteLater()));
    connect(m_socket, SIGNAL(readyRead()),
            this, SLOT(slotReadyRead()));
}

MsgSocket::~MsgSocket()
{

}

void MsgSocket::parseUserLogin(QString msg)
{
    qDebug() << "MsgSocket::parseUserLogin" << msg;

    QStringList list = msg.remove("L#").split("|");
    QString id = list.at(0);
    QString pswd = list.at(1);

    if(GlobalVars::g_userInfoMap.contains(id))
    {
        UserInfoList::iterator it = GlobalVars::g_userInfoMap[id];
        it->UserInfoDisplay();
        if(it->getPswd() == pswd)
        {
            QString msg = QString(CMD_UserLogin_L)
                    % QString("#!|") % it->getID()
                    % "|" % it->getPswd()
                    % "|" % it->getRole()
                    % "|" % it->getDate();
            this->slotSendMsg(msg);
            emit signalRegisterSocket(id, this);
        }else
        {
            QString msg = QString(CMD_UserLogin_L)
                    % QString("#?|") % QString("Error: UID Or Pswd!");
            this->slotSendMsg(msg);
        }
    }
}

void MsgSocket::parseUserExit(QString msg)
{
    qDebug() << "MsgSocket::parseUserExit" << msg;
    msg.remove("X#");

    emit signalLogoutSocket(msg, this);
    QString msg1 = QString(CMD_UserExit_X)
            % QString("#!|") % msg;
    if(this->slotSendMsg(msg1))
    {
        delete this;
    }
}

void MsgSocket::slotReadyRead()
{
    qDebug() << "MsgSocket::slotReadyRead()";
    QDataStream in(m_socket);
    in.setVersion(QDataStream::Qt_4_6);

    if(m_tcpBlockSize == 0)
    {
        if(m_socket->bytesAvailable()<sizeof(quint16))
            return;

        in >> m_tcpBlockSize;
    }

    if(m_socket->bytesAvailable() < m_tcpBlockSize)
        return;

    QString msg;
    in >> msg;
    qDebug() << "Server Recv: " << msg;

    if(msg.at(0) == CMD_UserLogin_L)
    {
        parseUserLogin(msg);
    }else if(msg.at(0) == CMD_UserExit_X)
    {
        parseUserExit(msg);
    }else
    {
        GlobalVars::g_msgQueue.enqueue(msg);
    }
    m_tcpBlockSize = 0;
}

bool MsgSocket::slotSendMsg(QString msg)
{
    QByteArray buffer;
    QDataStream out(&buffer, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_6);

    out << (quint16)0;
    out << msg;
    out.device()->seek(0);
    out << (quint16)(buffer.size() - sizeof(quint16));

    qDebug() << "Server Send: " << msg;
    return m_socket->write(buffer);
}

