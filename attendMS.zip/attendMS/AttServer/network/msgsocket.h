#ifndef MSGSOCKET_H
#define MSGSOCKET_H

#include <QObject>
#include <QTcpSocket>

class MsgSocket : public QObject
{
    Q_OBJECT

signals:
    void signalRegisterSocket(QString id, MsgSocket *socket);
    void signalLogoutSocket(QString id, MsgSocket *socket);

public slots:    
    void slotReadyRead();
    bool slotSendMsg(QString msg);

public:
    explicit MsgSocket(QTcpSocket *socket,QObject *parent = 0);
    ~MsgSocket();
    QString m_localUid;

private:
    quint16 m_tcpBlockSize;
    QTcpSocket *m_socket;

    void parseUserLogin(QString msg);
    void parseUserExit(QString msg);
};

typedef QMap<QString, MsgSocket*> SocketMap;

#endif // MSGSOCKET_H
