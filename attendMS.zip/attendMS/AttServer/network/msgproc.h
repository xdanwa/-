#ifndef MSGPROC_H
#define MSGPROC_H

#include <QThread>

class MsgProc : public QThread
{
    Q_OBJECT
public:
    explicit MsgProc(QThread *parent = 0);
    void exitThread(void);

protected:
    void run();

signals:
    void signalSendMsgToClient(QString id, QString msg);

    void signalUpdateTemp(void);

public slots:


private:
    bool m_isExit;

    void parseUserAsk(QString msg);

    ///通用请求命令
    void parseUserInfo(QString data);
    void parseChangePswd(QString data);
    void parseUserRegister(QString data);  //解析用户注册

    void parseUserGainGroupBulletin(QString data);  //用户获取群公告信息
    void parseUserGainGroupMember(QString data);    //用户获取群成员信息
    void parseUserSendGroupMessage(QString data);   //用户发送群消息

    ///员工请求命令
    void parseStaffCheck(QString data);    //解析员工打卡
    void parseVacationApply(QString data);  //解析员工假期申请
    void parseStaffAttendanceInfo(QString data);  //解析员工打卡记录的信息

    ///经理请求命令
    void parseGainVacationApplyInfo(QString data);
    void parseVacationApplyResult(QString data);

    void parsePublishGroupBulletin(QString data);  //解析经理发布群公告！

};

#endif // MSGPROC_H
