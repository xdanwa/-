#include "msgserver.h"
#include <QStringBuilder>

#include "execsql.h"

MsgServer::MsgServer(QObject *parent) : QObject(parent)
{
    m_socketMap.clear();
    m_msgProc = new MsgProc;
    m_server = new QTcpServer(this);
    connect(m_server, SIGNAL(newConnection()),
            this, SLOT(slotNewConnection()));

    connect(m_msgProc, SIGNAL(signalSendMsgToClient(QString,QString)),
            this, SLOT(slotSendMsgToClient(QString,QString)));

    connect(m_msgProc, SIGNAL(signalUpdateTemp()),
            this, SLOT(slotUpdateTemp()));

    m_server->listen(QHostAddress::Any, 55555);

    m_msgProc->start();   //开个子线程
}

MsgServer::~MsgServer()
{
    m_msgProc->exitThread();
    if(m_msgProc->wait())
    {
        delete m_msgProc;
    }
}

void MsgServer::slotNewConnection()
{
    qDebug() << "ServerUI::slotNewConnection()";
    QTcpSocket *socket = m_server->nextPendingConnection();
    MsgSocket *msgSocket = new MsgSocket(socket);
    connect(msgSocket, SIGNAL(signalRegisterSocket(QString,MsgSocket*)),
            this, SLOT(slotRegisterSocket(QString,MsgSocket*)));
    connect(msgSocket, SIGNAL(signalLogoutSocket(QString,MsgSocket*)),
            this, SLOT(slotLogoutSocket(QString,MsgSocket*)));
}

void MsgServer::slotRegisterSocket(QString id, MsgSocket *socket)
{
    m_socketMap.insert(id, socket); //登录成功，添加Socket到g_socketMap
    GlobalVars::g_userOnlineList.append(id);
    GlobalVars::g_userOnlineMap.insert(id,1);

    ///某客户端上线，告知其他线上客户端
    for(int i = 0; i < GlobalVars::g_userOnlineList.length(); i++)
    {
        if(GlobalVars::g_userOnlineList.at(i) != id
                && GlobalVars::g_userInfoMap[GlobalVars::g_userOnlineList.at(i)]->getDept()
                == GlobalVars::g_userInfoMap[id]->getDept())
        {
            QString msg = QString(CMD_NewClientOnline_N) % "#";

            if(GlobalVars::g_userInfoMap[id]->getRole() == "经理")
            {
                msg.append(GlobalVars::g_managerInfoMap[id]->getName());
            }else
            {
                msg.append(GlobalVars::g_staffInfoMap[id]->getName());
            }

            m_socketMap[GlobalVars::g_userOnlineList.at(i)]->slotSendMsg(msg);
        }
    }
}

void MsgServer::slotLogoutSocket(QString id, MsgSocket *socket)
{
    if(m_socketMap.contains(id))
    {
        m_socketMap.remove(id);
    }

    if(GlobalVars::g_userOnlineMap.contains(id))
    {
        GlobalVars::g_userOnlineMap.remove(id);
    }

    for(int i = 0; i < GlobalVars::g_userOnlineList.length(); i++)
    {
        if(GlobalVars::g_userOnlineList.at(i) == id)
        {
            GlobalVars::g_userOnlineList.removeAt(i);
        }
    }

    ///某客户端离线，告知其他线上客户端。
    for(int i = 0; i < GlobalVars::g_userOnlineList.length(); i++)
    {
        if(GlobalVars::g_userOnlineList.at(i) != id
                && GlobalVars::g_userInfoMap[GlobalVars::g_userOnlineList.at(i)]->getDept()
                == GlobalVars::g_userInfoMap[id]->getDept())
        {
            QString msg = QString(CMD_ClientOffline_F) % "#";

            if(GlobalVars::g_userInfoMap[id]->getRole() == "经理")
            {
                msg.append(GlobalVars::g_managerInfoMap[id]->getName());
            }else
            {
                msg.append(GlobalVars::g_staffInfoMap[id]->getName());
            }

            m_socketMap[GlobalVars::g_userOnlineList.at(i)]->slotSendMsg(msg);
        }
    }
}

void MsgServer::slotSendMsgToClient(QString id, QString msg)
{
    if(m_socketMap.contains(id))
    {
        m_socketMap[id]->slotSendMsg(msg);
    }
}

void MsgServer::slotUpdateTemp(void)
{
    emit signalUpdateBuffer();
}

