#include "chatrecordform.h"
#include "ui_chatrecordform.h"

#include "execsql.h"

ChatRecordForm::ChatRecordForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChatRecordForm)
{
    ui->setupUi(this);

    ui->pb_search->setFlat(true);

    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");

    m_searchCond = Search_None;

    on_pb_search_clicked();
}

ChatRecordForm::~ChatRecordForm()
{
    delete ui;
}

void ChatRecordForm::slotUpdateBuffer(void)
{
    on_pb_search_clicked();
}

void ChatRecordForm::updateTableInfos(void)
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(5);

    // set header lables
    QStringList headers;
    headers << "编号" << "姓名" << "部门" << "日期" << "内容";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->tableWidget->setRowCount(GlobalVars::g_chatRecordInfoList->length());
    for(int i=0; i < GlobalVars::g_chatRecordInfoList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_chatRecordInfoList->at(i).getID());
        ui->tableWidget->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_chatRecordInfoList->at(i).getName());
        ui->tableWidget->setItem(i, 1, item);
        item = new  QTableWidgetItem(GlobalVars::g_chatRecordInfoList->at(i).getDept());
        ui->tableWidget->setItem(i, 2, item);
        item = new  QTableWidgetItem(GlobalVars::g_chatRecordInfoList->at(i).getdateTime());
        ui->tableWidget->setItem(i, 3, item);
        item = new  QTableWidgetItem(GlobalVars::g_chatRecordInfoList->at(i).getContent());
        ui->tableWidget->setItem(i, 4, item);
    }
}

void ChatRecordForm::on_cb_condition_currentIndexChanged(int index)
{
    m_searchCond = index;
    if(m_searchCond == Search_None)
    {
        ui->le_condition->setEnabled(false);
    }else
    {
        ui->le_condition->setEnabled(true);
    }
}

void ChatRecordForm::on_pb_search_clicked()
{
    if(m_searchCond == Search_Name)
    {
        ExecSQL::searchChatRecordInfoForName(ui->le_condition->text());
    }else if(m_searchCond == Search_Dept)
    {
        ExecSQL::searchChatRecordInfoForDept(ui->le_condition->text());
    }else if(m_searchCond == Search_Date)
    {
        ExecSQL::searchChatRecordInfoForDate(ui->le_condition->text());
    }else
    {
        ExecSQL::searchAllChatRecordInfos();
    }

    updateTableInfos();
}
