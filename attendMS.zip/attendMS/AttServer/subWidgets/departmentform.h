#ifndef DEPARTMENTFORM_H
#define DEPARTMENTFORM_H

#include <QWidget>

#include "execsql.h"

namespace Ui {
class DepartmentForm;
}

class DepartmentForm : public QWidget
{
    Q_OBJECT

public:
    explicit DepartmentForm(QWidget *parent = 0);
    ~DepartmentForm();

    enum Search_Condition{
        Search_None = 0,
        Search_ID,
        Search_Name,
        Search_Count,
        Search_Manager
    };

private slots:
    void on_cb_condition_currentIndexChanged(int index);

    void on_pb_search_clicked();

    void on_tableWidget_clicked(const QModelIndex &index);

    void on_pb_modify_clicked();

    void on_pb_delete_clicked();

    void on_pb_add_clicked();

    void on_pb_cancel_clicked();

    void on_pb_save_clicked();

private:
    Ui::DepartmentForm *ui;

    int m_operData;
    int m_searchCond;

    void updateTableInfos(void);

};

#endif // DEPARTMENTFORM_H
