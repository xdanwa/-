#ifndef STAFFFORM_H
#define STAFFFORM_H

#include <QWidget>

#include "execsql.h"

namespace Ui {
class StaffForm;
}

class StaffForm : public QWidget
{
    Q_OBJECT

public:
    explicit StaffForm(QWidget *parent = 0);
    ~StaffForm();

    enum Search_Condition{
        Search_None = 0,
        Search_ID,
        Search_Name,
        Search_Dept,
        Search_Post
    };

public slots:
    void slotUpdateBuffer(void);

private slots:
    void on_cb_condition_currentIndexChanged(int index);

    void on_pb_search_clicked();

    void on_tableWidget_clicked(const QModelIndex &index);

    void on_pb_modify_clicked();

    void on_pb_delete_clicked();

    void on_pb_add_clicked();

    void on_pb_cancel_clicked();

    void on_pb_save_clicked();

private:
    Ui::StaffForm *ui;

    int m_operData;
    int m_searchCond;

    void updateTableInfos(void);
};

#endif // STAFFFORM_H
