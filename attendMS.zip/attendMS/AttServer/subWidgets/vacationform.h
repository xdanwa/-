#ifndef VACATIONFORM_H
#define VACATIONFORM_H

#include <QWidget>

#include "execsql.h"

namespace Ui {
class VacationForm;
}

class VacationForm : public QWidget
{
    Q_OBJECT

public:
    explicit VacationForm(QWidget *parent = 0);
    ~VacationForm();

    enum Search_Condition{
        Search_None = 0,
        Search_StaffID,
        Search_StaffName,
        Search_StaffDept,
        Search_vacationDate
    };

public slots:
    void slotUpdateBuffer(void);

private slots:
    void on_cb_condition_currentIndexChanged(int index);

    void on_pb_search_clicked();

private:
    Ui::VacationForm *ui;
    int m_searchCond;

    void updateTableInfos(void);

};

#endif // VACATIONFORM_H
