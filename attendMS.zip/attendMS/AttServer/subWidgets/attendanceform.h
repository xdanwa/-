#ifndef ATTENDANCEFORM_H
#define ATTENDANCEFORM_H

#include <QWidget>

#include "execsql.h"

namespace Ui {
class AttendanceForm;
}

class AttendanceForm : public QWidget
{
    Q_OBJECT

public:
    explicit AttendanceForm(QWidget *parent = 0);
    ~AttendanceForm();

    enum Search_Condition{
        Search_None = 0,
        Search_ID,
        Search_Name,
        Search_Dept,
        Search_Date
    };
public slots:
    void slotUpdateBuffer(void);

private slots:
    void on_cb_condition_currentIndexChanged(int index);

    void on_pb_search_clicked();

private:
    Ui::AttendanceForm *ui;

    int m_searchCond;

    void updateTableInfos(void);
};

#endif // ATTENDANCEFORM_H
