#include "managerform.h"
#include "ui_managerform.h"

ManagerForm::ManagerForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ManagerForm)
{
    ui->setupUi(this);
    ui->pb_search->setFlat(true);

    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");

    m_operData = Oper_None;
    m_searchCond = Search_None;

    on_pb_search_clicked();
}

ManagerForm::~ManagerForm()
{
    delete ui;
}

void ManagerForm::on_cb_condition_currentIndexChanged(int index)
{
    m_searchCond = index;
    if(m_searchCond == Search_None)
    {
        ui->le_condition->setEnabled(false);
    }else
    {
        ui->le_condition->setEnabled(true);
    }
}

void ManagerForm::updateTableInfos(void)
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);

    // set header lables
    QStringList headers;
    headers << "工号" << "姓名"  << "部门" << "电话";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->tableWidget->setRowCount(GlobalVars::g_managerInfoList->length());
    for(int i=0; i < GlobalVars::g_managerInfoList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_managerInfoList->at(i).getID());
        ui->tableWidget->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_managerInfoList->at(i).getName());
        ui->tableWidget->setItem(i, 1, item);
        item = new  QTableWidgetItem(GlobalVars::g_managerInfoList->at(i).getDept());
        ui->tableWidget->setItem(i, 2, item);
    }
}

void ManagerForm::on_pb_search_clicked()
{
    if(m_searchCond == Search_ID)
    {
        ExecSQL::searchManagerInfoForID(ui->le_condition->text());
    }else if(m_searchCond == Search_Name)
    {
        ExecSQL::searchManagerInfoForName(ui->le_condition->text());
    }else if(m_searchCond == Search_Dept)
    {
        ExecSQL::searchManagerInfoForDept(ui->le_condition->text());
    }else
    {
        ExecSQL::searchAllManagerInfos();
    }

    updateTableInfos();
}

void ManagerForm::on_tableWidget_clicked(const QModelIndex &index)
{
    const ManagerInfo &info(GlobalVars::g_managerInfoList->at(index.row()));

    ui->le_id->setText(info.getID());
    ui->le_name->setText(info.getName());
    ui->le_dept->setText(info.getDept());
}

void ManagerForm::on_pb_modify_clicked()
{
    m_operData = Oper_Mdy;

    ui->pb_save->setEnabled(true);
    ui->le_name->setEnabled(true);
    ui->le_dept->setEnabled(true);
    ui->le_contanct->setEnabled(true);
}

void ManagerForm::on_pb_delete_clicked()
{
    m_operData = Oper_Del;

    ui->pb_save->setEnabled(true);
}

void ManagerForm::on_pb_add_clicked()
{
    m_operData = Oper_Add;

    ui->pb_save->setEnabled(true);
    ui->le_id->setEnabled(true);
    ui->le_name->setEnabled(true);
    ui->le_dept->setEnabled(true);
    ui->le_contanct->setEnabled(true);
}

void ManagerForm::on_pb_cancel_clicked()
{
    m_operData = Oper_Cancel;

    ui->le_id->clear();
    ui->le_name->clear();
    ui->le_dept->clear();
    ui->le_contanct->clear();

    ui->le_id->setEnabled(false);
    ui->le_name->setEnabled(false);
    ui->le_dept->setEnabled(false);
    ui->le_contanct->setEnabled(false);
}

void ManagerForm::on_pb_save_clicked()
{
   if(m_operData == Oper_Del)
   {
       ExecSQL::removeManagerInfo(ui->le_id->text());
   }else if(m_operData == Oper_Add)
   {
       ManagerInfo info(ui->le_id->text(),ui->le_name->text(),
                        ui->le_dept->text());
       ExecSQL::addNewManagerInfo(info);
   }else if(m_operData == Oper_Mdy)
   {
       ExecSQL::modifyManagerInfoForName(ui->le_id->text(), ui->le_name->text());
       ExecSQL::modifyManagerInfoForDept(ui->le_id->text(), ui->le_dept->text());
   }

   ui->pb_save->setEnabled(false);
   ui->le_id->setEnabled(false);
   ui->le_dept->setEnabled(false);
   ui->le_name->setEnabled(false);
   ui->le_contanct->setEnabled(false);

   on_pb_cancel_clicked();
   on_pb_search_clicked();
}
