#ifndef ANNOUNCEMENTFORM_H
#define ANNOUNCEMENTFORM_H

#include <QWidget>

namespace Ui {
class AnnouncementForm;
}

class AnnouncementForm : public QWidget
{
    Q_OBJECT

public:
    explicit AnnouncementForm(QWidget *parent = 0);
    ~AnnouncementForm();

    enum Search_Condition{
        Search_None = 0,
        Search_Name,
        Search_Date
    };

public slots:
    void slotUpdateBuffer(void);

private slots:
    void on_cb_condition_currentIndexChanged(int index);

    void on_pb_search_clicked();

private:
    Ui::AnnouncementForm *ui;

    int m_searchCond;

    void updateTableInfos(void);
};

#endif // ANNOUNCEMENTFORM_H
