#include "attendanceform.h"
#include "ui_attendanceform.h"

AttendanceForm::AttendanceForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AttendanceForm)
{
    ui->setupUi(this);
    ui->pb_search->setFlat(true);

    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");

    m_searchCond = Search_None;
    on_pb_search_clicked();
}

AttendanceForm::~AttendanceForm()
{
    delete ui;
}

void AttendanceForm::slotUpdateBuffer(void)
{
    on_pb_search_clicked();
}

void AttendanceForm::updateTableInfos(void)
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(6);

    // set header lables
    QStringList headers;
    headers << "员工号" << "员工姓名"  << "部门" << "工作开始时间" << "工作结束时间" << "日期";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->tableWidget->setRowCount(GlobalVars::g_attendanceInfoList->length());
    for(int i=0; i < GlobalVars::g_attendanceInfoList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_attendanceInfoList->at(i).getStaffID());
        ui->tableWidget->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_attendanceInfoList->at(i).getStaffName());
        ui->tableWidget->setItem(i, 1, item);
        item = new  QTableWidgetItem(GlobalVars::g_attendanceInfoList->at(i).getStaffDept());
        ui->tableWidget->setItem(i, 2, item);
        item = new  QTableWidgetItem(GlobalVars::g_attendanceInfoList->at(i).getWorkTime());
        ui->tableWidget->setItem(i, 3, item);
        item = new  QTableWidgetItem(GlobalVars::g_attendanceInfoList->at(i).getEndTime());
        ui->tableWidget->setItem(i, 4, item);
        item = new  QTableWidgetItem(GlobalVars::g_attendanceInfoList->at(i).getDate());
        ui->tableWidget->setItem(i, 5, item);
    }
}

void AttendanceForm::on_cb_condition_currentIndexChanged(int index)
{
    m_searchCond = index;
    if(m_searchCond == Search_None)
    {
        ui->le_condition->setEnabled(false);
    }else
    {
        ui->le_condition->setEnabled(true);
    }
}

void AttendanceForm::on_pb_search_clicked()
{
    if(m_searchCond == Search_ID)
    {
        ExecSQL::searchAttendanceInfoForID(ui->le_condition->text());
    }else if(m_searchCond == Search_Name)
    {
        ExecSQL::searchAttendanceInfoForName(ui->le_condition->text());
    }else if(m_searchCond == Search_Dept)
    {
        ExecSQL::searchAttendanceInfoForDept(ui->le_condition->text());
    }else if(m_searchCond == Search_Date)
    {
        ExecSQL::searchAttendanceInfoForDate(ui->le_condition->text());
    }else
    {
        ExecSQL::searchAllAttendanceInfos();
    }

    updateTableInfos();
}
