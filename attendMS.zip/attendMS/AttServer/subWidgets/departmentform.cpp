#include "departmentform.h"
#include "ui_departmentform.h"

DepartmentForm::DepartmentForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DepartmentForm)
{
    ui->setupUi(this);
    ui->pb_search->setFlat(true);

    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");

    m_operData = Oper_None;
    m_searchCond = Search_None;
    on_pb_search_clicked();
}

DepartmentForm::~DepartmentForm()
{
    delete ui;
}

void DepartmentForm::on_cb_condition_currentIndexChanged(int index)
{
    m_searchCond = index;

    if(m_searchCond == Search_None)
    {
        ui->le_condition->setEnabled(false);
    }else
    {
        ui->le_condition->setEnabled(true);
    }
}

void DepartmentForm::updateTableInfos(void)
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);

    // set header lables
    QStringList headers;
    headers << "编号" << "姓名"  << "人数" << "经理";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->tableWidget->setRowCount(GlobalVars::g_departmentInfoList->length());
    for(int i=0; i < GlobalVars::g_departmentInfoList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_departmentInfoList->at(i).getID());
        ui->tableWidget->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_departmentInfoList->at(i).getName());
        ui->tableWidget->setItem(i, 1, item);
        item = new  QTableWidgetItem(GlobalVars::g_departmentInfoList->at(i).getCount());
        ui->tableWidget->setItem(i, 2, item);
        item = new  QTableWidgetItem(GlobalVars::g_departmentInfoList->at(i).getManager());
        ui->tableWidget->setItem(i, 3, item);
    }
}

void DepartmentForm::on_pb_search_clicked()
{
    if(m_searchCond == Search_ID)
    {
        ExecSQL::searchDepartmentInfoForID(ui->le_condition->text());
    }else if(m_searchCond == Search_Name)
    {
        ExecSQL::searchDepartmentInfoForName(ui->le_condition->text());
    }else if(m_searchCond == Search_Count)
    {
        ExecSQL::searchDepartmentInfoForCount(ui->le_condition->text());
    }else if(m_searchCond == Search_Manager)
    {
        ExecSQL::searchDepartmentInfoForManager(ui->le_condition->text());
    }else
    {
        ExecSQL::searchAllDepartmentInfos();
    }

    updateTableInfos();
}

void DepartmentForm::on_tableWidget_clicked(const QModelIndex &index)
{
    const DepartmentInfo info = GlobalVars::g_departmentInfoList->at(index.row());

    ui->le_id->setText(info.getID());
    ui->le_name->setText(info.getName());
    ui->le_count->setText(info.getCount());
    ui->le_manager->setText(info.getManager());
}


void DepartmentForm::on_pb_modify_clicked()
{
    m_operData = Oper_Mdy;

    ui->pb_save->setEnabled(true);
    ui->le_name->setEnabled(true);
    ui->le_count->setEnabled(true);
    ui->le_manager->setEnabled(true);
}

void DepartmentForm::on_pb_delete_clicked()
{
    m_operData = Oper_Del;

    ui->pb_save->setEnabled(true);
}

void DepartmentForm::on_pb_add_clicked()
{
    m_operData = Oper_Add;

    ui->pb_save->setEnabled(true);
    ui->le_id->setEnabled(true);
    ui->le_name->setEnabled(true);
    ui->le_count->setEnabled(true);
    ui->le_manager->setEnabled(true);
}

void DepartmentForm::on_pb_cancel_clicked()
{
    m_operData = Oper_Cancel;

    ui->le_id->clear();
    ui->le_name->clear();
    ui->le_count->clear();
    ui->le_manager->clear();
}

void DepartmentForm::on_pb_save_clicked()
{
    if(m_operData == Oper_Add)
    {
        DepartmentInfo info(ui->le_id->text(), ui->le_name->text(),
                            ui->le_count->text(), ui->le_manager->text());
        ExecSQL::addNewDepartmentInfo(info);
    }else if(m_operData == Oper_Del)
    {
        ExecSQL::removeDepartmentInfo(ui->le_id->text());
    }else if(m_operData == Oper_Mdy)
    {
        ExecSQL::modifyDepartmentInfoForName(ui->le_id->text(),ui->le_name->text());
        ExecSQL::modifyDepartmentInfoForCount(ui->le_id->text(), ui->le_count->text());
        ExecSQL::modifyDepartmentInfoForManager(ui->le_id->text(), ui->le_manager->text());
    }

    ui->le_id->setEnabled(false);
    ui->le_name->setEnabled(false);
    ui->le_count->setEnabled(false);
    ui->le_manager->setEnabled(false);
    ui->pb_save->setEnabled(false);
    on_pb_cancel_clicked();
    on_pb_search_clicked();
}
