#include "vacationform.h"
#include "ui_vacationform.h"

VacationForm::VacationForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VacationForm)
{
    ui->setupUi(this);
    ui->pb_search->setFlat(true);

    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");

    on_pb_search_clicked();
}

VacationForm::~VacationForm()
{
    delete ui;
}

void VacationForm::slotUpdateBuffer(void)
{
    on_pb_search_clicked();
}

void VacationForm::updateTableInfos(void)
{

    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(7);

    // set header lables
    QStringList headers;
    headers << "员工号" << "员工姓名"  << "员工部门" << "经理编号" << "请假日期" << "请假原因" << "是否批准(0否1批)";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->tableWidget->setRowCount(GlobalVars::g_vacationInfoList->length());
    for(int i=0; i < GlobalVars::g_vacationInfoList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getID());
        ui->tableWidget->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getName());
        ui->tableWidget->setItem(i, 1, item);
        item = new  QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getDept());
        ui->tableWidget->setItem(i, 2, item);
        item = new  QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getManagerID());
        ui->tableWidget->setItem(i, 3, item);
        item = new  QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getVacationDate());
        ui->tableWidget->setItem(i, 4, item);
        item = new  QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getVacationReason());
        ui->tableWidget->setItem(i, 5, item);
        item = new  QTableWidgetItem(GlobalVars::g_vacationInfoList->at(i).getVacationFlag());
        ui->tableWidget->setItem(i, 6, item);
    }
}

void VacationForm::on_cb_condition_currentIndexChanged(int index)
{
    m_searchCond = index;
    if(m_searchCond == Search_None)
    {
        ui->le_condition->setEnabled(false);
    }else
    {
        ui->le_condition->setEnabled(true);
    }
}

void VacationForm::on_pb_search_clicked()
{
    if(m_searchCond == Search_StaffID)
    {
        ExecSQL::searchVacationInfoForID(ui->le_condition->text());
    }else if(m_searchCond == Search_StaffName)
    {
        ExecSQL::searchVacationInfoForName(ui->le_condition->text());
    }else if(m_searchCond == Search_StaffDept)
    {
        ExecSQL::searchVacationInfoForDept(ui->le_condition->text());
    }else if(m_searchCond == Search_vacationDate)
    {
        ExecSQL::searchVacationInfoForDate(ui->le_condition->text());
    }else
    {
        ExecSQL::searchAllVacationInfos();
    }

    updateTableInfos();
}
