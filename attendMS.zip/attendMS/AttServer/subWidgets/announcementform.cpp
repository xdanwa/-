#include "announcementform.h"
#include "ui_announcementform.h"

#include "execsql.h"

AnnouncementForm::AnnouncementForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AnnouncementForm)
{
    ui->setupUi(this);
    ui->pb_search->setFlat(true);

    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");

    m_searchCond = Search_None;

    on_pb_search_clicked();
}

AnnouncementForm::~AnnouncementForm()
{
    delete ui;
}

void AnnouncementForm::slotUpdateBuffer(void)
{
   on_pb_search_clicked();
}

void AnnouncementForm::updateTableInfos(void)
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(2);

    // set header lables
    QStringList headers;
    headers << "日期" << "内容";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->tableWidget->setRowCount(GlobalVars::g_announcementInfoList->length());
    for(int i=0; i < GlobalVars::g_announcementInfoList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_announcementInfoList->at(i).getdateTime());
        ui->tableWidget->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_announcementInfoList->at(i).getContent());
        ui->tableWidget->setItem(i, 1, item);
    }
}

void AnnouncementForm::on_cb_condition_currentIndexChanged(int index)
{
    m_searchCond = index;
    if(m_searchCond == Search_None)
    {
        ui->le_condition->setEnabled(false);
    }else
    {
        ui->le_condition->setEnabled(true);
    }
}

void AnnouncementForm::on_pb_search_clicked()
{
    if(m_searchCond == Search_Name)
    {
        ExecSQL::searchAnnouncementInfoForName(ui->le_condition->text());
    }else if(m_searchCond == Search_Date)
    {
        ExecSQL::searchAnnouncementInfoForDate(ui->le_condition->text());
    }else
    {
        ExecSQL::searchAllAnnouncementInfos();
    }

    updateTableInfos();
}
