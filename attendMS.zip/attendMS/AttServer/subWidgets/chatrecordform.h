#ifndef CHATRECORDFORM_H
#define CHATRECORDFORM_H

#include <QWidget>

namespace Ui {
class ChatRecordForm;
}

class ChatRecordForm : public QWidget
{
    Q_OBJECT

public:
    explicit ChatRecordForm(QWidget *parent = 0);
    ~ChatRecordForm();

    enum Search_Condition{
        Search_None = 0,
        Search_ID,
        Search_Name,
        Search_Date,
        Search_Dept
    };

public slots:

    void slotUpdateBuffer(void);

private slots:
    void on_cb_condition_currentIndexChanged(int index);

    void on_pb_search_clicked();

private:
    Ui::ChatRecordForm *ui;

    int m_searchCond;

    void updateTableInfos(void);
};

#endif // CHATRECORDFORM_H
