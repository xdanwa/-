#include "staffform.h"
#include "ui_staffform.h"

StaffForm::StaffForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StaffForm)
{
    ui->setupUi(this);
    ui->pb_search->setFlat(true);

    ui->tableWidget->setStyleSheet("background-color:rgba(0,0,0,0)");

    m_searchCond = Search_None;
    m_operData == Oper_None;

    on_pb_search_clicked();
}

StaffForm::~StaffForm()
{
    delete ui;
}

void StaffForm::on_cb_condition_currentIndexChanged(int index)
{
    m_searchCond = index;

    if(m_searchCond == Search_None)
    {
        ui->le_condition->setEnabled(false);
    }else
    {
        ui->le_condition->setEnabled(true);
    }
}

void StaffForm::updateTableInfos(void)
{
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(4);

    // set header lables
    QStringList headers;
    headers << "工号" << "姓名"  << "部门" << "职务";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->tableWidget->setRowCount(GlobalVars::g_staffInfoList->length());
    for(int i=0; i < GlobalVars::g_staffInfoList->length(); i++)
    {
        QTableWidgetItem *item = new  QTableWidgetItem(GlobalVars::g_staffInfoList->at(i).getID());
        ui->tableWidget->setItem(i, 0, item);
        item = new  QTableWidgetItem(GlobalVars::g_staffInfoList->at(i).getName());
        ui->tableWidget->setItem(i, 1, item);
        item = new  QTableWidgetItem(GlobalVars::g_staffInfoList->at(i).getDept());
        ui->tableWidget->setItem(i, 2, item);
        item = new  QTableWidgetItem(GlobalVars::g_staffInfoList->at(i).getPost());
        ui->tableWidget->setItem(i, 3, item);
    }
}

void StaffForm::on_pb_search_clicked()
{
    if(m_searchCond == Search_ID)
    {
        ExecSQL::searchStaffInfoForID(ui->le_condition->text());
    }else if(m_searchCond == Search_Name)
    {
        ExecSQL::searchStaffInfoForName(ui->le_condition->text());
    }else if(m_searchCond == Search_Dept)
    {
        ExecSQL::searchStaffInfoForDept(ui->le_condition->text());
    }else if(m_searchCond == Search_Post)
    {
        ExecSQL::searchStaffInfoForPost(ui->le_condition->text());
    }else
    {
        ExecSQL::searchAllStaffInfos();
    }

    updateTableInfos();
}

void StaffForm::on_tableWidget_clicked(const QModelIndex &index)
{
    const StaffInfo &info = GlobalVars::g_staffInfoList->at(index.row());

    ui->le_id->setText(info.getID());
    ui->le_name->setText(info.getName());
    ui->le_dept->setText(info.getDept());
    ui->le_post->setText(info.getPost());
}

void StaffForm::on_pb_modify_clicked()
{
    m_operData = Oper_Mdy;

    ui->pb_save->setEnabled(true);
    ui->le_name->setEnabled(true);
    ui->le_dept->setEnabled(true);
    ui->le_post->setEnabled(true);
}

void StaffForm::on_pb_delete_clicked()
{
    m_operData = Oper_Del;
    ui->pb_save->setEnabled(true);
}

void StaffForm::on_pb_add_clicked()
{
    m_operData = Oper_Add;

    ui->pb_save->setEnabled(true);
    ui->le_id->setEnabled(true);
    ui->le_name->setEnabled(true);
    ui->le_dept->setEnabled(true);
    ui->le_post->setEnabled(true);
}

void StaffForm::on_pb_cancel_clicked()
{
    m_operData = Oper_Cancel;

    ui->le_id->clear();
    ui->le_name->clear();
    ui->le_dept->clear();
    ui->le_post->clear();
}

void StaffForm::on_pb_save_clicked()
{
    if(m_operData == Oper_Add)
    {
        StaffInfo info(ui->le_id->text(),ui->le_name->text(),
                       ui->le_dept->text(), ui->le_post->text());
        ExecSQL::addNewStaffInfo(info);
    }else if(m_operData == Oper_Del)
    {
        ExecSQL::removeStaffInfo(ui->le_id->text());
    }else if(m_operData == Oper_Mdy)
    {
        ExecSQL::modifyStaffInfoForName(ui->le_id->text(), ui->le_name->text());
        ExecSQL::modifyStaffInfoForDept(ui->le_id->text(), ui->le_dept->text());
        ExecSQL::modifyStaffInfoForPost(ui->le_id->text(), ui->le_post->text());
    }

    ui->pb_save->setEnabled(false);
    ui->le_id->setEnabled(false);
    ui->le_name->setEnabled(false);
    ui->le_dept->setEnabled(false);
    ui->le_post->setEnabled(false);
    on_pb_cancel_clicked();
    on_pb_search_clicked();
}

void StaffForm::slotUpdateBuffer(void)
{
    on_pb_search_clicked();
}
