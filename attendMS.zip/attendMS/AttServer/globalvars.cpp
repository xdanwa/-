#include "globalvars.h"

QQueue<QString> GlobalVars::g_msgQueue;

QList<QString> GlobalVars::g_userOnlineList;
UserOnlineMap GlobalVars::g_userOnlineMap;

UserInfoMap GlobalVars::g_userInfoMap;
UserInfoList *GlobalVars::g_userInfoList = new UserInfoList;

StaffInfoList *GlobalVars::g_staffInfoList = new StaffInfoList;
StaffInfoMap GlobalVars::g_staffInfoMap;

ManagerInfoList *GlobalVars::g_managerInfoList = new ManagerInfoList;
ManagerInfoMap GlobalVars::g_managerInfoMap;

DepartmentInfoList *GlobalVars::g_departmentInfoList = new DepartmentInfoList;
DepartmentInfoMap GlobalVars::g_departmentInfoMap;

AttendanceInfoList *GlobalVars::g_attendanceInfoList = new AttendanceInfoList;
AttendanceInfoList *GlobalVars::g_localStaffAttendanceInfoList = new AttendanceInfoList;
AttendanceInfoMap GlobalVars::g_attendanceInfoMap;

VacationInfoList *GlobalVars::g_vacationInfoList = new VacationInfoList;
VacationInfoList *GlobalVars::g_vacationApplyInfoList = new VacationInfoList;
VacationInfoMap GlobalVars::g_vacationInfoMap;

AnnouncementInfoList *GlobalVars::g_announcementInfoList = new AnnouncementInfoList;
AnnouncementInfoList *GlobalVars::g_localGroupBulletinList = new AnnouncementInfoList;

ChatRecordInfoList *GlobalVars::g_chatRecordInfoList = new ChatRecordInfoList;
