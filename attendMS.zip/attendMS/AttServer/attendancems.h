#ifndef ATTENDANCEMS_H
#define ATTENDANCEMS_H

#include <QMainWindow>

#include "msgserver.h"

#include "loginwidget.h"
#include "userform.h"
#include "staffform.h"
#include "managerform.h"
#include "departmentform.h"
#include "attendanceform.h"
#include "vacationform.h"
#include "announcementform.h"
#include "chatrecordform.h"

namespace Ui {
class AttendanceMS;
}

class AttendanceMS : public QMainWindow
{
    Q_OBJECT

public:
    explicit AttendanceMS(QWidget *parent = 0);
    ~AttendanceMS();

public slots:
    void slotLoginSuccess(QString id, QString pswd);

protected:
    void paintEvent(QPaintEvent *);

private slots:
    void on_actionUser_triggered();

    void on_actionStaff_triggered();

    void on_actionManager_2_triggered();

    void on_actionDepartmentMS_triggered();

    void on_actionAttendanceMS_triggered();

    void on_actionVacationMS_triggered();

    void on_actionAnnouncementMS_triggered();

    void on_actionChatRecordMS_triggered();

private:
    Ui::AttendanceMS *ui;

    MsgServer* m_msgServer;

    LoginWidget* m_loginWidget;
    UserForm* m_userForm;
    StaffForm* m_staffForm;
    ManagerForm* m_managerForm;
    DepartmentForm* m_departmentFrom;
    AttendanceForm* m_attendanceForm;
    VacationForm* m_vacationForm;
    AnnouncementForm* m_announcementForm;
    ChatRecordForm* m_chatRecordForm;
};

#endif // ATTENDANCEMS_H
