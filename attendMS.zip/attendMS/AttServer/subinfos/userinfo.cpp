#include "userinfo.h"

UserInfo::UserInfo()
{

}

UserInfo::UserInfo(QString id, QString pswd, QString role,
         QString dept, QString date)
{
    m_id = id;
    m_pswd = pswd;
    m_role = role;
    m_dept = dept;
    m_date = date;
}

void UserInfo::setID(QString id)
{
    m_id = id;
}

void UserInfo::setPswd(QString pswd)
{
    m_pswd = pswd;
}

void UserInfo::setRole(QString role)
{
    m_role = role;
}

void UserInfo::setDept(QString dept)
{
    m_dept = dept;
}

void UserInfo::setDate(QString date)
{
    m_date = date;
}

const QString UserInfo::getID(void) const
{
    return m_id;
}

const QString UserInfo::getPswd(void) const
{
    return m_pswd;
}

const QString UserInfo::getRole(void) const
{
    return m_role;
}

const QString UserInfo::getDept(void) const
{
    return m_dept;
}

const QString UserInfo::getDate(void) const
{
    return m_date;
}

void UserInfo::UserInfoDisplay(void)
{
    qDebug() << "id: " << m_id;
    qDebug() << "pswd: " << m_pswd;
    qDebug() << "role: " << m_role;
    qDebug() << "dept: " << m_dept;
    qDebug() << "date: " << m_date;
}

