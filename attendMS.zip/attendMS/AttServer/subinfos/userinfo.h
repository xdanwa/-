#ifndef USERINFO_H
#define USERINFO_H

#include <QString>
#include <QList>
#include <QMap>
#include <QDebug>

class UserInfo
{
public:
    UserInfo();
    UserInfo(QString id, QString pswd, QString role,
             QString dept, QString date);

    void setID(QString id);
    void setPswd(QString pswd);
    void setRole(QString role);
    void setDept(QString dept);
    void setDate(QString date);

    const QString getID(void) const;
    const QString getPswd(void) const;
    const QString getRole(void) const;
    const QString getDept(void) const;
    const QString getDate(void) const;

    void UserInfoDisplay(void);

private:
    QString m_id;
    QString m_pswd;
    QString m_role;
    QString m_dept;
    QString m_date;

};

typedef QList<UserInfo> UserInfoList;
typedef QMap<QString, UserInfoList::iterator> UserInfoMap;
typedef QMap<QString, int> UserOnlineMap;

#endif // USERINFO_H
