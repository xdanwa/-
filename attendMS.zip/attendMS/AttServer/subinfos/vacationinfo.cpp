#include "vacationinfo.h"

VacationInfo::VacationInfo()
{

}

VacationInfo::VacationInfo(QString id, QString name, QString dept, QString managerID,
             QString vacationDate, QString vacationReason, QString flag)
{
    m_id = id;
    m_name = name;
    m_dept = dept;
    m_managerID = managerID;
    m_vacationDate = vacationDate;
    m_vacationReason = vacationReason;
    m_flag = flag;
}

void VacationInfo::setID(QString id)
{
    m_id = id;
}

void VacationInfo::setName(QString name)
{
    m_name = name;
}

void VacationInfo::setDept(QString dept)
{
    m_dept = dept;
}

void VacationInfo::setManagerID(QString id)
{
    m_managerID = id;
}

void VacationInfo::setVacationDate(QString vacationDate)
{
    m_vacationDate = vacationDate;
}

void VacationInfo::setVacationReason(QString vacationReason)
{
    m_vacationReason = vacationReason;
}

void VacationInfo::setVacationFlag(QString flag)
{
    m_flag = flag;
}

const QString VacationInfo::getID(void) const
{
    return m_id;
}

const QString VacationInfo::getName(void) const
{
    return m_name;
}

const QString VacationInfo::getDept(void) const
{
    return m_dept;
}

const QString VacationInfo::getManagerID(void) const
{
    return m_managerID;
}

const QString VacationInfo::getVacationDate(void) const
{
    return m_vacationDate;
}

const QString VacationInfo::getVacationReason(void) const
{
    return m_vacationReason;
}

const QString VacationInfo::getVacationFlag(void) const
{
    return m_flag;
}

void VacationInfo::VacationInfoDisplay(void)
{
    qDebug() << "id: " << m_id;
    qDebug() << "name: " << m_name;
    qDebug() << "dept: " << m_dept;
    qDebug() << "managerID: " << m_managerID;
    qDebug() << "vacationDate: " << m_vacationDate;
    qDebug() << "vacationReason: " << m_vacationReason;
    qDebug() << "flag: " << m_flag;
}
