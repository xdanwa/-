#include "attendancems.h"
#include <QApplication>
#include <QDebug>

#include "connectmysql.h"
#include "msgserver.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    connectMySQL sql;
    if(sql.createConnection())
    {
        qDebug() << "connect success!";
    }

    AttendanceMS w;
    w.show();

    int res = a.exec();

    sql.closeConnection();

    return res;
}
